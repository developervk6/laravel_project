@extends('layouts.app')
@section('content')
<!-- content section-->
<div class="container my-5">
	<div class="col-lg-6 m-auto">
		<div class="bg-white shadow rounded">
			<p class="py-5 h5 font-300 text-center">Please select from following options to signin</p>
			
			<form method="POST" action="{{ route('login') }}">
            @csrf
			<div class="col-sm-9 m-auto">
				<div class="col-lg-12 text-center mb-3">
					<a href="{{ url('/redirect') }}" role="button" class="btn btn-primary btn-lg font-300 px-lg-5 px-2 w-100"><i class="fab fa-linkedin-in fa-lg mr-3"></i> Sign in by LinkedIn</a>
				</div>
				<div class="col-lg-12 text-center">
					<a href="#" role="button" class="btn btn-danger btn-lg font-300 px-lg-5 px-2 w-100"><i class="fab fa-google fa-lg mr-3"></i> Sign in by Google</a>
				</div>
				<div class="col-lg-12">
					<div class="or my-4"> <span class="bg-white px-4">or</span></div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input type="email" id="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="{{ __('E-Mail Address') }}"/>
						@error('email')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
						@enderror
					</div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">
						@error('password')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
						@enderror
					</div>
				</div>
				<div class="col-lg-12">
					<button type="submit" class="btn btn-dark btn-lg mb-5 w-100 text-white">
						{{ __('Login') }}
					</button>
				</div>
			</div>
			</form>
		</div>
	</div>
</div>
 <!-- content section-->
<!-- Footer section -->
<div class="bg-dark position-fixed bottom-0 w-100 p-3">
	<div class="container">
		<p class="mb-0 text-silver text-center">@All Rights Reserved, United Market 2020</p>
	</div>
</div>
<!-- Footer section -->
@endsection
