@extends('layouts.app')
@section('content')
<!-- content section-->
<div class="container my-5">
	<div class="col-lg-6 m-auto">
		<form method="POST" action="{{ route('login') }}">
        @csrf
		<!---Step1 Started --->
		<div class="bg-white shadow rounded" id="step1">
			<p class="py-5 h5 font-300 text-center">Please select from following options to signup</p>
			<div class="col-sm-9 m-auto">
				<div class="col-lg-12 text-center mb-3">
					<a href="{{ url('/redirect') }}" role="button" class="btn btn-primary btn-lg font-300 px-lg-5 px-2 w-100"><i class="fab fa-linkedin-in fa-lg mr-3"></i> Sign up by LinkedIn</a>
				</div>
				<div class="col-lg-12 text-center">
					<a href="#" role="button" class="btn btn-danger btn-lg font-300 px-lg-5 px-2 w-100"><i class="fab fa-google fa-lg mr-3"></i> Sign up by Google</a>
				</div>
				<div class="col-lg-12">
					<div class="or my-4"> <span class="bg-white px-4">or</span></div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="{{ __('E-Mail Address') }}">
						@error('email')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
						@enderror
					</div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password" placeholder="{{ __('Password') }}">
						@error('password')
							<span class="invalid-feedback" role="alert">
								<strong>{{ $message }}</strong>
							</span>
						@enderror
					</div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						 <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="{{ __('Confirm Password') }}">
					</div>
				</div>
				<div class="col-lg-12">					
					<a href="javascript:void(0);" onClick="nextStep('step1','step2');" class="btn btn-dark btn-lg mb-5 w-100" type="button">Next</a>
				</div>
			</div>			
		</div>
		<!---Step1 End --->
		<!---Step2 Started --->
		<div class="bg-white shadow rounded" id="step2" style="display:none;">
			<p class="py-5 h5 text-center">Please Choose From Following <br/> Options to Proceed.</p>
			<div class="col-sm-9 m-auto">
			<div class="col-lg-12 text-center mb-3">
				<form>
					<div class="border py-3 mb-3">
						<p class="mb-0">I am Looking for Services <i class="fas fa-check-circle text-success ml-3"></i></p>
					</div>
					<div class="border py-3 mb-3">
						<p class="mb-0">I am Freelancer</p>
					</div>
					<div class="border py-3">
						<p class="mb-0">I am Business</p>
					</div>
				</form>
			</div>
			<div class="col-lg-12">
				<a href="javascript:void(0);" onClick="nextStep('step2','step3');" class="btn btn-dark btn-lg mb-5 w-100" type="button">Next</a>
			</div>
			</div>
		</div>
		<!---Step2 End -->
		<!---Step3 Started -->
		<div class="bg-white shadow rounded" id="step3" style="display:none;">
			<div class="col-sm-9 m-auto">
			<div class="col-lg-12 text-center mb-3">
				<form>
					<div class="col-lg-12 userImg float-left py-4">
						<div class="rounded-circle uploadImg shadow m-auto bg-white position-relative">
							<i class="fas fa-user fa-3x position-absolute setIcon"></i>
							<input class="custom-file-input" type="file"/>
						</div>
						<span class="mt-2 d-block">Upload Picture</span>
					</div>
					<div class="form-group">
						<input type="text" class="form-control text-center py-3"  placeholder="First Name" />
					</div>
					<div class="form-group">
						<input type="text" class="form-control text-center py-3"  placeholder="Last Name" />
					</div>
					<div class="form-group">
						<input type="email" class="form-control text-center py-3"  placeholder="Email Address" />
					</div>
					<div class="form-group">
						<input type="number" class="form-control text-center py-3"  placeholder="Phone Number" />
					</div>
				</form>
			</div>
			<div class="col-lg-12">
				<a href="javascript:void(0);" onClick="nextStep('step3','step4');"  class="btn btn-dark btn-lg mb-5 w-100" type="button">Next</a>
			</div>
			</div>
		</div>
		<!---Step3 End -->
		<!---Step4 Started -->		
		<div class="bg-white shadow rounded py-5" id="step4" style="display:none;">
			<p class="pb-3 h5 font-300 text-center">Congratulations!<br/> You're Almost Done</p>
			<div class="col-sm-9 m-auto">
			<div class="col-lg-12 text-center mb-3">
				<p class="text-muted mb-4">Please Provide 4 Digit Verification code sent to your Email Address &amp; Phone Number.</p>
				<form>
					<div class="form-group d-flex justify-content-between">
						<div class="row">
						<div class="col pr-1">
							<input type="number" class="form-control text-center py-3"/>
						</div>
						<div class="col px-1">
							<input type="number" class="form-control text-center py-3"/>
						</div>
						<div class="col px-1">
							<input type="number" class="form-control text-center py-3"/>
						</div>
						<div class="col pl-1">
							<input type="number" class="form-control text-center py-3"/>
						</div>
					</div>
					</div>
				</form>
			</div>
			<div class="col-lg-12">
				<button class="btn btn-dark btn-lg mb-5 w-100" type="button">Next</button>
			</div>
			<p class="d-flex justify-content-center">Didn't Recieve Code? <a class="text-dark ml-2" href="#"><b>Send Again</b></a></p>
			</div>
		</div>		
		<!---Step4 End -->
		<!---<button type="button" class="btn btn-dark btn-lg mb-5 w-100 text-white" onClick="openStep2();">
						{{ __('Next') }}
					</button>-->		
		</form>
	</div>
</div>
 <!-- content section-->
<!-- Footer section -->
<div class="bg-dark position-fixed bottom-0 w-100 p-3">
	<div class="container">
		<p class="mb-0 text-silver text-center">@All Rights Reserved, United Market 2020</p>
	</div>
</div>
<script type="text/javascript" src="public/js/jquery-2.2.2.js"></script>
<script type="text/javascript" src="public/js/popper.min.js"></script>
<script type="text/javascript" src="public/js/bootstrap.min.js"></script>
<script src="public/js/owl/owl.carousel.js"></script>
<!-- Footer section -->
<script>
function nextStep(currentStep,nextStep){
	$('#'+currentStep).hide();
	$('#'+nextStep).show();
}	
</script>
@endsection
