<!doctype html>
<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<style type="text/css">
	.container {max-width:940px;margin:0 auto;padding-left:20px;padding-right:20px;background-color:#fff;}	
	</style>
    </head>
    <body style="margin:0; padding:0;">
		<table border="0" style="font-family:Arial, Helvetica, sans-serif;padding-top:20px; padding-bottom:20px; outline:none; border:none; width:100%; font-size:16px;color:#000000; line-height:24px;" class="container">
		  <tr>
			<td colspan="2" align="left"><img border="0" alt="" src="{{ asset('public/images/logo.png') }}"></td>
		  </tr>		  
		  <tr>
			<td colspan="2" style="border-top:1px solid #545554;padding-top:20px; padding-bottom:20px; color: #000000;font-size: 24px;" >@lang('messages.hello'),</td>
		  </tr>		  	  
		  <tr>
			<td>
				 Join URL: {{$join_url}}
			</td>
			</tr>
			<tr>
            <td>
				 Join Code: {{$join_code}}
			</td>
		  </tr>			 
		  <tr>
			<td colspan="2" style="border-top:1px solid #000;padding-top:20px; font-size:14px; padding-bottom:20px; color:#545554;" ></td>
		  </tr>
		</table>
	</body>
</html>
