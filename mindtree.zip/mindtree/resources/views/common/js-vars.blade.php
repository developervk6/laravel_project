<script type="text/javascript">
var base_path = '<?php echo URL::to('/')?>';
var home_path = '{{route("home")}}';
var profile_path = '{{route("profile-setup")}}';
var payment_path = '{{route("payment-method")}}';
var admin_base_path = '<?php echo URL::to('/admin')?>';
var image_path = '<?php echo URL::to('/public/images')?>';
var icon_path = '<?php echo URL::to('/public/images/icon')?>';
</script>
