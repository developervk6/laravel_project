@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col-sm-8 offset-sm-2">
        <h1 class="display-3">Update a router</h1>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        <br /> 
        @endif
        <form method="post" action="{{ route('edit-router-post') }}">
		<input type="hidden" name="id" value="{{ $NetworkRouters->id }}"/>
            @csrf
            <div class="form-group">    
              <label for="dns">Type:</label>
              <select class="form-control" name="type" id="type">
				<option value="AG1" @if($NetworkRouters->type=='AG1') selected @endif >AG1</option>
				<option value="CSS" @if($NetworkRouters->type=='CSS') selected @endif >CSS</option>
			  </select>
          </div> 
			<div class="form-group">
                <label for="dns">SapId:</label>
                <input type="text" class="form-control" name="SapId" value="{{$NetworkRouters->SapId}}"/>
            </div>
            <div class="form-group">
                <label for="host_name">Host Name:</label>
                <input type="text" class="form-control" name="Hostname" value="{{$NetworkRouters->Hostname}}"/>
            </div>
            <div class="form-group">
                <label for="ip_address">Loopback:</label>
                <input type="text" class="form-control" name="Loopback" value="{{$NetworkRouters->Loopback}}" />
            </div>
            <div class="form-group">
                <label for="mac_address">Mac Address:</label>
                <input type="text" class="form-control" name="MacAddress" value="{{$NetworkRouters->MacAddress}}"/>
            </div>            
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>
@endsection