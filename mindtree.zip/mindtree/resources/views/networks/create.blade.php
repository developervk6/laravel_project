@extends('layouts.app')
@section('content')
<div class="row">
 <div class="col-sm-8 offset-sm-2">
    <h1 class="display-3">Add a router</h1>
  <div>
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('add-new-router-post') }}">
          @csrf
		  <div class="form-group">    
              <label for="dns">Type:</label>
              <select class="form-control"  name="type" id="type">
				<option value="AG1">AG1</option>
				<option value="CSS">CSS</option>
			  </select>
          </div> 
          <div class="form-group">    
              <label for="dns">Sap ID:</label>
              <input type="text" class="form-control" name="SapId" value="{{old('SapId')}}"/>
          </div>          
          <div class="form-group">
              <label for="host_name">Host Name:</label>
              <input type="text" class="form-control" name="Hostname" value="{{old('Hostname')}}"/>
          </div>
          <div class="form-group">
              <label for="ip_address">Loop Back(IPV4):</label>
              <input type="text" class="form-control" name="Loopback" value="{{old('Loopback')}}"/>
          </div>
          <div class="form-group">
              <label for="mac_address">Mac Address:</label>
              <input type="text" class="form-control" name="MacAddress" value="{{old('MacAddress')}}"/>
          </div>                           
          <button type="submit" class="btn btn-primary-outline">Add Router</button>
      </form>
  </div>
</div>
</div>
@endsection