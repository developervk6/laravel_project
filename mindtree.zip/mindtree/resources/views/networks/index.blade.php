@extends('layouts.app')
@section('content')
<div class="row">
<div class="col-sm-12">
  @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div>
  @endif
</div>
<div class="col-sm-12">
    <h1 class="display-3">Routers</h1>  
	<div style="margin: 10px 10px 20px 0px;">
		<a href="{{ route('add-new-router')}}" class="btn btn-primary">Add New Router</a>
		<span style="float:right;"><input type="text" name="search_keyword" id="search_keyword" placeholder="Search"></span>
    </div>	
  <table class="table table-striped">
    <thead>
        <tr>
          <td style="width:10%;">ID</td>
          <td style="width:10%;">Type</td>
		  <td style="width:15%;">SapId</td>
          <td style="width:15%;">Hostname</td>
          <td style="width:15%;">Loopback</td>
          <td style="width:15%;">Mac Address</td>
          <td colspan ="2" style="width:20%;">Actions</td>
        </tr>
    </thead>
	</table>
	<div id="results_router">
		@if(count($networks)>0)
			@foreach($networks as $network)
			<table class="table table-striped">
				<tr>
					<td style="width:10%;">{{$network->id}}</td>
					<td style="width:10%;">{{$network->type}}</td>
					<td style="width:15%;">{{$network->SapId}}</td>
					<td style="width:15%;">{{$network->Hostname}}</td>			
					<td style="width:15%;">{{$network->Loopback}}</td>
					<td style="width:15%;">{{$network->MacAddress}}</td>
					<td style="width:10%;">
						<a href="{{URL('/')}}/network-routers/edit-router/{{$network->id}}" class="btn btn-primary">Edit</a>
					</td>
					<td style="width:10%;">
						<a class="btn btn-danger" href="javascript:void();" onClick="deleteNetworkRouter({{$network->id}});">Delete</button>
					</td>
				</tr>
			</table>
			@endforeach
			{{$networks->appends(request()->query())->links()}}
		@else
			No records found
		@endif
		
	</div>  
<div>
</div>
</div>
@include('common.footer')
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$("#search_keyword").keyup(function(){
	var formPostData = {action:"SearchRouter",search_keyword:$(this).val()};
	$.ajax({
		type:'POST',
		url:"{{URL('/')}}"+"/AjaxRequest",
		data:formPostData,
		async: false,
		success:function(data){
			if(data.code==200){
				var html = '<table class="table table-striped">';
				if(data.data.length>0){					
					for(i=0;i<data.data.length;i++){					
						var network = data.data[i];
						html += '<tr>';
						html += '<td style="width:10%;">'+network.id+'</td>';
						html += '<td style="width:10%;">'+network.type+'</td>';
						html += '<td style="width:15%;">'+network.SapId+'</td>';
						html += '<td style="width:15%;">'+network.Hostname+'</td>';
						html += '<td style="width:15%;">'+network.Loopback+'</td>';		
						html += '<td style="width:15%;">'+network.MacAddress+'</td>';
						html += '<td style="width:10%;">';
						html += '<a href="{{URL("/")}}/network-routers/edit-router/'+network.id+'" class="btn btn-primary">Edit</a>';
						html += '</td>';
						html += '<td style="width:10%;">';
						html += '<form action="{{URL("/")}}/network-routers/delete-router" method="post">';
						html += '<input type="hidden" name="id" value="'+network.id+'"/>';
						html += '<a class="btn btn-danger" href="javascript:void();" onClick="deleteNetworkRouter('+network.id+');">Delete</a>';
						html += '</form>';
						html += '</td>';
						html += '</tr>';
					}
				}else{
					html = 'No results found';
				}	
				html += '</table>';
				$("#results_router").html("");				
				$("#results_router").html(html);	
			}
		}
	}); 
});
function deleteNetworkRouter(id){
	var formPostData = {action:'deleteRouter',id:id};
	if(confirm("Are you sure do you wan to delete this?")){
		$.ajax({
			type:'POST',
			url:"{{URL('/')}}/AjaxRequest",
			data:formPostData,
			async: false,
			success:function(data){
				if(data.code==200){
					alert("Deleted successfully");
					window.location.href=document.URL;
				}
			}
		});
	}
}	
</script>
@endsection