<?php
return
[
    'hello'=>'Hello',
    'copyright_text'=>'@All Rights Reserved, United Market 2020',
    'verification_email_subject'=>'United Market - Verification Code',
    'invalid_login_credentials'=>'Invalid login credentials.',
    'already_registered_account'=>'You have already registered, sign up with new email address.',
    'no_records_found'=>'No records found',
    'success'=>'Success',
    'account_is_not_active'=>'Your account is not active.',
    'invalid_verification_code'=>'Invalid verification code.',
    'mobile_already_exists'=>'Mobile number already exists.',
    'invalid_image'=>'Invalid Image',
    'not_found'=>'Not found',
    'parameter_missing'=>'Parameter missing',
    'invalid_image_file_error'=>'Invalid image file type. Please upload valid file - .jpg, .jpeg, .png',
    'invalid_video_file_error'=>'Invalid video file type. Please upload valid file - .mp4, .mov, .avi',
    'upload_error'=>'Error in moving files, please try again.',
    'already_exists'=>'Already exists',
    'already_applied'=>'Already applied',    
    'error'=>'Error',
    'unauthorise'=>'Unauthorized',
    'old_password_does_not_match'=>'Old password does not match',
    'already_added'=>'Already added',
    'wrong_security_answer'=>'Wrong securty answer',
    'invalid_video_link'=>'Invalid video link, only youtube and vimeo video link accepted',
    'contract_already_sent'=>'Contract already sent.'
];
?>