<script type="text/javascript">
var base_path = '<?php echo URL::to('/')?>';
var home_path = '<?php echo e(route("home")); ?>';
var profile_path = '<?php echo e(route("profile-setup")); ?>';
var payment_path = '<?php echo e(route("payment-method")); ?>';
var admin_base_path = '<?php echo URL::to('/admin')?>';
var image_path = '<?php echo URL::to('/public/images')?>';
var icon_path = '<?php echo URL::to('/public/images/icon')?>';
</script>
<?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/common/js-vars.blade.php ENDPATH**/ ?>