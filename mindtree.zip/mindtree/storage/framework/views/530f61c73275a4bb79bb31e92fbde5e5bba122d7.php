
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow cus-rounded p-lg-5 p-md-5 p-sm-5 p-4">
        <!-- notification 1 -->
        <div class="alert alert-dismissible fade show cus-alert border-bottom px-0"
            role="alert">
            <div class="row w-100 h5 font-300 text-muted d-flex justify-content-between align-items-center">
                <div class="col-lg-9 col-md-9 col-sm-7 col-12">
                    <p class="mb-0">Your Contract is ended <span class="text-dark">With Michael</span> for the JOB TITLE Need <span class="text-dark">"Photographer for
                        Product Shoot".</span></p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-5 col-12 d-flex align-items-center justify-content-between">
                    <button type="button" class="close px-lg-4 px-md-4 px-sm-4 px-0 font-300 order-1" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <p class="mb-0 order-2">Feb 12</p>
                </div>
            </div>
        </div>
        <!-- notification 1 -->
        <!-- notification 2 -->
        <div class="alert alert-dismissible fade show cus-alert px-0"
            role="alert">
            <div class="row w-100 h5 font-300 text-muted d-flex justify-content-between align-items-center">
                <div class="col-lg-9 col-md-9 col-sm-7 col-12">
                    <p class="mb-0">Your Contract is started <span class="text-dark">With Amanda Johnson</span> for the JOB TITLE Need <span class="text-dark">"Photographer for
                        Product Shoot".</span></p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-5 col-12 d-flex align-items-center justify-content-between">
                    <button type="button" class="close px-lg-4 px-md-4 px-sm-4 px-0 font-300 order-1" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <p class="mb-0 order-2">Feb 12</p>
                </div>
            </div>
        </div>
        <!-- notification 2 -->
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
</script> 
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/notifications.blade.php ENDPATH**/ ?>