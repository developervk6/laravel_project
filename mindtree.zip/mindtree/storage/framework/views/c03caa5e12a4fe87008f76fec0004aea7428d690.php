
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <form name="" id="frmEditPortfolio" action="" method="post">
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                        <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link active" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" role="tab" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" role="tab" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">                                            
                                            <div class="tab-pane fade show active" id="portfolio" role="tabpanel" aria-labelledby="nav-contact-tab">
                                                        <!-- portfolio -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                                <p class="text-dark mb-0">Note: <span class="text-muted">To make changes in your basic profile please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white">
                                                                    <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">
                                                                        <i class="fas fa-pen text-dark"></i>
                                                                    </span>
                                                                    Edit
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <!-- drag and drop -->
                                                        <div class="border rounded p-4 mt-2" id="addNewPortfolio">
                                                            <div class="row mt-2">
                                                                <div class="col-lg-12">
                                                                    <div class="drapDrop-full rounded d-flex align-items-center justify-content-center mb-lg-0 mb-sm-4 mb-4">
                                                                        <input class="custom-file-input dragDropFile" type="file" id="fileInput" multiple size="50">
                                                                        <p class="text-muted-50 text-center mb-0 position-absolute">Drag your files or <strong>Browse</strong> to upload</p>
                                                                        
                                                                    </div>
                                                                    <p class="font-bold text-center my-3">OR Embed a link
                                                                    </p>
                                                                    <div class="shadow text-center p-3">
                                                                        <a class="text-dark" href="#"
                                                                            data-toggle="modal"
                                                                            data-target="#addVideoLink">
                                                                            <i class="fas fa-video mr-2"></i> Add Video Link
                                                                        </a>
                                                                    </div>
                                                                    <span
                                                                        class="d-block text-center text-muted-50 py-5 border-bottom">Upload
                                                                        .jpg, .gif, .png images upto 10MB each. Images
                                                                        will
                                                                        be displayed at 690px wide, at maximum. You can
                                                                        also
                                                                        embed YouTube or Vimeo videos.</span>
                                                                </div>
                                                            </div>
                                                            <input type="hidden" id="portfolio_media_ids" name="portfolio_media_ids" value="<?php echo e($portfolio->media_ids); ?>">
                                                            <input type="hidden" id="portfolio_cover_media_id" name="portfolio_cover_media_id" value="<?php echo e($portfolio->cover_media_id); ?>">
                                                            <!-- drag and drop -->
                                                            <!-- cover image -->
                                                            <div id="coverImage">
                                                                <div class="row mt-5" id="addeed-portfolios">
                                                                <?php if(!empty($portfolio->medias)): ?>
                                                                    <?php $__currentLoopData = $portfolio->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4" id="portfolio_item_<?php echo e($media->id); ?>">
                                                                        <div class="card border-0 position-relative">
                                                                            <div class="position-absolute portfolioIcon">                                                                                
                                                                                <a href="javascript:void(0);" onClick="deletePortfolioAddedItem(<?php echo e($media->id); ?>);">
                                                                                    <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">
                                                                                        <i class="fas fa-trash text-dark"></i>
                                                                                    </span>
                                                                                </a>
                                                                            </div>
                                                                            <?php if($media->media_type=='youtube'): ?>
                                                                            <?php 
                                                                                $video_arr = explode("?v=",$media->media_file);
                                                                                $video_id = $video_arr[1];
                                                                            ?>
                                                                                <iframe width="420" height="315" src="https://www.youtube.com/embed/<?php echo e($video_id); ?>"></iframe>
                                                                            <?php else: ?>
                                                                                <img class="card-img-top" src="<?php echo e(URL($media->media_file)); ?>">
                                                                            <?php endif; ?>


                                                                            <div class="card-body px-0">
                                                                                <div class="form-group">
                                                                                    <input type="text" name="caption_<?php echo e($media->id); ?>" id="caption_<?php echo e($media->id); ?>" class="form-control cus-input" placeholder="Enter Caption" value="<?php echo e($media->caption); ?>" />
                                                                                </div>
                                                                                <div class="form-group mr-4">
                                                                                    <div class="custom-control custom-radio">
                                                                                        <input type="radio" id="customRadio<?php echo e($media->id); ?>" name="customRadio" class="custom-control-input" onclick="setCoverMedia(<?php echo e($media->id); ?>)" <?php if($media->id==$portfolio->cover_media_id): ?> checked <?php endif; ?>>
                                                                                        <label class="custom-control-label" for="customRadio<?php echo e($media->id); ?>">Cover Image</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>  
                                                                </div>
                                                            </div>
                                                            <!-- album form -->
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <h5 class="font-300">Album Title/Project Name</h5>
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control cus-input" name="title" id="title" placeholder="Title" value="<?php echo e($portfolio->title); ?>" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <textarea class="form-control" placeholder="Description" name="description" id="description" rows="4"><?php echo e($portfolio->description); ?></textarea>
                                                                    </div>
                                                                    <div class="form-group">                                                                       
                                                                        <input type="hidden" name="id" id="id" value="<?php echo e($portfolio->id); ?>">
                                                                        <button type="button" id="btnUpdatePortfolio" class="btn btn-dark btn-sm btn-block">Save</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- album form -->
                                                        </div>
                                                        <!-- cover image-->
                                                    </div>                                                      
                                                </div>
                                            </div>
                                </section>
                                </form>
                                <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Modal -->
<div class="modal fade" id="addVideoLink" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Add a Video Link</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <p>Paste the link to your Youtube or Vimeo Video Here</p>
                <form>
                    <div class="form-group">
                        <input type="text" name="video_link" id="video_link" class="form-control cus-input" placeholder="Link" />
                        <p class="mt-2 text-muted-50">Any Data which not meet United Market Guidlines will be
                            deleted.</p>
                    </div>
                </form>
                <div class="col-lg-6 m-auto">
                    <button type="button" id="btnAddVideoLink" class="btn btn-dark btn-sm btn-block mt-5">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){

});
// drag and drop
function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            var htmlPreview =
                '<img class="img-fluid" src="' + e.target.result + '" />'
            //'<p>' + input.files[0].name + '</p>';
            var wrapperZone = $(input).parent();
            var previewZone = $(input).parent().parent().find('.preview-zone');
            var boxZone = $(input).parent().parent().find('.preview-zone').find('.box1').find('.box-body');

            wrapperZone.removeClass('dragover');
            previewZone.removeClass('hidden');
            boxZone.empty();
            boxZone.append(htmlPreview);
        };

        reader.readAsDataURL(input.files[0]);
    }
}
$("#btnAddVideoLink").click(function(){
    if($('#video_link').val()==''){
        alert("Please add video link.");
        $('#video_link').focus();
        return false;    
    }else{
        var formData = {video_link:$('#video_link').val()}  
        $.ajax({
            type:'POST',
            url:'/api/add-video-link',
            data:formData,
            success:function(data){
                if(data.code==200){
                    var media_ids = data.media_ids;
                    var media_files = data.media_files;
                    var media_urls = data.media_urls;
                    var thumbnails = data.thumbnails;
                    var video_ids = data.video_ids;
                    if($('#portfolio_media_ids').val()!=''){
                        $('#portfolio_media_ids').val($('#portfolio_media_ids').val()+','+media_ids[0]);
                    }else{
                        $('#portfolio_media_ids').val(media_ids[0]);
                    }  
                    var media_html = '';
                    media_html += '<div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4" id="portfolio_item_'+media_ids[0]+'">';
                    media_html += '<div class="card border-0 position-relative">';
                    media_html += '<div class="position-absolute portfolioIcon">';
                    media_html += '<a href="javascript:void(0);" onClick="deletePortfolioAddedItem('+media_ids[0]+')">';
                    media_html += '<span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">';
                    media_html += '<i class="fas fa-trash text-dark"></i>';
                    media_html += '</span>';
                    media_html += '</a>';
                    media_html += '</div>';
                    media_html += '<iframe width="420" height="315" src="https://www.youtube.com/embed/'+video_ids[0]+'"></iframe>';
                    media_html += '<div class="card-body px-0">';
                    media_html += '<div class="form-group">';
                    media_html += '<input type="text" name="caption_'+media_ids[0]+'" class="form-control cus-input" placeholder="Enter Caption" />';
                    media_html += '</div>';
                    media_html += '<div class="form-group mr-4">';
                    media_html += '<div class="custom-control custom-radio">';
                    media_html += '<input type="radio" id="customRadio'+media_ids[0]+'" name="customRadio" class="custom-control-input" onclick="setCoverMedia('+media_ids[0]+');">';
                    media_html += '<label class="custom-control-label" for="customRadio'+media_ids[0]+'">Cover Image</label>';
                    media_html += '</div>';
                    media_html += '</div>';
                    media_html += '</div>';
                    media_html += '</div>';
                    media_html += '</div>';
                    $('#addeed-portfolios').prepend(media_html);
                    $(".close").trigger("click");
                }
            }
        });
    }
});
$("#fileInput").change(function(){
    var allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    var file = this.files[0];
    var fileType = file.type;
    if(!allowedTypes.includes(fileType)){
        alert('Please select a valid file (JPEG/JPG/PNG/GIF).');
        $("#fileInput").val('');
        return false;
    }else{     
        $('.progress').show();       
        var file = this.files[0];
        var formData = new FormData();
        formData.append("media_files[]", file);
        $.ajax({                
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = ((evt.loaded / evt.total) * 100);
                        $(".progress-bar").width(percentComplete + '%');
                        $(".progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
            type: 'POST',
            url: '/api/upload-medias',
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                //$(".progress-bar").width('0%');
                //$('#uploadStatus').html('<img src="images/loading.gif"/>');
            },
            error:function(){
                //$('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
            },
            success: function(resp){                    
                if(resp.code == 200){
                    var media_ids = resp.media_ids;
                    var media_files = resp.media_files;
                    var media_urls = resp.media_urls;
                    if($('#portfolio_media_ids').val()!=''){
                        $('#portfolio_media_ids').val($('#portfolio_media_ids').val()+','+media_ids[0]);
                    }else{
                        $('#portfolio_media_ids').val(media_ids[0]);
                    }                     
                    for(i=0;i<media_ids.length;i++){
                        var media_html = '';
                        media_html += '<div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4" id="portfolio_item_'+media_ids[i]+'">';
                        media_html += '<div class="card border-0 position-relative">';
                        media_html += '<div class="position-absolute portfolioIcon">';
                        media_html += '<a href="javascript:void(0);" onClick="deletePortfolioAddedItem('+media_ids[i]+')">';
                        media_html += '<span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">';
                        media_html += '<i class="fas fa-trash text-dark"></i>';
                        media_html += '</span>';
                        media_html += '</a>';
                        media_html += '</div>';
                        media_html += '<img class="card-img-top" src="'+media_urls[i]+'" alt="Card image cap">';
                        media_html += '<div class="card-body px-0">';
                        media_html += '<div class="form-group">';
                        media_html += '<input type="text" name="caption_'+media_ids[i]+'" class="form-control cus-input" placeholder="Enter Caption" />';
                        media_html += '</div>';
                        media_html += '<div class="form-group mr-4">';
                        media_html += '<div class="custom-control custom-radio">';
                        media_html += '<input type="radio" id="customRadio'+media_ids[i]+'" name="customRadio" class="custom-control-input" onclick="setCoverMedia('+media_ids[i]+');">';
                        media_html += '<label class="custom-control-label" for="customRadio'+media_ids[i]+'">Cover Image</label>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                    }
                    $('#addeed-portfolios').prepend(media_html);
                }else if(resp.code == 401){
                    $('#uploadStatus').html('<p class="text-dark">Please select a valid file to upload.</p>');
                }
            } 
        });
    }
});
function deletePortfolioAddedItem(media_id){
    $("#portfolio_item_"+media_id).remove();
    var value = media_id;
    var arr = $("#portfolio_media_ids").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#portfolio_media_ids").val(arr.join(","));
    $("#portfolio_item_"+media_id).remove(); 
    // $.ajax({
    //     type:'DELETE',
    //     url:'/api/delete-media/'+media_id,
    //     async: false,
    //     success:function(data){
    //         if(data.code==200){   
    //             $("#media_div_"+media_id).remove();          
    //         }
    //     }
    // });
}
function setCoverMedia(media_id){
    $("#portfolio_cover_media_id").val(media_id);
}
$('#btnUpdatePortfolio').click(function(e){
    e.preventDefault();
    if($('#title').val()==''){
        alert("Please select title.");
        $('#title').focus();
        return false;
    }else if($('#description').val()==''){
        alert("Please select description.");
        $('#description').focus();
        return false;
    }else{
        // var id = $("#id").val();
        // var title = $("#title").val();
        // var description = $("#description").val();
        // var portfolio_media_ids = $("#portfolio_media_ids").val();                   
        // var portfolio_cover_media_id = $("#portfolio_cover_media_id").val();
        // var formData = {id:id,title:title,description:description,portfolio_media_ids:portfolio_media_ids,portfolio_cover_media_id:portfolio_cover_media_id};     
        var formData = $("#frmEditPortfolio").serialize();
        $.ajax({
            type:'POST',
            url:'/UpdatePortfolio',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href="/settings/portfolio";
                }
            }
        });
    }
});
function deletePortfolio(portfolio_id){
    if(confirm("Are you sure? do you want to delete this?")){
        $.ajax({
            type:'DELETE',
            url:'/api/delete-portfolio/'+portfolio_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    alert("Deleted");                  
                }
            }
        });
    }
}
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/edit-portfolio.blade.php ENDPATH**/ ?>