
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" role="tab" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link active" id="nav-about-tab" href="/settings/contact-info" role="tab" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div> 
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0">                                            
                                            <div class="tab-pane fade show active" id="contact-info" role="tabpanel" aria-labelledby="nav-about-tab">
                                                <!-- note -->
                                                <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                   <div
                                                        class="d-flex flex-sm-row flex-column align-items-center justify-content-between">
                                                        <p class="text-dark text-sm-left text-center mb-sm-0 mb-2">Note: <span
                                                                class="text-muted">To make changes in your
                                                                Contact please click on edit button</span></p>
                                                        <a role="button" class="btn btn-dark text-white"
                                                            data-toggle="modal" data-target="#basicProfile">
                                                            <span
                                                                class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                    class="fas fa-pen text-dark"></i></span>
                                                            Edit</a>
                                                    </div>
                                                </div>
                                                <!-- note -->
                                                <!-- section 1 -->
                                                <div class="border rounded my-4 p-3">
                                                    <div class="row">
                                                        <!-- line 1 -->
                                                        <div class="col-lg-5">
                                                            <div class="d-flex align-items-center">
                                                                <h5 class="font-300 mr-2">Phone Number</h5>
                                                                <a data-toggle="modal" data-target="#phoneModal"><i
                                                                        class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-5"></i></a>
                                                            </div>
                                                            <p class="small text-muted-50"><?php echo e($user->mobile); ?></p>
                                                        </div>
                                                        <!-- line 1 -->
                                                        <!-- line 2 -->
                                                        <div class="col-lg-5">
                                                            <div class="d-flex align-items-center">
                                                                <h5 class="font-300 mr-2">Email Address</h5>
                                                                <a data-toggle="modal" data-target="#emailModal"><i
                                                                        class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-5"></i></a>
                                                            </div>
                                                            <p class="small text-muted-50"><?php echo e($user->email); ?></p>
                                                        </div>
                                                        <!-- line 2 -->
                                                    </div>
                                                </div>
                                            </div>  
                                        </div>  
                                    </div>  
                                </div> 
                            </div>                                           
                        </section>
                        <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<!-- Modal -->
<div class="modal fade" id="phoneModal" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Contact Info</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>NOTE: Please provide your phone number</p>
                <p id="alert-message-phone" class="alert text-center" style="display:none;"></p>
                <form>
                    <input type="hidden" name="otpMobileGenerated" id="otpMobileGenerated" value="" />
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" name="mobile" id="mobile" maxlength="10" placeholder="Phone Number" />
                    </div>    
                    <div class="form-group" id="otpMobileBox" style="display:none;">
                        <input type="text" name="otpMobile" id="otpMobile" maxlength="4" class="form-control cus-input" placeholder="OTP" value="" />
                    </div>            
                    <div id="mobile_otp_action">
                        <button type="button" id="btnSendOtpToMobile" class="btn btn-dark btn-sm btn-block">Send OTP</button>
                    </div>
                    <div id="mobile_save_action" style="display:none;">
                        <button type="button" id="btnSaveMobile" class="btn btn-dark btn-sm btn-block" >Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="emailModal" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Contact Info</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>NOTE: Please provide your email address</p>
                <p id="alert-message-email" class="alert text-center" style="display:none;"></p>
                <form>
                    <input type="hidden" name="otpEmailGenerated" id="otpEmailGenerated" value="" />
                    <div class="form-group">
                        <input type="text" id="email" name="email" class="form-control cus-input" placeholder="Email Address" />
                    </div>
                    <div class="form-group" id="otpEmailBox" style="display:none;">
                        <input type="text" name="otpEmail" id="otpEmail" maxlength="4" class="form-control cus-input" placeholder="OTP" value="" />
                    </div>
                    <div id="email_otp_action">
                        <button type="button" id="btnSendOtpToEmail" class="btn btn-dark btn-sm btn-block">Save</button>
                    </div>
                    <div id="email_save_action" style="display:none;">
                        <button type="button" id="btnSaveEmail" class="btn btn-dark btn-sm btn-block">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    $('#mobile,#otpMobile,#otpEmail').keydown(function(event){        
        if ( event.keyCode == 46 || event.keyCode == 8 ) {
        }
        else {
            if (event.keyCode < 48 || event.keyCode > 57) {
                event.preventDefault(); 
            }             
        }
    });
});
$('#btnSendOtpToMobile').click(function(e){
    e.preventDefault();
    if($('#mobile').val()==''){
        alert("Please enter phone number.");
        $('#mobile').focus();
        return false;
    }else if($('#mobile').val() !='' && $('#mobile').val().length<6){
        alert("Invalid phone number");
        $('#mobile').focus();
        return false;  
    }else{
        var formData = {action:'SendOtpToMobile',mobile:$("#mobile").val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data: formData,
            success:function(data){               
                if(data.code==200){
                    $('#otpMobileGenerated').val(data.otp);
                    $('#mobile_otp_action').hide();
                    $('#mobile_save_action').show();
                    $('#otpMobileBox').show();
                    $('#alert-message-phone').show();
                    $('#alert-message-phone').addClass("alert-success");
                    $("#alert-message-phone").html("OTP sent to new phone number.");
                    setTimeout(function(){
                        $("#alert-message-phone").hide();
                    },5000);
                }else if(data.code==207){
                    $('#alert-message-phone').show();
                    $('#alert-message-phone').addClass("alert-danger");
                    $("#alert-message-phone").html("Phone number already exists.");
                    setTimeout(function(){
                        $("#alert-message-phone").hide();
                    },5000);
                    $('#mobile').focus();
                    return false;
                }
            }
        });
    }
});
$('#btnSaveMobile').click(function(e){
    e.preventDefault();
    if($('#otpMobile').val()==''){
        alert("Please enter otp");
        $('#otpMobile').focus();
        return false;
    }else if($('#otpMobile').val()!=$('#otpMobileGenerated').val()){
        alert("Invalid otp");
        $('#otpMobile').focus();
        return false;
    }else{
        var formData = {action:'SaveMobile',mobile:$("#mobile").val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data: formData,
            success:function(data){
                if(data.code==200){
                    alert("Phone number updated successfully.");
                    window.location.href=document.URL;
                }
            }
        });
    }
});
$('#btnSendOtpToEmail').click(function(e){
    e.preventDefault();
    if($('#email').val()==''){
        alert("Please enter email.");
        $('#email').focus();
        return false;
    }else if(!validateEmail($('#email').val())){
			alert("Please enter valid email.");
			$('#email').focus();
			return false;
    }else{
        var formData = {action:'SendOtpToEmail',email:$("#email").val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data: formData,
            success:function(data){
                if(data.code==200){
                    $('#otpEmailGenerated').val(data.otp);
                    $('#email_otp_action').hide();
                    $('#email_save_action').show();
                    $('#otpEmailBox').show();
                    $('#alert-message-email').show();
                    $('#alert-message-email').addClass("alert-success");
                    $("#alert-message-email").html("OTP sent to new email.");
                    setTimeout(function(){
                        $("#alert-message-email").hide();
                    },5000);
                }else{
                    $('#alert-message-email').show();
                    $('#alert-message-email').addClass("alert-danger");
                    $("#alert-message-email").html("Email already exists.");
                    setTimeout(function(){
                        $("#alert-message-email").hide();
                    },5000);
                }
            }
        });
    }
});
$('#btnSaveEmail').click(function(e){
    e.preventDefault();
    if($('#otpEmail').val()==''){
        alert("Please enter otp");
        $('#otpEmail').focus();
        return false;
    }else if($('#otpEmail').val()!=$('#otpEmailGenerated').val()){
        alert("Invalid otp");
        $('#otpEmail').focus();
        return false;
    }else{
        var formData = {action:'SaveEmail',email:$("#email").val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data: formData,
            success:function(data){
                if(data.code==200){
                    alert("Email updated successfully.");
                    window.location.href=document.URL;
                }
            }
        });
    }
});
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/contact-info.blade.php ENDPATH**/ ?>