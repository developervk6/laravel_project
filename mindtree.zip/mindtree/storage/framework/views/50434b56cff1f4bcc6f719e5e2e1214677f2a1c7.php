<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="United Market for Business">
    <meta name="keywords" content="Business, Services, Client, jobs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>United Market</title>
    <!-- stylesheets -->
    <link rel="shortcut icon" href="<?php echo e(URL('/')); ?>/public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/style.css">
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/bootstrap-4.css">
	
	<!-- Owl Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/owl/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/owl/owl.theme.default.css">
	
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css"
        integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <!-- stylesheets -->
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/stepper.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link href="<?php echo e(URL('/')); ?>/public/css/two-handle.css" rel="stylesheet" />
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL('/')); ?>/public/css/fancymetags.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL('/')); ?>/public/css/mBox.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <?php echo view("common.js-vars");?>
</head>
<body>
    <div class="wrapper bg-light">
		<!-- header -->
            <?php if(auth()->guard()->guest()): ?>
            <nav class="navbar navbar-expand-md navbar-dark bg-dark py-0 pb-sm-0">
            <div class="container">
                <a class="navbar-brand logo py-3"  href="<?php echo e(url('/')); ?>">
					<img class="img-fluid" src="<?php echo e(URL('/')); ?>/public/images/logo.png" alt="logo" />
				</a>
                <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarCollapse"
					aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto d-flex align-items-center">
                        <li class="nav-item mr-lg-4 mr-md-4 mobile-menu">
                            <a class="nav-link mb-0 text-white" href="<?php echo e(url('/about-us')); ?>">About Us</a>
                        </li>
                        <li class="nav-item mr-lg-4 mr-md-4 mobile-menu">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item mr-lg-5 mr-md-5 mobile-menu">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('signup')); ?>"><?php echo e(__('Signup')); ?></a>
                        </li>
                        <li class="bg-white rounded px-lg-4 small post-job"><a role="button" href="#" class="btn btn-sm text-dark p-2">Post a job</a></li>
                    </ul>
                </div>
            </div>
            </nav>
            <?php else: ?>
            <nav class="navbar navbar-expand-xl navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand logo"  href="<?php echo e(url('/')); ?>">
					<img class="img-fluid" src="<?php echo e(URL('/')); ?>/public/images/logo.png" alt="logo" />
				</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
					aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="main-head navbar-nav d-flex align-items-center justify-content-end w-100">
                        <li
                            class="mr-xl-5 mr-lg-0  mr-md-0 mr-sm-0 mr-0 mb-xl-0 mb-lg-3 mb-md-3 mb-md-3 mb-3 mt-xl-0 mt-lg-5 mt-md-5 mt-5 position-relative col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group mb-0 position-relative headerSearch">
                                <form id="formSearch" autocomplete="off" action="/search-results" method="get">
                                    <input type="hidden" name="search_type" id="search_type" value="all">
                                    <input type="hidden" name="search_id" id="search_id" value="all">
                                    <input type="hidden" name="search_in" id="search_in" value="all">
                                    <input id="keyword" name="keyword" type="text" class="form-control bg-dark border-silver" placeholder="Find Freelancer/Business" value=""/>                                    
                                </form>
                                <div class="position-absolute searchIcon">
                                    <i class="fas fa-search fa-lg text-white"></i>
                                    <i class="fas fa-caret-down text-white cursor-pointer" id="searchArrow" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false"></i>
                                    <div class="dropdown-menu dropdown-menu-right text-center searchDrop" aria-labelledby="searchArrow">
                                        <a class="dropdown-item" href="javascript:void(0);" onClick="chnageSearchFor('FREELANCER');">Freelancer</a>
                                        <a class="dropdown-item" href="javascript:void(0);" onClick="chnageSearchFor('BUSINESS');">Business</a>
                                        <a class="dropdown-item" href="javascript:void(0);" onClick="chnageSearchFor('INSTITUTE');">Institute</a>
                                        <a class="dropdown-item" href="javascript:void(0);" onClick="chnageSearchFor('ORGANIZATION');">Organization</a>
                                    </div>
                                </div>
                            </div> <!-- /.form-group -->
                        </li>
                        
                        <?php if(Auth::user()->user_type=='CLIENT'): ?>
                        <li class="nav-item mr-xl-3 mr-lg-0 mr-md-0 mr-sm-0 mr-0 mb-xl-0 mb-lg-3 mb-md-3 mb-3 dropdown">
                            <a class="nav-link mb-0 text-white font-300" href="#" id="myJobs"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Jobs</a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="myJobs">
                                <a class="dropdown-item" href="<?php echo e(route('create-job')); ?>">Create New <i class="fas fa-plus ml-1"></i></a>
                                <a class="dropdown-item" href="<?php echo e(route('my-jobs')); ?>">My Jobs</a>
                            </div>
                        </li>
                        <?php else: ?>
                        <li class="nav-item mr-xl-3 mr-lg-0 mr-md-0 mr-sm-0 mr-0 mb-xl-0 mb-lg-3 mb-md-3 mb-3 dropdown">
                            <a class="nav-link mb-0 text-white font-300" href="#" id="myJobs"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Jobs</a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="myJobs">
                                <a class="dropdown-item" href="<?php echo e(route('applied-jobs')); ?>">Applied Jobs</a>
                                <a class="dropdown-item" href="<?php echo e(route('saved-jobs')); ?>">Saved Jobs</a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item mr-xl-3 mr-lg-0 mr-md-0 mr-sm-0 mr-0 mb-xl-0  mb-lg-3 mb-md-3 mb-3">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('notifications')); ?>">Messages <span
                                    class="box arrow-bottom ml-2 rounded">2</span></a>
                        </li>
                        <li class="nav-item mr-xl-3 mr-lg-0 mr-md-0 mr-sm-0 mr-0 mb-xl-0  mb-lg-3 mb-md-3 mb-3">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('notifications')); ?>">My Reminders</a>
                        </li>
                        <li
                            class="mr-xl-4 mr-lg-0 mr-md-0 mr-sm-0 mr-0 mb-xl-0  mb-lg-3 mb-md-3 mb-3 dropdown">
                            <i class="fas fa-bell fa-lg text-white cursor-pointer" id="notification_top" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"></i>
                            <div class="dropdown-menu dropdown-menu-right searchDrop" aria-labelledby="notification_top">
                                <?php if(count(UnreadNotifications())>0): ?>
                                <?php $__currentLoopData = UnreadNotifications(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('notifications')); ?>">
                                    <i class="fas fa-bell mr-3"></i> 
                                    <span class="d-flex justify-content-between  align-items-center w-100">
                                        <p class="text-truncate mb-0"><?php echo e($notification->message); ?></p> <i class="fas fa-chevron-right ml-3"></i>
                                    </span>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item bg-dark text-white text-center rounded mb-2 mt-4" href="<?php echo e(route('notifications')); ?>">See All</a>
                                <?php endif; ?>
                            </div>                            
                        </li>
                        <li class="dropdown mr-xl-4 mr-lg-0 mr-md-0 mr-sm-0 mr-0 mb-xl-0  mb-lg-3 mb-md-3 mb-3">
                           <div  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                            <img class="avatar img-fluid rounded-circle cursor-pointer" src="<?php if(Auth::user()->profile_image!=''){echo Auth::user()->profile_image;}else{echo url('public/images/img-1.png');}?>" alt="avatar"
                                id="avatarIcon"/>  <i class="fas fa-caret-down text-white cursor-pointer"></i>
                            </div>    
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="avatarIcon">
                                <a class="dropdown-item" href="<?php echo e(route('my-profile')); ?>">
                                    <i class="far fa-user mr-1"></i> 
                                    <?php echo Auth::user()->user_type=='BUSINESS'?Auth::user()->business_name:Auth::user()->first_name; ?>
                                     <span class="caret"></span>
                                </a>
                                <a class="dropdown-item" href="javascript:void(0);">
                                    <i class="far fa-credit-card mr-1"></i> My Payments
                                </a>
                                <a class="dropdown-item" href="javascript:void(0);">
                                    <i class="far fa-address-card mr-1"></i> My Contracts
                                </a>
                                <?php if(Auth::user()->user_type=='BUSINESS'): ?>
                                <a class="dropdown-item" href="javascript:void(0);">
                                  <i class="far fa-edit mr-1"></i>  Reports
                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="javascript:void(0);">
                                  <i class="fas fa-gavel mr-1"></i>  Disputes
                                </a> 
                                <?php if(Auth::user()->user_type!='CLIENT'): ?>                              
                                <a class="dropdown-item" href="javascript:void(0);">
                                    <i class="far fa-clock mr-1"></i> My Availability
                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('my-subscribers')); ?>">
                                    <i class="fas fa-rss mr-1"></i> My Subscribers
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('my-favorites')); ?>">
                                   <i class="far fa-heart mr-1"></i> My Favorites
                                </a>
                                <?php if(Auth::user()->user_type=='BUSINESS'): ?>
                                <a class="dropdown-item" href="javascript:void(0);">
                                   <i class="far fa-user-circle mr-1"></i> My Team Members
                                </a>                                
                                <a class="dropdown-item" href="javascript:void(0);">
                                  <i class="far fa-share-square mr-1"></i>  Share Bar Code
                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="/settings/basic-info">
                                   <i class="fas fa-cog mr-1"></i>  Settings
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                   <i class="fas fa-sign-out-alt mr-1"></i> <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>    
            </nav>        
            <?php endif; ?> 
		<!-- header -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
<!-- loader -->
<div id="loader" class="loader-wrap">
    <div class="loader"></div>
</div>
<!-- loader --> 
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});  
$(document).ready(function(){
    $("#keyword").keyup(function(){
        var search_in = $("#search_in").val();
        if(search_in==''){search_in='all';}
        $.ajax({
            type:'GET',
            url:'/api/search-suggestion?search_in='+search_in+'&keyword='+$(this).val(),
            success:function(data){
                if(data.code==200 && data.data.length>0){
                    $("#keyword").autocomplete({
                        minLength: 3,
                        source: data.data,
                        classes: {
                            "ui-autocomplete": "cus-search",
                        },
                        response: function( event, ui ) {
                            if(ui.content.length>0){
                                ui.content.push({value:"Show All", id:0, label:"Show All"});
                            }else{
                                ui.content = ui.content.filter((item) => item.id !== 0);
                            }
                        },
                        select: function(e,item){ 
                            if(item.item.id==0){
                                $("#keyword").val($("#keyword").val());
                                $("#search_id").val("");
                                $("#search_type").val($("search_type").val());
                                $("#formSearch").submit();
                            } else{
                                $("#keyword").val(item.item.value);
                                $("#search_id").val(item.item.id);
                                $("#search_type").val(item.item.type);
                                $("#formSearch").submit();
                            } 
                        }                    
                    });                
                }
            }
        });
    });
});
function chnageSearchFor(search_in){
    if(search_in=='FREELANCER'){
        $('#keyword').attr('placeholder','Find Freelancer');
    }else if(search_in=='BUSINESS'){
        $('#keyword').attr('placeholder','Find Business');
    }
    $("#search_in").val(search_in);
    if($("#keyword").val()!=''){
        $("#formSearch").submit();
    }    
}
</script>
</body>
</html>
<?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>