
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-4">
        <form name="frmApplyJob" id="frmApplyJob" action="/apply-job" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                <h1 class="text-lg-left text-md-left text-sm-center text-center font-600">Apply Job</h1>                
            </div>
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-8  d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center mb-sm-0 mb-4">
                    <div class="d-flex">
                        <div class="w-100 overflow-hidden">
                            <h5 class="font-300 text-sm-left text-center"><?php echo e($jobDetails->job_title); ?></h5>
                            <div class="d-flex">
                                <div class="col-auto pl-0">
                                    <p class="text-muted"><i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($jobDetails->state_name); ?></p>
                                </div>
                                <div class="col-auto">
                                    <p class="text-muted"><?php echo e(ucfirst(strtolower($jobDetails->service_mode))); ?></p>
                                </div>
                                <div class="col-auto">
                                    <p class="text-muted">
                                        <?php
                                        if ($jobDetails->service_mode == 'FIXED') {
                                            if (empty($jobDetails->service_fixed_charge)) {
                                                echo 'NA';
                                            } else {
                                                echo "$" . $jobDetails->service_fixed_charge;
                                            }
                                        } else {
                                            if (empty($jobDetails->service_charges_low) || empty($jobDetails->service_charges_high)) {
                                                echo 'NA';
                                            } else {
                                                echo "$" . $jobDetails->service_charges_low . " - $" . $jobDetails->service_charges_high;
                                            }
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>
                            <div class="d-flex justify-content-sm-start justify-content-center">
                                <i class="fas fa-star mr-1 text-warning"></i>
                                <i class="fas fa-star mr-1 text-warning"></i>
                                <i class="fas fa-star mr-1 text-warning"></i>
                                <i class="fas fa-star mr-1 text-warning"></i>
                                <i class="fas fa-star mr-1 text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 text-lg-right text-md-right text-sm-right text-center">
                    <p class="font-500 text-muted"><?php echo e(GetTimeFromDateFormat($jobDetails->created_at)); ?></p>
                </div>
                <div class="col-lg-12 text-lg-left text-md-left text-sm-left text-center mt-4">
                    <h5 class="font-300">Job Description</h5>
                    <p><?php echo e($jobDetails->job_description); ?></p>
                </div>
            </div>
            <div class="row my-4">
                <div class="col-lg-12">
                    <div class="form-group">
                        <textarea class="form-control" rows="5" name="cover_letter" id="cover_letter" placeholder="Cover Letter"></textarea>
                        <span id="rcharst" class="text-right w-100 d-block mt-1"></span>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <?php if($jobDetails->service_mode=='FIXED'): ?>
                        <label>Please add your fixed price($)</label>
                        <?php else: ?>
                        <label>Please add your price per hour($)</label>
                        <?php endif; ?>
                        <input type="hidden" name="service_mode" id="service_mode" value="<?php echo e($jobDetails->service_mode); ?>">
                        <input type="text" class="form-control cus-input" name="price" id="price" placeholder="10">
                        <span class="text-muted mt-2 d-block">United Market will charge 10% fees.</span>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <label>Please select estimation time of completion</label>
                        <div class="select-style-left">
                            <select name="estimated_time_completion" id="estimated_time_completion">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <?php if($jobDetails->service_mode=='FIXED'): ?>
                <div class="col-lg-4 my-0 cusInputGroup">
                    <div class="input-group mb-3 rightArrow">                            
                    <input type="text" class="form-control" disabled="" aria-label="add Milstones" placeholder="Add Milestones">                            
                    <div class="input-group-append">
                        <a href="javascript:void();" id="milestone" onClick="openMileStoneModal()">
                            <span class="input-group-text h-100"><i class="fas fa-chevron-right"></i></span>
                        </a>
                    </div>
                </div>
                </div>
                <div class="col-lg-6 my-3">
                    <ul class="list-inline" id="added_milestone" style="display:none;">
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(count($jobDetails->questions)>0): ?>
                <div class="col-lg-12 my-4">                
                    <?php $__currentLoopData = $jobDetails->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label><?php echo e($question->question); ?></label>
                        <input type="hidden" name="questions[]" value="<?php echo e($question->id); ?>" />
                        <input type="text" name="answers[]" class="form-control cus-input" placeholder="Answer" />
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <div class="col-lg-12">
                    <div class="form-group">
                        <div class="border-dashed rounded d-flex align-items-center position-relative">
                            <input class="custom-file-input" type="file" id="fileInput" multiple size="50">
                            <div class="position-absolute divCenter text-muted">
                                <i class="fas fa-paperclip mr-3"></i>Attachments
                            </div>
                        </div>
                        <div class="d-flex">
                            <div class="mr-3">
                                <p id="demo"></p>
                            </div>
                        </div>
                        <div class="progress" style="display:none;">
                            <div class="progress-bar"></div>
                        </div>
                        <div id="uploadStatus"></div>
                        <input type="hidden" id="attachment_ids" name="attachment_ids" value="">
                    </div>
                </div>
            </div>
            <input type="hidden" name="milestones" id="milestones" value="">
            <div class="mt-3">
                <input type="hidden" name="job_id" id="job_id" value="<?php echo e($jobDetails->id); ?>">
                <?php if($jobDetails->isApplied==0): ?>
                <button id="submit" type="button" class="btn btn-dark btn-sm btn-block">Submit Proposal</button>
                <?php endif; ?>
            </div>
            <input type="hidden" name="milestone_total_ammount" id="milestone_total_ammount" value="0">            
            <div class="col-lg-12 my-4 text-center">
                <p>By applying job Application, you agree to our <a href="#">Privacy Policy</a> and <a href="#">Terms of Use</a></p>
            </div>
        </form>
    </div>
</div>
<!-- content section-->
<!--Modal-->
<div class="modal fade" id="milestoneModal" tabindex="-1" role="dialog" aria-labelledby="milestoneModallLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:800px !important;">
        <div class="modal-content">
            <div class="modal-header px-4 pb-0">
                <h4 class="mt-2">Add milestones</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="col-lg-12 mt-3">
                <div class="row px-2">
                    <div class="col-lg-6">
                        <label>Total Budget</label>
                        <div class="input-group mb-3">                            
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="text" class="form-control" name="total_budget" id="total_budget" readonly value="">
                        </div>
                        <div class="alert-red alert alert-danger mt-2 p-1 text-white small">
                            50% Amount will be added in Escrow
                        </div>
                        <div class="form-group">
                            <label>Title</label>
                            <input type="text" class="form-control" placeholder="Title" name="milestone_title" id="milestone_title" />
                        </div>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="text" class="form-control" mame="milestone_price" id="milestone_price">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Date" id="milestone_date" name="milestone_date" autocomplete="off"/>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <textarea class="form-control" rows="4" placeholder="Description" name="milestone_description" id="milestone_description"></textarea>
                        </div>
                        <div class="input-group mb-3 rightArrow">                            
                            <input type="text" class="form-control" disabled aria-label="add Milstones" placeholder="Add More Milestones">                            
                            <div class="input-group-append">
                                <a href="javascript:void(0);" onclick="AddMileStone(0);">
                                    <span class="input-group-text h-100"><i class="fas fa-chevron-right"></i></span>
                                </a>
                            </div>
                        </div>
                        <button type="button" class="btn btn-dark btn-sm btn-block" onClick="AddMileStone(1);">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Modal-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function(){
        var wordLen = 700,len;
        len = $('#cover_letter').val().split(/[\s]+/);
        wordsLeft = (wordLen) - len.length;
        if($('#cover_letter').val()==''){
            $('#rcharst').html('700 Word(s) left');
        }else if(wordsLeft==700){
            $('#rcharst').html(wordsLeft+" Words");
        }else{
            $('#rcharst').html(wordsLeft+' Word(s) left');
        }
        $("#milestone_date").datepicker({
            minDate: 0,
            changeMonth: true,
            changeYear: true
        });
    });
    $("#fileInput").change(function() {
        var allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.ms-office', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        var file = this.files[0];
        var fileType = file.type;
        if (!allowedTypes.includes(fileType)) {
            alert('Please select a valid file (PDF/DOC/DOCX/JPEG/JPG/PNG/GIF).');
            $("#fileInput").val('');
            return false;
        } else {
            $('.progress').show();
            var file = this.files[0];
            var formData = new FormData();
            formData.append("media_files[]", file);
            $.ajax({
                xhr: function() {
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function(evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = parseInt((evt.loaded / evt.total) * 100);
                            $(".progress-bar").width(percentComplete + '%');
                            $(".progress-bar").html(percentComplete + '%');
                        }
                    }, false);
                    return xhr;
                },
                type: 'POST',
                url: '/api/upload-medias',
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function() {
                    $(".progress-bar").width('0%');
                    //$('#uploadStatus').html('<img src="images/loading.gif"/>');
                },
                error: function() {
                    $('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
                },
                success: function(resp) {
                    if (resp.code == 200) {
                        $('.progress').hide();
                        var media_id = resp.media_ids;
                        var media_files = resp.media_files;
                        if ($('#attachment_ids').val() != '') {
                            $('#attachment_ids').val($('#attachment_ids').val() + ',' + media_id[0]);
                        } else {
                            $('#attachment_ids').val(media_id[0]);
                        }
                        //$('#fileInput')[0].reset();
                        var deleteImage = '<a class="d-flex align-self-center" href="javascript:void(0);" onclick="removeImage(' + media_id[0] + ')"><i class="fas fa-times-circle text-dark ml-1"></i></a>';
                        $('#uploadStatus').append('<p id="attachment_id_' + media_id[0] + '" class="d-flex align-items-center docStyle text-success">' + '<i class="fas fa-file mr-2"></i>' + media_files[0] + '&nbsp;' + deleteImage + '</p>');
                    } else if (resp.code == 401) {
                        $('#uploadStatus').html('<p class="text-dark">Please select a valid file to upload.</p>');
                    }
                }
            });
        }
    });

    function removeImage(image_id) {
        $('#attachment_id_' + image_id).remove();
        var value = image_id;
        var arr = $("#attachment_ids").val().split(",");
        arr = arr.filter(function(item) {
            return item != value;
        });
        $("#attachment_ids").val(arr.join(","));
        $.ajax({
            type: 'DELETE',
            url: '/api/delete-media/' + image_id,
            async: false,
            success: function(data) {
                if (data.code == 200) {}
            }
        });
    }
    function openMileStoneModal(){
        if ($("#price").val() == '') {
            alert("Please enter price");
            $("#price").focus();
            return false;
        }else{
            $("#total_budget").val($("#price").val());
            $("#milestoneModal").modal();
        }
    }
    function AddMileStone(is_close_popup){
        if ($("#milestone_price").val()!='') {
            var milestone_total_ammount = parseInt($("#milestone_total_ammount").val())+parseInt($("#milestone_price").val());
        }
        if ($("#milestone_title").val() == '') {
            alert("Please enter title");
            $("#milestone_title").focus();
            return false;
        }else if ($("#milestone_price").val() == '') {
            alert("Please enter price");
            $("#milestone_price").focus();
            return false;
        } else if ($("#milestone_date").val() == '') {
            alert("Please enter date");
            $("#milestone_date").focus();
            return false;
        } else if ($("#milestone_description").val() == '') {
            alert("Please enter description");
            $("#milestone_description").focus();
            return false;
        }else if(milestone_total_ammount>$("#price").val()){
            alert("You can not enter milestones amount greater than total amount.");
            $("#milestone_price").focus();
            return false;
        }else{   
            $("#milestone_total_ammount").val(milestone_total_ammount);    
            var addedMilestones = $("#milestones").val();
            if(addedMilestones=='' || addedMilestones==undefined){
                var mileStones = [];
                var id = 1;
                var milestone = {id:id,title:$("#milestone_title").val(),price:$("#milestone_price").val(),date:$("#milestone_date").val(),description:$("#milestone_description").val()};
                mileStones.push(milestone);
                var mstone = JSON.stringify(mileStones);
                $("#milestones").val(mstone);
            }else{
                addedMilestones = JSON.parse(addedMilestones);
                var length = addedMilestones.length;
                var id = parseInt(length)+1;
                var milestone = {id:id,title:$("#milestone_title").val(),price:$("#milestone_price").val(),date:$("#milestone_date").val(),description:$("#milestone_description").val()};
                addedMilestones.push(milestone);
                var mstone = JSON.stringify(addedMilestones);
                $("#milestones").val(mstone); 
            }            
            $("#milestone").val(milestone);
            $("#added_milestone").show(); 
            var added_milestone = '<li id="milestone_li_id_'+id+'" class="bg-light p-2 mb-2 rounded">'+id+') '+$("#milestone_title").val()+' - $'+$("#milestone_price").val()+' - '+$("#milestone_date").val();
            added_milestone += '&nbsp;&nbsp;<span style="float:right;"><a class="text-dark" href="javascript:void(0);" onClick="deleteMilestone('+id+')"><i class="fas fa-times-circle"></i></a><span></li>';
            $("#added_milestone").append(added_milestone);
            $("#milestone_title").val("");
            $("#milestone_price").val("");
            $("#milestone_date").val("");
            $("#milestone_description").val("");
            alert("Milestone added.");
            if(is_close_popup==1){
                $(".close").trigger("click");
            }
        }
    }
    $('#submit').click(function() {
        var answers = [];
        var total_questions = 0;
        $("input[name='answers[]']").each(function() {
            if ($(this).val()) {
                answers.push($(this).val());
            }
            total_questions = total_questions + 1;
        });
        if ($("#cover_letter").val() == '') {
            alert("Please enter cover letter");
            $("#cover_letter").focus();
            return false;
        } else if ($("#price").val() == '') {
            alert("Please select price");
            $("#price").focus();
            return false;
        } else if ($("#estimated_time_completion").val() == '') {
            alert("Please select estimated time of completion");
            $("#estimated_time_completion").focus();
            return false;
        } else if (answers.length < total_questions) {
            alert("Please write all answers");
            return false;
        } else {
            //$('#loader').show();
            var formPostData = $('#frmApplyJob').serialize();            
            $.ajax({
                type: 'POST',
                url: '/apply-job',
                data: formPostData,
                async: false,
                success: function(data) {
                    if (data.code == 200) {
                        alert("You have successfully applied for this job");
                        window.location.href = home_path;                       
                    } else if (data.code == 211) {
                        alert("You have already applied for this job");
                        window.location.href = home_path;
                    }
                }
            });
        }
    });
    $('#price,#milestone_price').keydown(function(event) {
        if (event.keyCode == 46 || event.keyCode == 8) {} else {
            if (event.keyCode < 48 || event.keyCode > 57) {
                event.preventDefault();
            }
        }
    });
    function SaveJob(job_id){
        var formPostData = {job_id:job_id};
        $.ajax({
            type:'POST',
            url:'/save-job',
            data:formPostData,
            async: false,
            success:function(data){
                if(data.code==200){
                    $("#save_job_span").html('<i class="fas fa-bookmark"></i>');
                }
            }
        });
    }
    var wordLen = 700,len;
    $('#cover_letter').keyup(function(event) {    
        if($(this).val()==''){
            $('#rcharst').html(wordLen+' Words');
        }else{
            var words = $(this).val().match(/\S+/g).length;
            if (words > 700) {
                var trimmed = $(this).val().split(/\s+/, 700).join(" ");
                $(this).val(trimmed + " ");
            }
            else {
                var wordsLeft = wordLen - words;
                if(wordsLeft<=0){
                    $('#rcharst').css({'color':'red'}).prepend('<i class="fa fa-exclamation-triangle"></i>');
                }else{
                    $('#rcharst').css({'color':'black'})
                }
                $('#rcharst').html(wordsLeft+' Word(s) left');
            }    
        }    
    });
    function deleteMilestone(id){
        $("#milestone_li_id_"+id).remove();
        var value = id;
        var addedMilestones = $("#milestones").val();
        addedMilestones = JSON.parse(addedMilestones);
        var data = $.grep(addedMilestones, function(e){ 
            return e.id != id; 
        });
        if(data.length>0){
            var mileStones = [];
            $("#added_milestone").html("");
            var milestone_total_ammount = 0;
            for (var i = 0, l = data.length; i < l; i++) {
                var k=i+1;
                var obj = data[i];
                var added_milestone = '<li id="milestone_li_id_'+k+'" class="bg-light p-2 mb-2 rounded">'+k+') '+obj.title+' - $'+obj.price+' - '+obj.date;
                added_milestone += '&nbsp;&nbsp;<span style="float:right;"><a class="text-dark" href="javascript:void(0);" onClick="deleteMilestone('+k+')"><i class="fas fa-times-circle"></i></a><span></li>';            
                var milestone = {id:k,title:obj.title,price:obj.price,date:obj.date,description:obj.description};            
                mileStones.push(milestone);
                $("#added_milestone").append(added_milestone);
                milestone_total_ammount = milestone_total_ammount+parseInt(obj.price)
            } 
            var mstone = JSON.stringify(mileStones);
            $('#milestones').val(mstone);
            $('#milestone_total_ammount').val(milestone_total_ammount);
        }
    }
</script>
<!-- Footer section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/job/apply-job.blade.php ENDPATH**/ ?>