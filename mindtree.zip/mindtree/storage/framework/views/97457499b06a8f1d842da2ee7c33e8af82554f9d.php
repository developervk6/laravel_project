<?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
<div class="col-lg-3 pt-0 px-4 pb-3 pt-lg-0 pt-md-4 pt-sm-4 pt-4 mt-lg-2 mt-md-0 border-md-top-1">
    <div class="mb-4">
        <h5 class="mb-0">Availability</h5>
        <p><?php echo e($user->availability_hours); ?></p>
    </div>
    <div class="mb-4">
        <h5 class="mb-0">Spl Availability</h5>
        <p class="mb-0 text-secondary font-300">New Jersey, Photoshoots</p>
        <p class="h5 font-300 text-muted">25-03-2020 to 30-03-2020</p>
    </div>
    <?php if(Auth::user()->id!=$user->id): ?>
    <div class="mb-4">
        <button type="button" class="btn btn-dark btn-sm btn-block" data-toggle="modal" data-target="#inviteMember">Invite</button>
    </div>
    <div class="mb-4 text-center">
        <p class="mb-0">Or</p>
    </div>    
    <div class="mb-4">
        <button type="button" class="btn btn-dark btn-sm btn-block">Accept Proposal</button>
    </div>
    <div class="mb-4">
        <button type="button" class="btn btn-sm btn-outline-secondary btn-block">Decline Proposal</button>
    </div>
    <?php endif; ?>
</div>

<!-- Modal -->
<div class="modal fade" id="inviteMember" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Send Invite</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php if(count($user->active_jobs)>0): ?>
                <form>
                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control cus-input" placeholder="Write Message"></textarea>
                    </div>  
                    <div class="form-group">
                        <select name="job_id" id="job_id" class="form-control">
                            <option value="">Select Job</option>                            
                            <?php $__currentLoopData = $user->active_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($job->id); ?>"><?php echo e($job->job_title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>  
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user->id); ?>">
                            <button type="button" id="btnInviteMember" class="btn btn-dark btn-sm btn-block">Invite</button>                            
                        </div>
                    </div>                                   
                </form>  
                <?php else: ?>
                    <div class="form-group text-center">
                        You didn't post any job yet<br>
                        Please create job to invite candidate.
                    </div> 
                    <div class="row">
                        <div class="col-lg-12">
                            <a class="btn btn-dark btn-sm btn-block my-4" href="<?php echo e(route('create-job')); ?>">Create Job</a>
                        </div>
                    </div>
                <?php endif; ?>              
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<?php else: ?>
<div class="col-lg-3 pt-0 px-4 pb-3 pt-lg-0 pt-md-4 pt-sm-4 pt-4 mt-lg-2 mt-md-0 border-md-top-1">
    <div class="mb-4">
        Member since <?php echo e(date('M d, Y',strtotime($user->created_at))); ?>

    </div>

    <?php if($user->is_payment_setup_done==1): ?>
    <div class="mb-4 bg-success rounded p-1 text-white text-center">
        Payment method is verified
    </div>
    <?php else: ?>
    <div class="alert-red mb-4 alert-danger rounded p-1 text-white text-center">
        Payment method is not verified
    </div>
    <?php endif; ?>
    <?php if(Auth::user()->id!=$user->id): ?>
    <div class="mb-4">
        <?php if($user->is_blocked==0): ?>
            <a href="javascript:void(0);" onClick="BlockUnBlock(<?php echo e($user->id); ?>);" class="text-muted">Block</a>
        <?php else: ?>
            Blocked 
        <?php endif; ?>
    </div>
    <div class="mb-4">
        <a href="javascript:void(0);" onClick="ReportUser();" class="text-muted">Report</a>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/profile-right.blade.php ENDPATH**/ ?>