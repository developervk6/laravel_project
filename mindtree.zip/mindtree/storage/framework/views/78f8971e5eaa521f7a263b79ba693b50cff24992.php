
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <?php if($MyJobs->total()): ?>
    <?php $__currentLoopData = $MyJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white shadow rounded p-4">
        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
        <?php if($loop->first): ?>
        <h1 class="text-lg-left text-md-left text-sm-center text-center font-600 mb-4">My Jobs</h1>
        <?php else: ?>
        <h1 class="d-none">&nbsp;</h1>
        <?php endif; ?>
        <input type="hidden" id="job_status" value="<?php echo e($jobDetails->status); ?>">
        </div>                
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-8  d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center mb-sm-0 mb-4">
                <div class="d-flex">
                    <div class="w-100 overflow-hidden">
                        <h5 class="font-300"><?php echo e($jobDetails->job_title); ?></h5>                        
                        <div class="d-flex">
                            <div class="col-auto pl-0">
                                <p class="text-muted"><i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($jobDetails->state_name); ?></p>
                            </div>
                            <div class="col-auto">
                                <p class="text-muted"><?php echo e(ucfirst(strtolower($jobDetails->service_mode))); ?></p>
                            </div>
                            <div class="col-auto">
                            <p class="text-muted">
                            <?php 
                                if($jobDetails->service_mode=='FIXED'){
                                    if(empty($jobDetails->service_fixed_charge)){
                                        echo 'NA';
                                    }else{
                                        echo "$".$jobDetails->service_fixed_charge; 
                                    }                                                       
                                }else{
                                    if(empty($jobDetails->service_charges_low) || empty($jobDetails->service_charges_high)){
                                        echo 'NA';
                                    }else{
                                        echo "$".$jobDetails->service_charges_low." - $".$jobDetails->service_charges_high;
                                    }
                                } 
                            ?>
                            </p>
                            </div>
                        </div>
                        <div class="d-flex justify-content-sm-start justify-content-center">
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                        </div>
                    </div>
                </div>                
            </div>                        
            <div class="col-lg-4 col-md-4 col-sm-4 text-lg-right text-md-right text-sm-right text-center">                    
                <p><b><?php echo e(ucfirst(strtolower($jobDetails->status))); ?></b></p>
                <i class="fas fa-ellipsis-v fa-1x cursor-pointer" data-toggle="dropdown"></i>
                <div class="dropdown-menu dropdown-menu-right shadow-sm cus-rounded py-0 myJobs" style="top:0px !important;">
                    <a class="dropdown-item text-center" href="javascript:void(0);" onClick="ArchiveJob(<?php echo e($jobDetails->id); ?>);"><?php if($jobDetails->status=='OPEN'): ?> Archive <?php else: ?> Unarchive <?php endif; ?></a>
                    <a class="dropdown-item text-center" href="javascript:void(0);" onClick="DeleteJob(<?php echo e($jobDetails->id); ?>);">Delete</a>
                </div>  
            </div>
            <div class="col-lg-12 text-lg-left text-md-left text-sm-left text-center mt-4">
                <h5 class="font-300">Job Description</h5>
                <p><?php echo e($jobDetails->job_description); ?></p>
            </div>
            <?php if(count($jobDetails->questions)>0): ?>
            <div class="col-lg-12 text-sm-left text-center">
                <p>Questions</p>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center">
                <ul class="list-inline w-50">
                    <?php $__currentLoopData = $jobDetails->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-light p-2 mb-2 rounded"> <?php echo e($loop->iteration); ?>) <?php echo e($question->question); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(count($jobDetails->attachments)>0): ?>
            <div class="col-lg-12 text-sm-left text-center">
                <p>Attachments</p>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center">
                    <ul class="list-inline">   
                       
                            <?php $__currentLoopData = $jobDetails->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $image = !empty($attachment->thumbnail)?$attachment->thumbnail:$attachment->media_file;?>
                                <a href="<?php echo e($attachment->media_file); ?>" target="_blank">
                                    <li class="file-box list-inline-item" style="background-image:url('<?php echo e($image); ?>');"></li>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               
                    </ul>
            </div>
            <?php endif; ?>           
        </div>
        <div class="row bg-light pt-4 px-5">   

            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">Location Desired</p>
                <span class="text-muted small"><?php echo e($jobDetails->desired_location); ?></span>
            </div>           
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">Job Type</p>
                <span class="text-muted small"><?php echo e($jobDetails->sub_category); ?></span>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">Expert Level</p>
                <span class="text-muted small"><?php echo e(ucfirst(strtolower($jobDetails->expertise_level))); ?></span>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">For Location</p>
                <span class="text-muted small"><?php echo e($jobDetails->current_location); ?></span>
            </div>
        </div>
        <div class="row bg-light pb-4 px-5">
            <div class="col-lg-8 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-2">Skills</p>
                <?php if(!empty($jobDetails->tags)): ?>
                    <?php $__currentLoopData = $jobDetails->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="text-muted small bg-secondary-50 rounded px-2 py-1 my-2"><?php echo e($tag->tag); ?></span>&nbsp;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>       
    </div>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <div class="bg-white shadow rounded p-4">
    <h1 class="text-lg-left text-md-left text-sm-center text-center font-600">My Jobs</h1>
        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">        
            No jobs found
        </div>
    </div>
    <?php endif; ?>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
function ArchiveJob(job_id){
    var job_status = $("#job_status").val();
    var formPostData = {job_id:job_id};
    $.ajax({
        type:'POST',
        url:'/api/archive-job',
        data:formPostData,
        async: false,
        success:function(data){
            if(data.code==200){
                if(job_status=='OPEN'){
                    alert("Archived successfully");
                }else{
                    alert("Unarchived successfully");
                }
                window.location.href=document.URL;               
            }
        }
    });
}
function DeleteJob(job_id){    
    if(confirm("Are you sure you want to delete this job?")){
        $.ajax({
            type:'DELETE',
            url:'/api/delete-job/'+job_id,
            async: false,
            success:function(data){
                if(data.code==200){
                    alert("Deleted successfully");
                    window.location.href=document.URL;               
                }
            }
        });
    }
}
</script>
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/job/my-jobs.blade.php ENDPATH**/ ?>