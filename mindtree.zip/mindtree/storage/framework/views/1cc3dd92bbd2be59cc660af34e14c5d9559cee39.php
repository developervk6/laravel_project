
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" role="tab" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link active" id="nav-about-tab" href="/settings/education" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">                                          
                                        <div class="tab-pane fade show active" id="education" role="tabpanel" aria-labelledby="nav-about-tab">
                                                <!-- note -->
                                                <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                    <div
                                                        class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                        <p class="text-dark mb-0">Note: <span
                                                                class="text-muted">To make changes in your
                                                                Education please click on edit button</span></p>
                                                        <a role="button" class="btn btn-dark text-white"
                                                            data-toggle="modal" data-target="#basicProfile">
                                                            <span
                                                                class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                    class="fas fa-pen text-dark"></i></span>
                                                            Edit</a>
                                                    </div>
                                                </div>
                                                <!-- note -->
                                                <!-- section 1 -->
                                                <div class="border rounded my-4 p-3" id="education_list">
                                                    <?php if(count($user->educations)>0): ?>
                                                        <?php $__currentLoopData = $user->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="eduRowClass" id="education_row_<?php echo e($education->id); ?>">
                                                            <div class="d-flex align-items-center">
                                                                <h5 class="font-300 mr-2"><?php echo e($education->institute_name); ?></h5>
                                                                <span>
                                                                    <a href="javascript:void(0);" onClick="editEducation(<?php echo e($education->id); ?>)">
                                                                        <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-2"></i>
                                                                    </a>
                                                                </span>
                                                                <span>
                                                                    <a href="javascript:void(0);" onClick="deleteEducation(<?php echo e($education->id); ?>)">
                                                                        <i class="fas fa-window-close cursor-pointer text-dark fa-lg ml-1"></i>
                                                                    <a>
                                                                </span>
                                                            </div>
                                                            <p class="small text-muted-50"><?php echo e($education->description); ?></p>
                                                            <div class="d-flex">
                                                                <p class="font-bold mr-5"><?php echo e(date("M Y",strtotime($education->from_date))); ?></p>
                                                                <p class="font-bold"><?php echo e(date("M Y",strtotime($education->to_date))); ?></p>
                                                            </div>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                    <div id="no_education">You have not added education.</div>
                                                    <?php endif; ?>                                                            
                                                </div>
                                                <!-- section 1 -->
                                                <!-- section 2-->
                                                <div class="border my-4 rounded p-4">
                                                    <div
                                                        class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                                                        <p class="font-bold mb-sm-0 mb-2">Want to add new education?</p>
                                                        <a href="javascript:void(0);" class="btn btn-dark text-white" data-toggle="modal" data-target="#educationModal">
                                                            <i class="fas fa-plus-circle mr-1"></i> Add
                                                        </a>
                                                    </div>
                                                </div>
                                                <!-- section 2-->                                                        
                                            </div>                                                       
                                        </div>
                                    </div>
                                </section>
                                <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<!-- Modal Add education-->
<div class="modal fade" id="educationModal" tabindex="-1" role="dialog" aria-labelledby="educationlabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Education</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body px-5 pb-5">
                <p class="text-muted-50">Please provide your education details</p>
                <form method="POST" action="" id="ExpForm">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Institute Name</label>
                        <input type="text" id="institute_name" name="institute_name" class="form-control cus-input" placeholder="Institute Name"/>
                    </div>
                    <div class="form-group">
                        <label>Degree Name</label>
                        <input type="text" id="degree_name" name="degree_name" class="form-control cus-input" placeholder="Degree Name"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="institute_description" name="institute_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="education_from" autocomplete="off"/>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="education_to" autocomplete="off"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnAddNewEducation" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal Add education End-->
<!-- Modal Edit education-->
<div class="modal fade" id="edit_education_modal" tabindex="-1" role="dialog" aria-labelledby="educationEditlabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Edit Education</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body px-5 pb-5">
                <p class="text-muted-50">Please provide your education details</p>
                <form method="POST" action="" id="EditEducationForm">
                <input type="hidden" id="education_id" value=""/>
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Institute Name</label>
                        <input type="text" id="edit_institute_name" name="edit_institute_name" class="form-control cus-input" placeholder="Institute Name"/>
                    </div>
                    <div class="form-group">
                        <label>Degree Name</label>
                        <input type="text" id="edit_degree_name" name="edit_degree_name" class="form-control cus-input" placeholder="Degree Name"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="edit_institute_description" name="institute_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="edit_education_from" autocomplete="off"/>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="edit_education_to" autocomplete="off"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnEditEducation" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal Edit education End-->
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    $('#education_from').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'
    });
    $('#education_to').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });  
    $('#edit_education_to').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });  
    $('#edit_education_from').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });   
});

$('#btnAddNewEducation').click(function(e){
    e.preventDefault();
    if($('#institute_name').val()==''){
        alert("Please enter institute name.");
        $('#institute_name').focus();
        return false;
    }else if($('#degree_name').val()==''){
        alert("Please enter degree name.");
        $('#degree_name').focus();
        return false;
    }else if($('#institute_description').val()==''){
        alert("Please enter description.");
        $('#institute_description').focus();
        return false;
    }else if($('#education_from').val()==''){
        alert("Please select from date.");
        $('#education_from').focus();
        return false;
    }else if($('#education_to').val()==''){
        alert("Please select to date.");
        $('#education_to').focus();
        return false;
    }else if($('#education_from').val()>=$('#education_to').val()){
        alert("Invalid from/to date.");
        $('#education_from').focus();
        return false;
    }else{
        var institute_name = $("#institute_name").val();
        var degree_name = $("#degree_name").val();
        var description = $("#institute_description").val();
        var from_date = $("#education_from").val();                   
        var to_date = $("#education_to").val();
        var formData = {institute_name:institute_name,degree_name:degree_name,description:description,from_date:from_date,to_date:to_date};     
        $.ajax({
            type:'POST',
            url:'/AddUserEducation',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL; 
                }
            }
        });
    }
});
function deleteEducation(education_id){
    if(confirm("Are you sure you want to delete this?")){
        $.ajax({
            type:'GET',
            url:'/api/delete-education/'+education_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    window.location.href=document.URL;      
                }
            }
        });
    }
}
function editEducation(education_id){
    $.ajax({
        type:'GET',
        url:'/api/education-details/'+education_id,
        async: false,
        success:function(data){
            if(data.code==200){ 
                $("#education_id").val(education_id);  
                $("#edit_institute_name").val(data.data.institute_name);
                $("#edit_degree_name").val(data.data.degree_name);
                $("#edit_institute_description").val(data.data.description); 
                $("#edit_education_from").val(data.data.from_date); 
                $("#edit_education_to").val(data.data.to_date);   
                $("#edit_education_modal").modal();       
            }
        }
    });
}
$('#btnEditEducation').click(function(e){
    e.preventDefault();
    if($('#edit_institute_name').val()==''){
        alert("Please enter institute name.");
        $('#edit_institute_name').focus();
        return false;
    }else if($('#edit_degree_name').val()==''){
        alert("Please enter degree name.");
        $('#edit_degree_name').focus();
        return false;
    }else if($('#edit_institute_description').val()==''){
        alert("Please enter description.");
        $('#edit_institute_description').focus();
        return false;
    }else if($('#edit_education_from').val()==''){
        alert("Please select from date.");
        $('#edit_education_from').focus();
        return false;
    }else if($('#edit_education_to').val()==''){
        alert("Please select to date.");
        $('#edit_education_to').focus();
        return false;
    }else if($('#edit_education_from').val()>=$('#edit_education_to').val()){
        alert("Invalid from/to date.");
        $('#edit_education_from').focus();
        return false;
    }else{
        var id = $("#education_id").val();
        var institute_name = $("#edit_institute_name").val();
        var degree_name = $("#edit_degree_name").val();
        var description = $("#edit_institute_description").val();
        var from_date = $("#edit_education_from").val();                   
        var to_date = $("#edit_education_to").val();
        var formData = {id:id,institute_name:institute_name,degree_name:degree_name,description:description,from_date:from_date,to_date:to_date};     
        $.ajax({
            type:'POST',
            url:'/EditUserEducation',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL; 
                }
            }
        });
    }
});
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/education.blade.php ENDPATH**/ ?>