<?php $__env->startSection('content'); ?>
    <!-- slider -->
    <div id="carouselExampleIndicators" class="home carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner h-100">
            <div class="carousel-item active h-100">
                <div class="position-relative h-100">
                <img class="w-100" src="public/images/1.png" alt="First slide">
                <div class="position-absolute sliderContent text-white">
                    <div class="container h-100">
                        <div class="d-table h-100 w-100 text-sm-left text-center">
                            <div class="w-100 h-100" style="display: table-cell; vertical-align: middle;">
                            <h2 class="text-uppercase font-300">Join the business</h2>
                            <h1 class="text-uppercase display-4 d-inline-block border-bottom-trans pb-sm-3 pb-1 font-500">Platform of the future</h1>
                            <p class="h4 mb-sm-5 mb-2 font-300">Enterepreneurs &amp business owners worldwide</p>
                            <a href="#" role="button" class="btn btn-light btn-arrow text-dark px-sm-4 py-sm-3 px-3 py-2 cus-rounded-sm font-500">Get Started</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="carousel-item h-100">
                <div class="position-relative h-100">
                <img class="w-100" src="public/images/2.png" alt="First slide">
                <div class="position-absolute sliderContent text-white">
                    <div class="container h-100">
                        <div class="d-table h-100 text-sm-left text-center">
                            <div class="w-100 h-100" style="display: table-cell; vertical-align: middle;">
                            <h2 class="text-uppercase font-300">Join the business</h2>
                            <h1 class="text-uppercase display-4 d-inline-block border-bottom-trans pb-sm-3 pb-1 font-500">Platform of the future</h1>
                            <p class="h4 mb-sm-5 mb-2 font-300">Enterepreneurs &amp business owners worldwide</p>
                            <a href="#" role="button" class="btn btn-light btn-arrow text-dark px-sm-4 py-sm-3 px-3 py-2 cus-rounded-sm font-500">Get Started</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="carousel-item h-100">
                <div class="position-relative h-100">
                <img class="w-100" src="public/images/3.png" alt="First slide">
                <div class="position-absolute sliderContent text-white">
                    <div class="container h-100">
                        <div class="d-table h-100 text-sm-left text-center">
                            <div class="w-100 h-100" style="display: table-cell; vertical-align: middle;">
                            <h2 class="text-uppercase font-300">Join the business</h2>
                            <h1 class="text-uppercase display-4 d-inline-block border-bottom-trans pb-sm-3 pb-1 font-500">Platform of the future</h1>
                            <p class="h4 mb-sm-5 mb-2 font-300">Enterepreneurs &amp business owners worldwide</p>
                            <a href="#" role="button" class="btn btn-light btn-arrow text-dark px-sm-4 py-sm-3 px-3 py-2 cus-rounded-sm font-500">Get Started</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <!-- <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a> -->
    </div>
    <!-- slider -->
    <!-- hyper local -->
    <div class="bg-light mobile-font border-bottom p-5">
        <div class="container">
            <h2 class="text-uppercase text-center text-dark mb-sm-5 mb-4">Hyper Local - Business Management - Service
                Fulfillment</h2>
            <div class="row">
                <div class="col-lg-4 d-flex flex-column justify-content-center align-items-center border-right border-right-sm-0 mb-lg-0 mb-sm-4 mb-3">
                    <h2 class="text-dark">2256,3</h2>
                    <p class="mb-0 text-muted">Jobs Added</p>
                </div>
                <div class="col-lg-4 d-flex flex-column justify-content-center align-items-center border-right border-right-sm-0 mb-lg-0 mb-sm-4 mb-3">
                    <h2 class="text-dark">1560,2</h2>
                    <p class="mb-0 text-muted">Active Freelancers</p>
                </div>
                <div class="col-lg-4 d-flex flex-column justify-content-center align-items-center">
                    <h2 class="text-dark">2500</h2>
                    <p class="mb-0 text-muted">Business</p>
                </div>
            </div>
        </div>
    </div>
    <!-- hyper local -->
    <!-- polular-jobs -->
    <div class="container mobile-font">
        <h2 class="text-uppercase text-center text-dark mt-5 mb-3">Popular Jobs Right Now</h2>
        <p class="mb-5 text-center text-muted h5 font-300">A better career is out there. We'll help you find it. We're
            your first step to becoming everthing you want to be.</p>
        <div class="row mb-sm-5 mb-2">
            <div class="col-lg-3 col-md-3 col-sm-6 col-12 mb-lg-0 mb-sm-4 mb-4">
                <div class="card shadow cus-rounded">
                    <img class="card-img-top rounded-top-right" src="public/images/img-1.png" alt="img">
                    <div class="position-absolute brand-logo">
                        <img class="rounded-circle" src="public/images/vouge_logo.png" alt="brand logo" />
                    </div>
                    <div class="card-body">
                        <div class="card-text">
                            <div class="d-flex justify-content-between">
                                <h5 class="text-uppercase">Vogue Usa</h5>
                                <p class="text-muted"><i class="fas fa-map-marker-alt"></i> New York</p>
                            </div>
                            <div class="text-muted">
                                <p>2+ Jobs Open <br /> for Fashion Photographer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-12 mb-lg-0 mb-sm-4 mb-4">
                <div class="card shadow cus-rounded">
                    <img class="card-img-top rounded-top-right" src="public/images/img-1.png" alt="img">
                    <div class="position-absolute brand-logo">
                        <img class="rounded-circle" src="public/images/infosys_logo.png" alt="brand logo" />
                    </div>
                    <div class="card-body">
                        <div class="card-text">
                            <div class="d-flex justify-content-between">
                                <h5 class="text-uppercase">Vogue Usa</h5>
                                <p class="text-muted"><i class="fas fa-map-marker-alt"></i> New York</p>
                            </div>
                            <div class="text-muted">
                                <p>2+ Jobs Open <br /> for Fashion Photographer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-12 mb-lg-0 mb-sm-4 mb-4">
                <div class="card shadow cus-rounded">
                    <img class="card-img-top rounded-top-right" src="public/images/img-1.png" alt="img">
                    <div class="position-absolute brand-logo">
                        <img class="rounded-circle" src="public/images/vouge_logo.png" alt="brand logo" />
                    </div>
                    <div class="card-body">
                        <div class="card-text">
                            <div class="d-flex justify-content-between">
                                <h5 class="text-uppercase">Vogue Usa</h5>
                                <p class="text-muted"><i class="fas fa-map-marker-alt"></i> New York</p>
                            </div>
                            <div class="text-muted">
                                <p>2+ Jobs Open <br /> for Fashion Photographer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-12 mb-lg-0 mb-sm-4 mb-4">
                <div class="card shadow cus-rounded position-relative">
                    <img class="card-img-top rounded-top-right" src="public/images/img-1.png" alt="img">
                    <div class="position-absolute brand-logo">
                        <img class="rounded-circle" src="public/images/infosys_logo.png" alt="brand logo" />
                    </div>
                    <div class="card-body">
                        <div class="card-text">
                            <div class="d-flex justify-content-between">
                                <h5 class="text-uppercase">Vogue Usa</h5>
                                <p class="text-muted"><i class="fas fa-map-marker-alt"></i> New York</p>
                            </div>
                            <div class="text-muted">
                                <p>2+ Jobs Open <br /> for Fashion Photographer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3 m-auto">
            <a role="button" class="btn btn-success btn-block btn-lg text-uppercase text-white btn-arrow py-3 h4 mb-5">View More</a>
        </div>
    </div>
    <!-- polular-jobs -->

    <!-- TESTIMONIALS -->
<section class="testimonials bg-light p-5 border-top">
	<div class="container">
      <div class="row">
        <div class="col-sm-12 mobile-font">
            <h2 class="text-center mb-4">What Our Users Say</h2>
            <p class="text-center h5 mb-4 font-300">We Collect reviews from our users so you can get honest opinion of what an experience with our <br/> <strong>Website</strong> and <strong>App</strong> are really like</p>
          <div id="customers-testimonials" class="owl-carousel">

            <!--TESTIMONIAL 1 -->
            <div class="item">
              <div class="quoted-testimonial">
                <p class="mb-0">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate.</p>
              </div>
              <img class="rounded-circle" src="https://themes.audemedia.com/html/goodgrowth/images/testimonial3.jpg" alt="">
              <div class="testimonial-name">
                <p class="mb-2">Eric James</p>
                <span class="text-muted">Freelancer, Photographer</span>
              </div>
            </div>
            <!--END OF TESTIMONIAL 1 -->
            <!--TESTIMONIAL 2 -->
            <div class="item">
                <div class="quoted-testimonial">
                  <p class="mb-0">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate.</p>
                </div>
                <img class="rounded-circle" src="https://themes.audemedia.com/html/goodgrowth/images/testimonial3.jpg" alt="">
                <div class="testimonial-name">
                  <p class="mb-2">Eric James</p>
                  <span class="text-muted">Freelancer, Photographer</span>
                </div>
              </div>
            <!--END OF TESTIMONIAL 2 -->
            <!--TESTIMONIAL 3 -->
            <div class="item">
                <div class="quoted-testimonial">
                  <p class="mb-0">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate.</p>
                </div>
                <img class="rounded-circle" src="https://themes.audemedia.com/html/goodgrowth/images/testimonial3.jpg" alt="">
                <div class="testimonial-name">
                  <p class="mb-2">Eric James</p>
                  <span class="text-muted">Freelancer, Photographer</span>
                </div>
              </div>
            <!--END OF TESTIMONIAL 3 -->
            <!--TESTIMONIAL 4 -->
            <div class="item">
                <div class="quoted-testimonial">
                  <p class="mb-0">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate.</p>
                </div>
                <img class="rounded-circle" src="https://themes.audemedia.com/html/goodgrowth/images/testimonial3.jpg" alt="">
                <div class="testimonial-name">
                  <p class="mb-2">Eric James</p>
                  <span class="text-muted">Freelancer, Photographer</span>
                </div>
              </div>
            <!--END OF TESTIMONIAL 4 -->
            <!--TESTIMONIAL 5 -->
            <div class="item">
                <div class="quoted-testimonial">
                  <p class="mb-0">Dramatically maintain clicks-and-mortar solutions without functional solutions. Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate.</p>
                </div>
                <img class="rounded-circle" src="https://themes.audemedia.com/html/goodgrowth/images/testimonial3.jpg" alt="">
                <div class="testimonial-name">
                  <p class="mb-2">Eric James</p>
                  <span class="text-muted">Freelancer, Photographer</span>
                </div>
              </div>
            <!--END OF TESTIMONIAL 5 -->
          </div>
        </div>
      </div>
      </div>
    </section>
    <!-- END OF TESTIMONIALS -->

    <!-- Footer section -->
    <div class="bg-dark-l">
        <div class="border-bottom-l mb-5">
            <div class="container">
                <div class="d-flex flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between align-items-center py-4">
                    <div class="logo mb-lg-0 mb-md-0 mb-sm-5 mb-5">
                        <img class="img-fluid" src="public/images/logo.png" alt="logo" />
                    </div>
                    <div class="social_icon">
                        <ul class="list-inline h2">
                            <li class="list-inline-item">
                                <a href="#"><i class="fab fa-facebook-square fa-lg text-silver"></i></a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#"><i class="fab fa-linkedin fa-lg text-silver"></i></a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#"><i class="fab fa-instagram fa-lg text-silver"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container py-3 pb-5 footerHead">
            <div class="row">
                <div class="col-lg-2 col-md-2 col-sm-4 col-6 text-md-left text-sm-left text-center">
                    <p class="text-white mb-3">For Candidates</p>
                    <ul class="list-inline">
                        <li class="mb-2"><a class="text-silver" href="#">Browse Jobs</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Browse Categories</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Candidate Dashboard</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">job Aletrs</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">My Bookmarks</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-4 col-6 text-md-left text-sm-left text-center">
                    <p class="text-white mb-3">For Employers</p>
                    <ul class="list-inline">
                        <li class="mb-2"><a class="text-silver" href="#">Browse Candidates</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Employer Dashboard</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Add Jobs</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">job Packages</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-4 col-6 text-md-left text-sm-left text-center">
                    <p class="text-white mb-3">Other</p>
                    <ul class="list-inline">
                        <li class="mb-2"><a class="text-silver" href="#">Job Page</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Job Page Alternative</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Resume Page</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Blog</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-4 col-6 text-md-left text-sm-left text-center">
                    <p class="text-white mb-3">Legal</p>
                    <ul class="list-inline">
                        <li class="mb-2"><a class="text-silver" href="#">Privacy policy</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Terms of Use</a></li>
                        <li class="mb-2"><a class="text-silver" href="#">Faq</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-8 col-12 mt-lg-0 mt-md-0 mt-sm-0 mt-4 text-md-left text-sm-left text-center">
                    <p class="text-white mb-3"><i class="far fa-envelope"></i> Sign Up For a Newsletter</p>
                    <p class="text-silver">Weekly breaking news analysis and cutting edge advices on job searching.</p>
                    <form>
                        <div class="form-group d-flex">
                            <input type="text" class="form-control bg-charcol border-0 mr-1" placeholder="Enter your email here" />
                            <button type="button" class="btn btn-success">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="bg-dark p-3 footer">
            <div class="container text-md-left text-sm-center text-center">
                <p class="mb-0 text-silver">@All  Rights Reserved, United Market 2020</p>
            </div>
        </div>
    </div> 
    <!-- Footer section -->
</body>
<script type="text/javascript" src="public/js/jquery-2.2.2.js"></script>
<script type="text/javascript" src="public/js/popper.min.js"></script>
<script type="text/javascript" src="public/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="public/js/common-functions.js"></script>
<script src="public/js/owl/owl.carousel.js"></script>
<!-- owl scripts -->
<script>
jQuery(document).ready(function($) {
        		"use strict";
        		//  TESTIMONIALS CAROUSEL HOOK
		        $('#customers-testimonials').owlCarousel({
		            loop: true,
		            center: true,
		            items: 3,
		            margin: 0,
		            autoplay: true,
		            dots:true,
		            autoplayTimeout: 8500,
		            smartSpeed: 450,
		            responsive: {
		              0: {
		                items: 1
		              },
		              768: {
		                items: 2
		              },
		              1170: {
		                items: 3
		              }
		            }
		        });
        	});
</script>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>