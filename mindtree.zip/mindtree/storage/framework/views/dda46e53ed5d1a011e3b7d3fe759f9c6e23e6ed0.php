
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-4">
        <h1 class="text-lg-left text-md-left text-sm-center text-center font-600">Job Invites</h1>
        <div class="row my-5 pb-4 border-bottom">
            <div class="col-lg-8 col-md-8 col-sm-8  d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center mb-sm-0 mb-4">
                <div class="d-flex">
                    <div class="flex-shrink-0 mr-3">
                        <img class="img-box rounded-circle" src="images/2.png"  alt="img"/>
                    </div>
                    <div class="w-100 overflow-hidden">
                        <h4>Eric Jones</h4>
                        <div class="d-flex cus-w-stars">
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-lg-right text-md-right text-sm-right text-center">
                <p class="font-500 text-muted"><i class="fas fa-map-marker-alt mr-2"></i> Buckhead</p>
                <h4>$30/hr</h4>
            </div>
            <div class="col-lg-11 text-lg-left text-md-left text-sm-center text-center">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit explicabo debitis, ea asperiores pariatur officiis? Nihil quibusdam pariatur cum animi<span id="dots">...</span> <span id="more">dignissimos porro dolores nostrum similique quaerat at? Nobis, tempora aperiam.</span>
                <a onclick="myFunction()" id="myBtn"><strong>More</strong></a>
                </p>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-center justify-content-center">
                    <ul class="list-inline">
                        <li class="file-box list-inline-item" style="background-image:url('images/img-1.png');"></li>
                        <li class="file-box list-inline-item" style="background-image:url('images/img-1.png');"></li>
                        <li class="file-box list-inline-item" style="background-image:url('images/img-1.png');"></li>
                        <li class="file-box list-inline-item" style="background-image:url('images/img-1.png');"></li>
                        <li class="file-box list-inline-item border rounded text-center">2+</li>
                    </ul>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-center justify-content-center">
                <button type="button" class="btn btn-success px-4 mr-2"><i class="fas fa-check-circle mr-2"></i> Accept</button>
                <button type="button" class="btn btn-dark px-4"><i class="fas fa-times-circle mr-2"></i> Reject</button>
            </div>
        </div>
        <div class="row my-5">
            <div class="col-lg-8 col-md-8 col-sm-8 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center mb-sm-0 mb-4">
                <div class="d-flex">
                    <div class="flex-shrink-0 mr-3">
                        <img class="img-box rounded-circle" src="images/2.png"  alt="img"/>
                    </div>
                    <div class="w-100 overflow-hidden">
                        <h4>Eric Jones</h4>
                        <div class="d-flex cus-w-stars">
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-lg-right text-md-right text-sm-right text-center">
                <p class="font-500 text-muted"><i class="fas fa-map-marker-alt mr-2"></i> Buckhead</p>
                <h4>$30/hr</h4>
            </div>
            <div class="col-lg-11 text-lg-left text-md-left text-sm-center text-center">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit explicabo debitis, ea asperiores pariatur officiis? Nihil quibusdam pariatur cum animi<span id="dots">...</span> <span id="more">dignissimos porro dolores nostrum similique quaerat at? Nobis, tempora aperiam.</span>
                    <a onclick="myFunction()" id="myBtn"><strong>More</strong></a>
                    </p>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-center justify-content-center">
                <button type="button" class="btn btn-success px-4 mr-2" data-toggle="modal"
                data-target="#contractEnded"><i class="fas fa-check-circle mr-2"></i> Accept</button>
                <button type="button" class="btn btn-dark px-4"><i class="fas fa-times-circle mr-2"></i> Reject</button>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
</script>
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/job/job-invites.blade.php ENDPATH**/ ?>