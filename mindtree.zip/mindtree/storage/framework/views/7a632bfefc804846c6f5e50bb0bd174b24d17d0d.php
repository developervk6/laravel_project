
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" role="tab" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link active" id="nav-about-tab" href="/settings/experience" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">                                          
                                            <div class="tab-pane fade show active" id="experience" role="tabpanel" aria-labelledby="nav-about-tab">
                                                <!-- note -->
                                                <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                    <div
                                                        class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                        <p class="text-dark text-sm-left text-center mb-sm-0 mb-2">Note: <span
                                                                class="text-muted">To make changes in your experience
                                                                please click on edit button</span></p>
                                                        <a role="button" class="btn btn-dark text-white"
                                                            data-toggle="modal" data-target="#basicProfile">
                                                            <span
                                                                class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                    class="fas fa-pen text-dark"></i></span>
                                                            Edit</a>
                                                    </div>
                                                </div>
                                                <!-- note -->
                                                <!-- section 1 -->
                                                <div class="border rounded my-4 p-3" id="experience_list">
                                                    <?php if(count($user->experiences)>0): ?>
                                                    <?php $__currentLoopData = $user->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="expRowClass" id="experience_row_<?php echo e($experience->id); ?>">
                                                        <div class="d-flex align-items-center">
                                                            <h5 class="font-300 mr-2"><?php echo e($experience->title); ?></h5>
                                                            <span>
                                                                <a href="javascript:void(0);" onClick="editExperience(<?php echo e($experience->id); ?>)">
                                                                    <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-2"></i>
                                                                </a>
                                                            </span>
                                                            <span>
                                                                <a href="javascript:void(0);" onClick="deleteExperience(<?php echo e($experience->id); ?>)">
                                                                    <i class="fas fa-window-close cursor-pointer text-dark fa-lg ml-1"></i>
                                                                </a>
                                                            </span>
                                                        </div>
                                                        <p class="small text-muted-50"><?php echo e($experience->description); ?></p>
                                                        <div class="d-flex">
                                                            <p class="font-bold mr-5"><?php echo e(date("M Y",strtotime($experience->from_date))); ?></p>
                                                            <p class="font-bold"><?php echo e(date("M Y",strtotime($experience->to_date))); ?></p>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                    <div id="no_experience">
                                                        You have not added experience.
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                                <!-- section 1 -->
                                                <!-- section 2-->
                                                <div class="border my-4 rounded p-4">
                                                    <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                                                        <p class="font-bold mb-sm-0 mb-2">Want to add new experience?</p>
                                                        <a href="javascript:void(0);" class="btn btn-dark text-white" data-toggle="modal" data-target="#experienceModal">
                                                            <i class="fas fa-plus-circle mr-1"></i> Add
                                                        </a>
                                                    </div>
                                                </div>
                                                <!-- section 2-->
                                            </div>                                                        
                                        </div>
                                    </div>
                                </section>
                                <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<!-- Modal Add experience-->
<div class="modal fade" id="experienceModal" tabindex="-1" role="dialog" aria-labelledby="experiencelabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Experience</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body">
                <p class="text-muted-50">Please provide your experience details</p>
                <form method="POST" action="" id="ExpForm">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" id="experience_title" name="experience_title" class="form-control cus-input" placeholder="Title"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="experience_description" name="experience_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="experience_from" autocomplete="off" />
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="experience_to" autocomplete="off" />
                            </div>
                        </div>
                    </div>
                        <button type="button" id="btnAddNewExperience" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal Add experience End-->
<!-- Modal Edit experience-->
<div class="modal fade" id="edit_experience_modal" tabindex="-1" role="dialog" aria-labelledby="edit_experience_modal_label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Edit Experience</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body">
                <form method="POST" action="" id="ExpEditForm">
                <input type="hidden" id="experience_id" value=""/>
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" id="edit_experience_title" name="edit_experience_title" class="form-control cus-input" placeholder="Title"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="edit_experience_description" name="edit_experience_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="edit_experience_from" autocomplete="off" />
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="edit_experience_to" autocomplete="off" />
                            </div>
                        </div>
                    </div>
                        <button type="button" id="btnEditExperience" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal edit experience End-->

<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    $('#experience_from').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'
    });
    $('#experience_to').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });
    $('#edit_experience_to').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });  
    $('#edit_experience_from').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });    
});
$('#btnAddNewExperience').click(function(e){
    e.preventDefault();
    if($('#experience_title').val()==''){
        alert("Please enter title.");
        $('#experience_title').focus();
        return false;
    }else if($('#experience_description').val()==''){
        alert("Please enter description.");
        $('#experience_description').focus();
        return false;
    }else if($('#experience_from').val()==''){
        alert("Please select from date.");
        $('#experience_from').focus();
        return false;
    }else if($('#experience_to').val()==''){
        alert("Please select to date.");
        $('#experience_to').focus();
        return false;
    }else if($('#experience_from').val()>=$('#experience_to').val()){
        alert("Invalid from/to date.");
        $('#experience_from').focus();
        return false;
    }else{
        var title = $("#experience_title").val();
        var description = $("#experience_description").val();
        var from_date = $("#experience_from").val();                   
        var to_date = $("#experience_to").val();
        var formData = {title:title,description:description,from_date:from_date,to_date:to_date};     
        $.ajax({
            type:'POST',
            url:'/AddUserExperience',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL; 
                }
            }
        });
    }
});
function deleteExperience(experience_id){
    if(confirm("Are you sure you want to delete this?")){
        $.ajax({
            type:'GET',
            url:'/api/delete-experience/'+experience_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    window.location.href=document.URL;                
                }
            }
        });
    }
}
function editExperience(experience_id){
    $.ajax({
        type:'GET',
        url:'/api/experience-details/'+experience_id,
        async: false,
        success:function(data){
            if(data.code==200){
                $("#experience_id").val(experience_id);  
                $("#edit_experience_title").val(data.data.title); 
                $("#edit_experience_description").val(data.data.description); 
                $("#edit_experience_from").val(data.data.from_date); 
                $("#edit_experience_to").val(data.data.to_date);   
                $("#edit_experience_modal").modal();       
            }
        }
    });
}
$('#btnEditExperience').click(function(e){
    e.preventDefault();
    if($('#edit_experience_title').val()==''){
        alert("Please enter title.");
        $('#edit_experience_title').focus();
        return false;
    }else if($('#edit_experience_description').val()==''){
        alert("Please enter description.");
        $('#edit_experience_description').focus();
        return false;
    }else if($('#edit_experience_from').val()==''){
        alert("Please select from date.");
        $('#edit_experience_from').focus();
        return false;
    }else if($('#edit_experience_to').val()==''){
        alert("Please select to date.");
        $('#edit_experience_to').focus();
        return false;
    }else if($('#edit_experience_from').val()>=$('#edit_experience_to').val()){
        alert("Invalid from/to date.");
        $('#edit_experience_from').focus();
        return false;
    }else{
        var id = $("#experience_id").val();
        var title = $("#edit_experience_title").val();
        var description = $("#edit_experience_description").val();
        var from_date = $("#edit_experience_from").val();                   
        var to_date = $("#edit_experience_to").val();
        var formData = {id:id,title:title,description:description,from_date:from_date,to_date:to_date};     
        $.ajax({
            type:'POST',
            url:'/EditUserExperience',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL; 
                }
            }
        });
    }
});
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/experience.blade.php ENDPATH**/ ?>