
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-4">
        <form name="frmCreateJob" id="frmCreateJob" action="/create-job" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h1 class="mb-4 font-600">Create job</h1>
        <p class="mb-2 font-300">I am Looking for</p>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <div class="select-style-left">
                        <select name="user_type" id="user_type">
                            <option value="">Select Services</option>
                            <option value="FREELANCER">Freelancer</option>
                            <option value="BUSINESS">Business</option>
                            <option value="BOTH">Both</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="select-style-left">
                        <select name="service_category_id" id="service_category_id" onChange="populateServiceSubCategories(this.value);">
                            <option value="">Category</option>
                            <?php $__currentLoopData = $service_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service_category->id); ?>"><?php echo e($service_category->service_category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="select-style-left">
                        <select name="service_sub_category_id" id="service_sub_category_id">
                            <option value="">Sub Category</option>                           
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div id="locationfield" class="black fancyme-location">
                        <input id="location_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Location" autocomplete="off">
                        <p class="text-muted-50 mb-3 h6 font-300 mt-2">Please add the preferred locations for services</p>
                        <div id="shownlistLocation" class="shownlistLocation">                           
                        </div>
                    </div>
                </div>
                <input type="hidden" id="current_location_lat_long" name="current_location_lat_long" value="<?php echo e($user->current_location_lat_long); ?>">                
                <input type="hidden" id="location_state_ids" name="location_state_ids" value="<?php echo e($user->location_state_ids); ?>">
                <input type="hidden" id="location_country_ids" name="location_country_ids" value="<?php echo e($user->location_country_ids); ?>">
                <div class="form-group position-relative float-left w-100">
                    <input class="form-control cus-input" type="text" placeholder="Job Location" id="current_location" name="current_location" value="<?php echo e($user->current_location); ?>">
                    <span class="position-absolute rightIcon" style="top:30%;"><i class="fas fa-map-marker-alt text-muted"></i></span>
                    <p class="text-muted-50 h6 font-300 mb-0 mt-2">Please add your current location in case of Face to Face services</p>
                </div>
                <div class="form-group">
                    <div id="tagfield" class="black fancyme-tags">
                        <input id="tag_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Skills" autocomplete="off">
                        <div id="shownlist">                           
                        </div>
                    </div>
                </div>
                <input type="hidden" id="selectedTagIds" name="selectedTagIds" value="<?php echo e($user->tag_ids); ?>">
                <div class="form-group">
                    <input type="text" class="form-control cus-input" maxlength="100" id="job_title" name="job_title" placeholder="Job Title" value="">
                </div>
                <div class="form-group">
                    <textarea class="form-control cus-input" rows="7" placeholder="Job Description" id="job_description" name="job_description"></textarea>
                    <span id="rcharst" class="text-right w-100 d-block mt-1"></span>
                </div> 
                <div class="form-group">
                    <div class="border-dashed rounded d-flex align-items-center position-relative">
                        <input class="custom-file-input" type="file" id="fileInput" name="media_files[]" multiple size="50">
                        <div class="position-absolute divCenter text-muted">
                            <i class="fas fa-paperclip mr-3"></i>Attachments
                        </div>
                    </div>                   
                    <p class="text-muted text-center small py-2">You can attach Files, Documents, Photos and Intro Videos upto 10MB</p>
                    <div class="d-flex">
                        <div class="mr-3">
                            <p id="demo"></p>
                        </div>
                    </div>
                    <div class="progress" style="display:none;">
                        <div class="progress-bar"></div>
                    </div>                        
                    <div id="uploadStatus"></div>
                    <input type="hidden" id="attachment_ids" name="attachment_ids" value="">                  
                </div> 
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Timeline</label>
                    <div class="select-style-left">
                        <select name="timeline" id="timeline">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Expected Completion Date</label>
                    <input class="form-control cus-input" placeholder="MM/DD/YYYY" id="expected_completion_date" name="expected_completion_date" autocomplete="off"/>
                </div>
                <div class="form-group">
                    <label>Estimated Hours</label>
                    <div class="select-style-left">
                        <select name="availability_hours" id="availability_hours">
                            <option value="">Select</option>
                            <?php $__currentLoopData = $availibility_hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Expertise Level</label>
                    <div class="d-flex">
                        <?php $i = 1;?>
                        <?php $__currentLoopData = $expertise_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <div class="form-group mr-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio<?php echo e($i); ?>" name="expertise_level" class="custom-control-input" value="<?php echo e($value); ?>" <?php if($key=='ENTRY'): ?> checked <?php endif; ?>>
                                    <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e(ucfirst(strtolower($value))); ?></label>
                                </div>
                            </div>
                            <?php $i++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </div>
                </div>
                <div class="form-group">
                    <label>Job Type</label>
                    <div class="d-flex">                        
                        <?php $__currentLoopData = $fulfilment_of_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <div class="form-group mr-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio<?php echo e($i); ?>" name="fulfilment_of_services" class="custom-control-input" value="<?php echo e($key); ?>" <?php if($key==0): ?> checked <?php endif; ?>>
                                    <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e($value); ?></label>
                                </div>
                            </div>
                            <?php $i++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </div>
                </div>                
                <div class="form-group">
                    <label>Services by</label>
                    <div class="d-flex">                        
                        <?php $__currentLoopData = $service_mode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group mr-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio<?php echo e($i); ?>" name="service_mode" class="custom-control-input" value="<?php echo e($value); ?>" onChange="return showHideServiceChargeOptions(this.value);"  <?php if($key=='HOURLY'): ?> checked <?php endif; ?>>
                                    <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e(ucfirst(strtolower($value))); ?></label>
                                </div>
                            </div>
                            <?php $i++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                    </div>
                </div>               
                <div class="form-group" id="fixed_div">
                    <label>Service Charges</label>
                    <input class="form-control cus-input px-2" type="text" id="service_fixed_charge" name="service_fixed_charge" placeholder="$200" maxlength="10" value="">
                </div>               
                <div class="form-group" id="flexible_div">
                    <label class="mb-3">Service Charges</label>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="slider-range"></div>
                        </div>
                    </div>
                    <div class="row slider-labels mt-3">
                        <div class="col-sm-6 caption">
                            <strong>Min:</strong>&nbsp;<span id="slider-range-value1"></span>
                        </div>
                        <div class="col-sm-6 d-flex justify-content-end caption">
                            <strong>Max:</strong>&nbsp;<span id="slider-range-value2"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                                <input type="hidden" name="service_charges_low" id="service_charges_low" value="">
                                <input type="hidden" name="service_charges_high" id="service_charges_high" value="">
                        </div>
                    </div>
                </div>
                <button id="submit" type="button" class="btn btn-dark btn-sm btn-block">Create Job</button>
            </div>
        </div>
        <div class="row mb-3 my-3">
            <div class="col-lg-6 cusInputGroup">
            <div class="input-group mb-3 rightArrow">                            
                    <input type="text" class="form-control" disabled="" aria-label="add Milstones" placeholder="Add Questions">                            
                    <div class="input-group-append">
                        <a href="javascript:void();" id="questions_selects" data-toggle="modal" data-target="#questionModal">
                            <span class="input-group-text h-100"><i class="fas fa-chevron-right"></i></span>
                        </a>
                    </div>
                </div>
                <p class="text-muted-50">Please select general & custom questions for your job</p>
                <div class="d-flex">
                    <ul class="list-inline" id="added_questions" style="display:none;">                    
                        <li class="bg-light p-2 mb-2 rounded"></li>
                    </ul>
                </div>
                <div class="form-group">
                        &nbsp;
                </div>
                <input type="hidden" name="questions" id="questions" value="">
            </div>
        </div>
        </form>
    </div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">   
            <div class="bg-white shadow cus-rounded pb-5">
                <p class="pt-5 pb-4 h5 font-300 text-center px-2">Congratulations!<br> You've Posted a New Job</p>
                <div class="col-sm-9 m-auto">
                    <div class="col-lg-6 m-auto mb-3">
                        <img class="img-fluid animated bounce" src="public/images/congratulations.png" />
                    </div>
                </div>
            </div>
    </div>
  </div>
</div> 

<!--Modal-->
<div class="modal fade" id="questionModal" tabindex="-1" role="dialog" aria-labelledby="questionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Add questions</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group position-relative mt-2">
                    <div class="input-group mb-3">
                      <input class="form-control cus-input px-2" name="custom_question" id="custom_question" type="text" placeholder="Create Custom Question">
                      <div class="input-group-append cursor-pointer" onClick="AddCustomQuestion()">
                        <span class="input-group-text"><i class="fas fa-plus"></i></span>
                      </div>
                    </div>
                </div>
                <div id="custom_question_div">                   
                </div>                
                <div class="w-100">
                    <div class="or my-3"> <span class="bg-white px-4">Or</span></div>
                </div>
                <p class="mb-0 font-bold">Recommended questions:</p>

                <?php if(isset($questions)): ?>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox recover_pass mr-sm-2 my-3">
                        <input type="checkbox" class="custom-control-input question" name="questions[]" custom-attr-question="<?php echo e($question->question); ?>" id="question<?php echo e($question->id); ?>" value="<?php echo e($question->id); ?>" onClick="CheckAddedQuestion();">
                        <label class="custom-control-label" for="question<?php echo e($question->id); ?>"><?php echo e($question->question); ?></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>                
            </div>
            <div class="modal-footer flex-column">
               <div class="w-100 text-right">
                <p id="label_added"></p>
                </div>
                <div class="w-100 text-right">
                    <button type="button" class="btn btn-sm btn-dark" onClick="AddQuestion()">Add Question(s)</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Modal-->
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});    
$('#submit').click(function(){
    if($("#user_type").val()==''){
        alert("Please select service");
        $("#user_type").focus();
        return false;
    }else if($("#service_category_id").val()==''){
        alert("Please select category");
        $("#service_category_id").focus();
        return false;
    }else if($("#service_sub_category_id").val()==''){
        alert("Please select sub category");
        $("#service_sub_category_id").focus();
        return false;
    }else if($("#location_state_ids").val()=='' && $("#location_country_ids").val()==''){
        alert("Please select location(s)");
        $("#location_list").focus();
        return false;
    }if($("#current_location").val()==''){
        alert("Please enter job location");
        $("#current_location").focus();
        return false;
    }if($("#selectedTagIds").val()==''){
        alert("Please select skill(s)");
        $("#tag_list").focus();
        return false;
    }if($("#job_title").val()==''){
        alert("Please enter job title");
        $("#job_title").focus();
        return false;
    }if($("#job_description").val()==''){
        alert("Please enter job description");
        $("#job_description").focus();
        return false;
    }if($("#timeline").val()==''){
        alert("Please select timeline");
        $("#timeline").focus();
        return false; 
    }if($("#expected_completion_date").val()==''){
        alert("Please select expected completion date");
        $("#expected_completion_date").focus();
        return false;       
    }else if($("#availability_hours").val()==''){
        alert("Please select estimated hours");
        $("#availability_hours").focus();
        return false;
    }else if($('input[name="service_mode"]:checked').val()=='FIXED' && $('#service_fixed_charge').val()=='') {
        alert('Please enter service charges');
        return false;  
    }else{
        //$('#loader').show();
        var formPostData = $('#frmCreateJob').serialize();
        //console.log(formPostData);return false;
        $.ajax({
            type:'POST',
            url:'/create-job',
            data:formPostData,
            async: false,
            success:function(data){
                if(data.status=='done' && data.data.is_payment_setup_done==1){
                    $('#myModal').modal('toggle');     
                    setTimeout(() => {
                        window.location.href = home_path;
                    }, 5000); 
                }else{
                    localStorage.setItem("action_name", "create_job");
                    window.location.href = payment_path;
                }
            }
        });
    }
});
$("#fileInput").change(function(){
    var allowedTypes = ['video/quicktime', 'video/mp4', 'ideo/x-msvideo', 'application/pdf', 'application/msword', 'application/vnd.ms-office', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    var fileType = '';   
    var isValid = false;
    var formData = new FormData();
    var size = 0;
    for (var i = 0; i < $(this).get(0).files.length; ++i) {
        fileType = $(this).get(0).files[i].type;
        if(!allowedTypes.includes(fileType)){
            isValid = false;
        }else{
            isValid = true;
        }
        formData.append("media_files[]", $(this).get(0).files[i]);
        size = parseInt(size)+parseInt($(this).get(0).files[i]['size']);
    }
    var size_in_mb = size/1000000;
    if($(this).val()!=''){
        if(!isValid){
            alert('Please select a valid file (PDF/DOC/DOCX/JPEG/JPG/PNG/GIF/MP4/MOV/AVI).');
            $("#fileInput").val('');
            return false;
        }else if(size_in_mb>10){
            alert('You can not select large than 10 MB file.');
            $("#fileInput").val('');
            return false;
        }else{
            $.ajax({                
                xhr: function() {
                    $('.progress').show();
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function(evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = parseInt(((evt.loaded / evt.total) * 100));
                            $(".progress-bar").width(percentComplete + '%');
                            $(".progress-bar").html(percentComplete+'%');
                        }
                    }, false);
                    return xhr;
                },
                type: 'POST',
                url: '/api/upload-medias',
                data: formData,
                contentType: false,
                cache: false,
                processData:false,
                beforeSend: function(){
                    $(".progress-bar").width('0%');
                    //$('#uploadStatus').html('<img src="images/loading.gif"/>');
                },
                error:function(){
                    $('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
                },
                success: function(resp){                    
                    if(resp.code == 200){
                        $('.progress').hide();
                        var media_ids = resp.media_ids;
                        var media_files = resp.media_files;
                        console.log(media_ids);
                        for(i=0;i<media_ids.length;i++){
                            if($('#attachment_ids').val()!=''){
                                $('#attachment_ids').val($('#attachment_ids').val()+','+media_ids[i]);
                            }else{
                                $('#attachment_ids').val(media_ids[i]);
                            }               
                            var deleteImage = '<a class="d-flex align-self-center" href="javascript:void(0);" onclick="removeImage('+media_ids[i]+')"><i class="fas fa-times-circle text-dark ml-1"></i></a>';
                            $('#uploadStatus').append('<p id="attachment_id_'+media_ids[i]+'" class="d-flex align-items-center docStyle text-success">'+'<i class="fas fa-file mr-2"></i>'+media_files[i]+'&nbsp;'+deleteImage+'</p>');
                        }
                    }else if(resp.code == 401){
                        $('#uploadStatus').html('<p class="text-dark">Please select a valid file to upload.</p>');
                    }
                } 
            });
        }
    }
});  
var wordLen = 700,len;
$('#job_description').keyup(function(event) {    
    if($(this).val()==''){
        $('#rcharst').html(wordLen+' Words');
    }else{
        var words = $(this).val().match(/\S+/g).length;
        if (words > 700) {
            var trimmed = $(this).val().split(/\s+/, 700).join(" ");
            $(this).val(trimmed + " ");
        }
        else {
            var wordsLeft = wordLen - words;
            if(wordsLeft<=0){
                $('#rcharst').css({'color':'red'}).prepend('<i class="fa fa-exclamation-triangle"></i>');
            }else{
                $('#rcharst').css({'color':'black'})
            }
            $('#rcharst').html(wordsLeft+' Word(s) left');
        }    
    }    
});
$(document).ready(function(){
    init();
    $.ajax({
        type:'GET',
        url:'/GetCountriesStates',
        success:function(data){
            if(data.status=='done'){                   
                $( "#location_list" ).autocomplete({
                    classes: {
                        "ui-autocomplete": "input-style",
                    },
                    maxShowItems: 10,
                    minLength: 1,
                    source: data.data,
                    select: function(e, item){
                        if(item.item.type==1 && item.item.value!=''){ ////country
                            var location_country_ids = $("#location_country_ids").val();
                            if (location_country_ids.split(",").includes(item.item.id+"")) {
                            } else {
                                var spanHtml = '<span id="country'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeLocation('+item.item.id+',1)"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                $("#shownlistLocation").append(spanHtml);
                                if($("#location_country_ids").val()==''){
                                    $("#location_country_ids").val(item.item.id);
                                }else{
                                    $("#location_country_ids").val($("#location_country_ids").val()+','+item.item.id);
                                }
                            }
                        }else if(item.item.type==2 && item.item.value!=''){ ////state
                            var location_state_ids = $("#location_state_ids").val();
                            if (location_state_ids.split(",").includes(item.item.id+"")) {
                            } else {
                                var spanHtml = '<span id="state'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeLocation('+item.item.id+',2)"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                $("#shownlistLocation").append(spanHtml);
                                if($("#location_state_ids").val()==''){
                                    $("#location_state_ids").val(item.item.id);
                                }else{
                                    $("#location_state_ids").val($("#location_state_ids").val()+','+item.item.id);
                                }
                            }
                        }                            
                        setTimeout(function(){
                            $('#location_list').val("");
                        },100);
                    },
                    response: function(event, ui) {
                        if (!ui.content.length) {
                            var noResult = { value:"",label:"No results found" };
                            ui.content.push(noResult);
                        }
                    }
                });
            }
        }
    });
    $.ajax({
        type:'GET',
        url:'/GetTags',
        success:function(data){
            if(data.status=='done'){                   
                $( "#tag_list" ).autocomplete({
                    classes: {
                        "ui-autocomplete": "tag-style",
                    },
                    minLength: 1,
                    maxShowItems: 10,
                    source: data.data,                       
                    select: function(e, item){
                        var selectedTagIds = $("#selectedTagIds").val();
                        if (selectedTagIds.split(",").includes(item.item.id+"") || item.item.value=='') {
                        } else {
                            var spanHtml = '<span id="tag'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeTag('+item.item.id+')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                            $(".fancyme-tags #shownlist").append(spanHtml);
                            if($("#selectedTagIds").val()==''){
                                $("#selectedTagIds").val(item.item.id);
                            }else{
                                $("#selectedTagIds").val($("#selectedTagIds").val()+','+item.item.id);
                            }
                        }
                        setTimeout(function(){
                            $('#tag_list').val("");
                        },100);
                    },
                    response: function(event, ui) {
                        if (!ui.content.length) {
                            var noResult = { value:"",label:"No results found" };
                            ui.content.push(noResult);
                        }
                    }
                });
            }
        }
    });

    $('#expected_completion_date').datepicker({
        uiLibrary: 'bootstrap4',
        minDate: 0
    });

    var wordLen = 700,len;
    len = $('#job_description').val().split(/[\s]+/);
    wordsLeft = (wordLen) - len.length;
    if($('#job_description').val()==''){
        $('#rcharst').html('700 Word(s) left');
    }else if(wordsLeft==700){
        $('#rcharst').html(wordsLeft+" Words");
    }else{
        $('#rcharst').html(wordsLeft+' Word(s) left');
    }
    ////range slider
    var rangeSlider = document.getElementById('slider-range');
    var moneyFormat = wNumb({
        decimals: 0,
        thousand: ',',
        prefix: '$'
    });
    noUiSlider.create(rangeSlider, {
        start: [1,100],
        step: 1,
        range: {
        'min': [1],
        'max': [100]
        },
        format: moneyFormat,
        connect: true
    });        
    // Set visual min and max values and also update value hidden form inputs
    rangeSlider.noUiSlider.on('update', function(values, handle) {
        document.getElementById('slider-range-value1').innerHTML = values[0];
        document.getElementById('slider-range-value2').innerHTML = values[1];
        document.getElementById('service_charges_low').value = moneyFormat.from(values[0]);
        document.getElementById('service_charges_high').value = moneyFormat.from(values[1]);
    });
    var service_mode = 'HOURLY';
    showHideServiceChargeOptions(service_mode);

});
function removeLocation(span_id,type){
    if(type==1){
        $('#country'+span_id).remove();
        var value = span_id;
        var arr = $("#location_country_ids").val().split(",");
        arr = arr.filter(function(item) {
            return item != value;
        });
        $("#location_country_ids").val(arr.join(","));
    }else if(type==2){
        $('#state'+span_id).remove();
        var value = span_id;
        var arr = $("#location_state_ids").val().split(",");
        arr = arr.filter(function(item) {
            return item != value;
        });
        $("#location_state_ids").val(arr.join(","));
    }
}
function removeTag(span_id){
    $('#tag'+span_id).remove();
    var value = span_id;
    var arr = $("#selectedTagIds").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#selectedTagIds").val(arr.join(","));    
}
function removeImage(image_id){
    $('#attachment_id_'+image_id).remove();
    var value = image_id;
    var arr = $("#attachment_ids").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#attachment_ids").val(arr.join(","));
    $.ajax({
        type:'DELETE',
        url:'/api/delete-media/'+image_id,
        async: false,
        success:function(data){
            if(data.code==200){               
            }
        }
    });
}
function showHideServiceChargeOptions(service_mode){
    if(service_mode=='HOURLY' || service_mode=='FLEXIBLE'){
        $('#fixed_div').hide();
        $('#flexible_div').show();
    }else if(service_mode=='FIXED'){
        $('#fixed_div').show();
        $('#flexible_div').hide();
    }
}
function init(){
    var address_selected = '<?php echo isset($user->current_location)?false:true;?>';
    if (navigator.geolocation) {
        if(address_selected){
            navigator.geolocation.getCurrentPosition(showPosition);
        }
    }
}
function showPosition(position) {
    var latitude = "latitude=" + position.coords.latitude;
    var longitude = "&longitude=" + position.coords.longitude;
    var query = latitude + longitude + "&localityLanguage=en";
    const Http = new XMLHttpRequest();
    var bigdatacloud_api ="https://api.bigdatacloud.net/data/reverse-geocode-client?";
    bigdatacloud_api += query;
    Http.open("GET", bigdatacloud_api);
    Http.send();
    Http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);
            var address = myObj.locality;
            if(myObj.principalSubdivision!='') address += ', '+myObj.principalSubdivision;
            $('#current_location').val(address);
        }
    };
    $("#current_location_lat_long").val(position.coords.latitude+','+position.coords.longitude);
}
$('#service_fixed_charge').keydown(function(event){        
    if ( event.keyCode == 46 || event.keyCode == 8 ) {
    }
    else {
        if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault(); 
        }             
    }
});  
function AddCustomQuestion(){
    if($("#custom_question").val().trim()==''){
        alert("Please enter question");
        $("#custom_question").focus();
        return false;
    }else{
        var formPostData = {question:$("#custom_question").val()};
        $.ajax({
            type:'POST',
            url:'/create-custom-question',
            data:formPostData,
            async: false,
            success:function(data){
                if(data.code==200){
                    var questionHtml = '<div class="custom-control custom-checkbox recover_pass mr-sm-2 my-3">';
                    questionHtml += '<input type="checkbox" class="custom-control-input question" name="questions[]" custom-attr-question="'+data.data.question+'" checked id="question'+data.data.id+'" value="'+data.data.id+'" onClick="CheckAddedQuestion();">';
                    questionHtml += '<label class="custom-control-label" for="question'+data.data.id+'">'+data.data.question+'</label>';
                    questionHtml += '</div>';
                    $("#custom_question_div").append(questionHtml);
                    $('#custom_question').val("");
                    var selected_questions = $('input[name="questions[]"]:checked').length;
                    $("#label_added").html("You have added "+selected_questions+" out of 5 questions.");
                }else{
                    alert("Question already exists");
                    return false;
                }
            }
        }); 
    }
}
function AddQuestion(){
    var selected_questions = $('input[name="questions[]"]:checked').length;
    if(selected_questions>5){
        alert("You can not select more than 5 questions.");
        return false;
    }else{
        if(selected_questions>0){
            var idsArr = [];
            var question_added;
            var html_li = '';
            var count = 1;
            $('input[name="questions[]"]:checked').each(function() {
                idsArr.push($(this).val());
                question_added = $(this).attr("custom-attr-question");
                html_li += '<li id="question_li_id_'+$(this).val()+'" class="bg-light p-2 mb-2 rounded">'+count+') '+question_added;
                html_li += '&nbsp;&nbsp;<span><a class="text-dark" href="javascript:void(0);" onClick="deleteQuestion('+$(this).val()+')"><i class="fas fa-times-circle"></i></a><span></li>';
                count++;
            });
            var idsStr = idsArr.join(",");
            $("#questions").val(idsStr);       
            $("#added_questions").show();
            $("#added_questions").html(html_li);
        }
        $(".close").trigger('click');
    }
}
function deleteQuestion(id){
    $("#question_li_id_"+id).remove();
    var value = id;
    var arr = $("#questions").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#questions").val(arr.join(","));
    $('#question'+id).prop('checked', false);
    AddQuestion();
}
//$(".question").click(function(){
function CheckAddedQuestion(){
    var selected_questions = $('input[name="questions[]"]:checked').length;
    if(selected_questions>5){
        alert("You can not select more than 5 questions.");
        return false;
    }else{
        $("#label_added").html("You have added "+selected_questions+" out of 5 questions.");
    }
}
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/job/create-job.blade.php ENDPATH**/ ?>