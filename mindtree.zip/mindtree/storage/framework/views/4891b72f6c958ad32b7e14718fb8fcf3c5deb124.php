
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
	<div class="col-lg-5 m-auto">
		<form method="POST" action="/complete-profile" id="signupstep2From" enctype="multipart/form-data">
		<input type="hidden" name="id" id="id" value="<?php echo e($id); ?>">
		<input type="hidden" name="email" id="email" value="<?php echo e($email); ?>">
		<input type="hidden" name="first_name" id="first_name" value="<?php if(isset($first_name)){ echo $first_name;}?>">
		<input type="hidden" name="last_name" id="last_name" value="<?php if(isset($last_name)){ echo $last_name;}?>">
		<input type="hidden" name="profile_image" id="profile_image" value="<?php if(isset($profile_image)){ echo $profile_image;}?>">
        <?php echo csrf_field(); ?>		
		<!---Step2 Started --->
		<div class="bg-white shadow cus-rounded pb-5" id="step2">
			<p class="pt-5 pb-4 h5 font-300 text-center">Please Choose From Following <br/> Options to Proceed.</p>
			<div class="col-sm-9 m-auto">
			<div class="col-lg-12 text-center mb-2">
				<label class="cus-radio cus-input border shadow-sm rounded text-center">I am Looking for Services
					<input type="radio" name="user_type" value="CLIENT" checked="checked">
					<span class="checkmark"></span>
				</label>
				<label class="cus-radio cus-input border shadow-sm rounded text-center">I am Freelancer
					<input type="radio" name="user_type" value="FREELANCER">
					<span class="checkmark"></span>
				</label>
				<label class="cus-radio cus-input border shadow-sm rounded text-center">I am Business
					<input type="radio" name="user_type" value="BUSINESS">
					<span class="checkmark"></span>
				</label>
			</div>
			<div class="col-lg-12">
				<button type="submit" id="btn-submit" class="btn btn-dark btn-sm w-100 text-white">
						<?php echo e(__('Next')); ?>

				</button>	
			</div>
			</div>
		</div>
		<!---Step2 End -->			
		</form>
	</div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<script>
$("#btn-submit").click(function(e){	
		$('#loader').show();
		$("#signupstep2From").submit();	
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/signup-step2.blade.php ENDPATH**/ ?>