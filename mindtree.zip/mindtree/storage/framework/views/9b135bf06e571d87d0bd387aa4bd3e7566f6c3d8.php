
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-4">
        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
            <h1 class="text-lg-left text-md-left text-sm-center text-center font-600">Job Details</h1>
            <span class="text-muted" id="save_job_span">
                <?php if($jobDetails->isSaved==0): ?>
                <a class="text-muted" href="javascript:void(0);" onClick="SaveJob(<?php echo e($jobDetails->id); ?>);" title="Save for later">
                    <i class="far fa-bookmark"></i>
                </a>
                <?php else: ?>
                <i class="fas fa-bookmark"></i>
                <?php endif; ?>
            </span>
        </div>
        <div class="row mt-4">
            <div class="col-lg-8 col-md-8 col-sm-8  d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center mb-sm-0 mb-4">
                <div class="d-flex">
                    <div class="w-100 overflow-hidden">
                        <h5 class="font-300 text-sm-left text-center"><?php echo e($jobDetails->job_title); ?></h5>
                        <div class="d-flex">
                            <div class="col-auto pl-0">
                                <p class="text-muted"><i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($jobDetails->state_name); ?></p>
                            </div>
                            <div class="col-auto">
                                <p class="text-muted"><?php echo e(ucfirst(strtolower($jobDetails->service_mode))); ?></p>
                            </div>
                            <div class="col-auto">
                                <p class="text-muted">
                                    <?php 
                                if($jobDetails->service_mode=='FIXED'){
                                    if(empty($jobDetails->service_fixed_charge)){
                                        echo 'NA';
                                    }else{
                                        echo "$".$jobDetails->service_fixed_charge; 
                                    }                                                       
                                }else{
                                    if(empty($jobDetails->service_charges_low) || empty($jobDetails->service_charges_high)){
                                        echo 'NA';
                                    }else{
                                        echo "$".$jobDetails->service_charges_low." - $".$jobDetails->service_charges_high;
                                    }
                                } 
                            ?>
                                </p>
                            </div>
                        </div>
                        <?php if($jobDetails->is_payment_setup_done==1): ?>
                        <div class="bg-success rounded p-1 text-white text-center">
                            Payment method is verified
                        </div>
                        <?php else: ?>
                        <div class="alert-red alert-danger rounded p-1 text-white text-center">
                            Payment method is not verified
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 text-lg-right text-md-right text-sm-right text-center">
                <p class="font-500 text-muted"><?php echo e(GetTimeFromDateFormat($jobDetails->created_at)); ?></p>
            </div>
            <div class="col-lg-12 text-lg-left text-md-left text-sm-left text-center mt-4">
                <h5 class="font-300">Job Description</h5>
                <p><?php echo e($jobDetails->job_description); ?></p>
            </div>
            <?php if(!empty($jobDetails->attachments)): ?>
            <div class="col-lg-12 text-sm-left text-center">
                <p>Attachments</p>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center">
                <ul class="list-inline">
                    <?php $__currentLoopData = $jobDetails->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $image = !empty($attachment->thumbnail)?$attachment->thumbnail:$attachment->media_file;?>
                    
                    <a href="<?php echo e($attachment->media_file); ?>" target="_blank">
                        <li class="file-box list-inline-item" style="background-image:url('<?php echo e($image); ?>');"></li>
                    </a>
                       

                    <!-- light box -->
                    <!-- <div class="mBox d-flex">
                        <div class="fancyBox mr-2 mb-2">
                            <img class="img-fluid" src="https://source.unsplash.com/TT-ROxWj9nA/1200x600" />
                        </div>
                        <div class="fancyBox mr-2 mb-2">
                            <img class="img-fluid" src="https://source.unsplash.com/IwVRO3TLjLc/1200x600" />
                        </div>
                        <div class="fancyBox mr-2 mb-2">
                            <img class="img-fluid" src="https://source.unsplash.com/Dv0YZ2_V3nc/1200x600" />
                        </div>
                    </div> -->
                    <!-- light box -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(count($jobDetails->questions)>0): ?>
            <div class="col-lg-12 text-sm-left text-center">
                <p>Questions</p>
            </div>
            <div class="col-lg-12 d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center">
                <ul class="list-inline w-50">
                    <?php $__currentLoopData = $jobDetails->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-light p-2 mb-2 rounded"> <?php echo e($loop->iteration); ?>) <?php echo e($question->question); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
        <div class="row bg-light pt-4 px-5">
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0"><?php echo e($jobDetails->country_name); ?></p>
                <span class="text-muted small"><?php echo e($jobDetails->state_name); ?></span>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">Job Type</p>
                <span class="text-muted small"><?php echo e($jobDetails->sub_category); ?></span>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">Expert Level</p>
                <span class="text-muted small"><?php echo e(ucfirst(strtolower($jobDetails->expertise_level))); ?></span>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">People Applied</p>
                <span class="text-muted small">40+</span>
            </div>
        </div>
        <div class="row bg-light pb-4 px-5">
            <div class="col-lg-8 col-md-2 col-sm-4 col-12 text-sm-left text-center mb-3">
                <p class="mb-0">Skills</p>
                <?php if(!empty($jobDetails->tags)): ?>
                <?php $__currentLoopData = $jobDetails->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="text-muted small bg-secondary-50 rounded p-1 my-2"><?php echo e($tag->tag); ?></span>&nbsp;
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="mt-5">
            <?php if($jobDetails->isApplied==0): ?>
            <a class="btn btn-dark btn-sm btn-block" href="/apply-job/<?php echo e($jobDetails->id); ?>">Apply Now</a>
            <?php else: ?>
            <a class="btn btn-dark btn-sm btn-block" href="javascript:void(0);">Already Applied</a>
            <?php endif; ?>
            <a class="btn btn-outline-secondary btn-sm btn-block" href="/profile/<?php echo e($jobDetails->user_id); ?>">About Client</a>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function SaveJob(job_id) {
        var formPostData = {
            job_id: job_id
        };
        $.ajax({
            type: 'POST',
            url: '/save-job',
            data: formPostData,
            async: false,
            success: function(data) {
                if (data.code == 200) {
                    $("#save_job_span").html('<i class="fas fa-bookmark"></i>');
                }
            }
        });
    }
</script>
<!-- Footer section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/job/job-details.blade.php ENDPATH**/ ?>