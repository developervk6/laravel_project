<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container my-5">
	<div class="col-lg-5 m-auto">
		<div class="bg-white shadow cus-rounded pb-5">
		<form method="POST" action="/login" id="frmLogin">
            <?php echo csrf_field(); ?>
			<p class="pt-5 pb-4 h5 font-300 text-center px-2">Please select from following options to login</p>
			<div class="col-sm-9 m-auto">
			<div class="col-lg-12 text-center mb-2">
				<a href="<?php echo e(url('/login/linkedin')); ?>" role="button" class="btn btn-primary btn-sm font-300 px-2 w-100"><i class="fab fa-linkedin-in fa-lg mr-sm-3 mr-1"></i> Sign in by LinkedIn</a>
			</div>
			<div class="col-lg-12 text-center">
				<a href="<?php echo e(url('/login/google')); ?>" role="button" class="btn btn-danger btn-sm font-300 px-2 w-100"><i class="fab fa-google fa-lg mr-sm-3 mr-1"></i> Sign in by Google</a>
			</div>
			<div class="col-lg-12">
				<div class="or my-3"> <span class="bg-white px-4">Or</span></div>
			</div>
			<?php if(session('message')): ?>
			<div class="col-sm-12">
			<div class="alert alert-danger text-center">
			  <?php echo e(session('message')); ?>

			</div>
			</div>
			<?php endif; ?>			
			<div class="col-lg-12 text-center">
				<div class="form-group">
					<input type="text" name="email" id="email" class="form-control cus-input text-center <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="<?php echo e(__('Email Address')); ?>" value="<?php echo e(old('email')); ?>"/>
					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="col-lg-12 text-center">
				<div class="form-group">
					<input type="password" name="password" id="password" class="form-control cus-input text-center <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="Password"/>
					<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="col-lg-12 text-center">
				<div class="form-group">
					<a class="text-muted small" href="<?php echo e(route('forgot-password')); ?>">Forgot Password?</a>
				</div>				
			</div>
			<div class="col-lg-12">
				<button id="btn-submit" type="submit" class="btn btn-dark btn-sm w-100 text-white">
					<?php echo e(__('Login')); ?>

				</button>
			</div>
			</div>		
		</form>
		</div>
	</div>

	<!--
<div class="container my-5">
	<div class="col-lg-6 m-auto">
		<div class="bg-white shadow rounded">
			<p class="py-5 h5 font-300 text-center">Please select from following options to signin</p>
			
			<form method="POST" action="">
            <?php echo csrf_field(); ?>
			<div class="col-sm-9 m-auto">
				<div class="col-lg-12 text-center mb-3">
					<a href="<?php echo e(url('/redirect')); ?>" role="button" class="btn btn-primary btn-lg font-300 px-lg-5 px-2 w-100"><i class="fab fa-linkedin-in fa-lg mr-3"></i> Sign in by LinkedIn</a>
				</div>
				<div class="col-lg-12 text-center">
					<a href="#" role="button" class="btn btn-danger btn-lg font-300 px-lg-5 px-2 w-100"><i class="fab fa-google fa-lg mr-3"></i> Sign in by Google</a>
				</div>
				<div class="col-lg-12">
					<div class="or my-4"> <span class="bg-white px-4">or</span></div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input type="email" id="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="<?php echo e(__('E-Mail Address')); ?>"/>
						<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="col-lg-12">
					<button type="submit" class="btn btn-dark btn-lg mb-5 w-100 text-white">
						<?php echo e(__('Login')); ?>

					</button>
				</div>
			</div>
			</form>
		</div>
	</div>
</div>
	-->
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<script>
$("#btn-submit").click(function(e){	
		$('#loader').show();
		$("#frmLogin").submit();	
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\mindtree2\resources\views/user/login.blade.php ENDPATH**/ ?>