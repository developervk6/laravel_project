
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded py-4 px-5">
        <h1 class="mb-4 font-600"><?php echo e(ucfirst(strtolower($user->user_type))); ?> Setup</h1>
        <form name="formProfileSetup" id="formProfileSetup" action="/profile-setup" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <input class="form-control cus-input" name="name" id="name" readonly type="text" value="<?php echo e($name); ?>">
                </div>
                <div class="form-group"> 
                   <div class="select-style-left">   
                    <select name="service_category_id" id="service_category_id" onChange="populateServiceSubCategories(this.value);">
                        <option value="">Category</option>
                        <?php $__currentLoopData = $service_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service_category->id); ?>" <?php echo $service_category->id==$user->service_category_id?'selected':''?>><?php echo e($service_category->service_category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
                <div class="form-group"> 
                   <div class="select-style-left">   
                    <select name="service_sub_category_id" id="service_sub_category_id">
                        <option value="">Sub Category</option>
                        <?php $__currentLoopData = $service_sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service_sub_category->id); ?>" <?php echo $service_sub_category->id==$user->user_service_sub_category->service_id?'selected':''?>><?php echo e($service_sub_category->service_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
                <div class="form-group">
                    <div id="locationfield" class="black fancyme-location">
                        <input id="location_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Location" autocomplete="off">
                        <div id="shownlistLocation" class="shownlistLocation">
                            <?php 
                                if(!empty($user->countries)){
                                    foreach($user->countries as $country){
                                        echo '<span id="country'.$country->id.'">'.$country->name.'<a href="javascript:void(0);" onclick="removeLocation('.$country->id.',1)"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                    }
                                }
                                if(!empty($user->states)){
                                    foreach($user->states as $state){
                                        echo '<span id="state'.$state->id.'">'.$state->name.'<a href="javascript:void(0);" onclick="removeLocation('.$state->id.',2)"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                    }
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="current_location_lat_long" name="current_location_lat_long" value="<?php echo e($user->current_location_lat_long); ?>">                
                <input type="hidden" id="selectedStateIds" name="selectedStateIds" value="<?php echo e($user->location_state_ids); ?>">
                <input type="hidden" id="selectedCountryIds" name="selectedCountryIds" value="<?php echo e($user->location_country_ids); ?>">
                <div class="form-group position-relative float-left w-100">
                    <input class="form-control cus-input" type="text" placeholder="Current Location" id="current_location" name="current_location" value="<?php echo e($user->current_location); ?>">
                    <span class="position-absolute rightIcon"><i class="fas fa-map-marker-alt text-muted"></i></span>
                </div>
                <div class="form-group">
                    <div id="tagfield" class="black fancyme-tags">
                        <input id="tag_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Keywords" autocomplete="off">
                        <div id="shownlist">
                            <?php 
                                if(!empty($user->tags)){
                                    foreach($user->tags as $tag){
                                        echo '<span id="tag'.$tag->id.'">'.$tag->tag.'<a href="javascript:void(0);" onclick="removeTag('.$tag->id.')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                    }
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="selectedTagIds" name="selectedTagIds" value="<?php echo e($user->tag_ids); ?>">                
                <div class="form-group">
                    <textarea class="form-control cus-input" rows="7" placeholder="<?php if($user->user_type=='BUSINESS'){echo 'Business Description';}else if($user->user_type=='FREELANCER'){echo 'Freelancer Description';}?>" id="job_description" name="job_description"><?php echo e($user->job_description); ?></textarea>
                    <span id="rcharst" class="text-right w-100 d-block mt-1"></span>
                </div>
                <!-- <div class="form-group">
                    <div class="border-dashed rounded p-3 d-flex align-items-center position-relative">
                        <input class="custom-file-input" type="file" id="fileInput" multiple size="50">
                        <div class="position-absolute divCenter text-muted">
                            <i class="fas fa-paperclip mr-3"></i>Attachments
                        </div>
                    </div>                   
                    <p class="text-muted text-center small py-2">You can attach Files, Document, Photos and Intro Videos upto 10MB</p>
                    <div class="d-flex">
                        <div class="mr-3">
                        <p id="demo"></p>
                        </div>
                    </div>
                    <div class="progress" style="display:none;">
                        <div class="progress-bar"></div>
                    </div>
                    <?php 
                        if($user->medias){
                            echo '<div id="uploadStatus">';
                            foreach($user->medias as $media){
                                echo '<p style="color:#28A74B;">'.$media->media_file.'</p>';
                            }
                            echo '</div>';
                        }else{
                            echo '<div id="uploadStatus"></div>';
                        }
                    ?>                    
                    <input type="hidden" id="attachment_ids" name="attachment_ids" value="">                  
                </div> -->
                <div class="form-group">
                    <input class="form-control cus-input" name="driver_license" id="driver_license" type="text" maxlength="20" placeholder="Driver License" value="<?php echo e($user->driver_license); ?>">
                </div>
                <div class="form-group">
                    <input class="form-control cus-input" name="ssn" id="ssn" type="text" placeholder="SSN" maxlength="20" value="<?php echo e($user->ssn); ?>">
                </div>                

                <?php  if($user->user_type=='BUSINESS'){ ?>
                <div class="form-group">
                    <input class="form-control cus-input" name="ein" id="ein" type="text" placeholder="EIN" maxlength="25" value="<?php echo e($user->ein); ?>">
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-6 mb-lg-0 mb-sm-4 mb-4">
                            <div class="border p-3 text-center shadow">
                                Business Code is: #<?php echo isset($user->business_code)?$user->business_code:'xxxxx';?>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-lg-0 mb-sm-4 mb-4">
                            <div class="border p-3 text-center shadow">
                                <!-- <a href="<?php echo e($share_links['facebook']); ?>" target="_blank"><img src="public/images/share_icons/fb128x128.png" width="25"></a>
                                &nbsp;
                                <a href="<?php echo e($share_links['linkedin']); ?>" target="_blank"><img src="public/images/share_icons/linkedin128x128.png" width="25"></a>
                                &nbsp;
                                <a href="<?php echo e($share_links['twitter']); ?>" target="_blank"><img src="public/images/share_icons/twitter128x128.png" width="25"></a>                                
                                 -->
                                <a class="text-dark" href="javascript:void(0);"><i class="fas fa-share-alt ml-2"></i></a>
                                &nbsp;
                                <a href="<?php echo e($share_links['gmail']); ?>" target="_blank"><img src="public/images/share_icons/gmail128x128.png" width="25"></a>
                                
                            </div>                            
                        </div>
                    </div>
                </div>
                <?php }?>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Fulfilment of Services</label>
                    <div class="d-flex">
                        <?php $i = 1;?>
                        <?php $__currentLoopData = $fulfilment_of_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <div class="form-group mr-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio<?php echo e($i); ?>" name="fulfilment_of_services" class="custom-control-input" value="<?php echo e($key); ?>" <?php if($user->fulfilment_of_services && $user->fulfilment_of_services==$key){echo 'checked';}else if($key==0){echo 'checked';}?>>
                                    <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e($value); ?></label>
                                </div>
                            </div>
                            <?php $i++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </div>
                </div>
                <div class="form-group">
                    <label>Expertise Level</label>
                    <div class="d-flex">
                        <?php $__currentLoopData = $expertise_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <div class="form-group mr-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio<?php echo e($i); ?>" name="expertise_level" class="custom-control-input" value="<?php echo e($value); ?>" <?php if($user->expertise_level && $user->expertise_level==$value){echo 'checked';}else if($key==0){echo 'checked';}?>>
                                    <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e(ucfirst(strtolower($value))); ?></label>
                                </div>
                            </div>
                            <?php $i++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </div>
                </div>
                <div class="form-group">
                    <label>Services by</label>
                    <div class="d-flex">                        
                        <?php $__currentLoopData = $service_mode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group mr-4">
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio<?php echo e($i); ?>" name="service_mode" class="custom-control-input" value="<?php echo e($value); ?>" onChange="return showHideServiceChargeOptions(this.value);" <?php if($user->service_mode && $user->service_mode==$value){echo 'checked';}else if($key==0){echo 'checked';}?>>
                                    <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e(ucfirst(strtolower($value))); ?></label>
                                </div>
                            </div>
                            <?php $i++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                    </div>
                </div>
                <p class="text-muted-50 mb-3 h6 font-300">You can set the payments later from settings.</p>
                <?php //if($user->service_mode=="FIXED"){?>
                <div class="form-group" id="fixed_div">
                    <label>Service Charges</label>
                    <input class="form-control cus-input px-2" type="text" id="service_fixed_charge" name="service_fixed_charge" placeholder="$200" maxlength="10" value="<?php if(isset($user->service_fixed_charge))echo "$".$user->service_fixed_charge;?>">
                </div>   
                <?php //}?>             
                <div class="form-group" id="flexible_div">
                    <label class="mb-3">Service Charges</label>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="slider-range"></div>
                        </div>
                    </div>
                    <div class="row slider-labels mt-3">
                        <div class="col-sm-6 caption">
                            <strong>Min:</strong>&nbsp;<span id="slider-range-value1"></span>
                        </div>
                        <div class="col-sm-6 d-flex justify-content-end caption">
                            <strong>Max:</strong>&nbsp;<span id="slider-range-value2"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                                <input type="hidden" name="service_charges_low" id="service_charges_low" value="">
                                <input type="hidden" name="service_charges_high" id="service_charges_high" value="">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Set Availability</label>
                    <div class="select-style-left">
                    <select name="availability_hours" id="availability_hours">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $availibility_hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo $user->availability_hours==$key?'selected':'';?>><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
                </div>
            </div>
        </div>
        <input type="button" id="submit" class="btn btn-dark btn-lg btn-block py-2" value="Save">
        </form>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function () {     
        //$("#locationfield").fancymelocations({theme: "black"});      
        //$("#tagfield").fancymetags({theme: "black"});

        $.ajax({
            type:'GET',
            url:'/GetCountriesStates',
            success:function(data){
                if(data.status=='done'){                   
                    $( "#location_list" ).autocomplete({
                        classes: {
                            "ui-autocomplete": "input-style",
                        },
                        maxShowItems: 10,
                        minLength: 1,
                        source: data.data,
                        select: function(e, item){
                            if(item.item.type==1 && item.item.value!=''){ ////country
                                var selectedCountryIds = $("#selectedCountryIds").val();
                                if (selectedCountryIds.split(",").includes(item.item.id+"")) {
                                } else {
                                    var spanHtml = '<span id="country'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeLocation('+item.item.id+',1)"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                    $("#shownlistLocation").append(spanHtml);
                                    if($("#selectedCountryIds").val()==''){
                                        $("#selectedCountryIds").val(item.item.id);
                                    }else{
                                        $("#selectedCountryIds").val($("#selectedCountryIds").val()+','+item.item.id);
                                    }
                                }
                            }else if(item.item.type==2 && item.item.value!=''){ ////state
                                var selectedStateIds = $("#selectedStateIds").val();
                                if (selectedStateIds.split(",").includes(item.item.id+"")) {
                                } else {
                                    var spanHtml = '<span id="state'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeLocation('+item.item.id+',2)"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                    $("#shownlistLocation").append(spanHtml);
                                    if($("#selectedStateIds").val()==''){
                                        $("#selectedStateIds").val(item.item.id);
                                    }else{
                                        $("#selectedStateIds").val($("#selectedStateIds").val()+','+item.item.id);
                                    }
                                }
                            }                            
                            setTimeout(function(){
                                $('#location_list').val("");
                            },100);
                        },
                        response: function(event, ui) {
                            if (!ui.content.length) {
                                var noResult = { value:"",label:"No results found" };
                                ui.content.push(noResult);
                            }
                        }
                    });
                }
            }
        });
        $.ajax({
            type:'GET',
            url:'/GetTags',
            success:function(data){
                if(data.status=='done'){                   
                    $( "#tag_list" ).autocomplete({
                        classes: {
                            "ui-autocomplete": "tag-style",
                        },
                        minLength: 1,
                        maxShowItems: 10,
                        source: data.data,                       
                        select: function(e, item){
                            var selectedTagIds = $("#selectedTagIds").val();
                            if (selectedTagIds.split(",").includes(item.item.id+"") || item.item.value=='') {
                            } else {
                                var spanHtml = '<span id="tag'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeTag('+item.item.id+')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                $(".fancyme-tags #shownlist").append(spanHtml);
                                if($("#selectedTagIds").val()==''){
                                    $("#selectedTagIds").val(item.item.id);
                                }else{
                                    $("#selectedTagIds").val($("#selectedTagIds").val()+','+item.item.id);
                                }
                            }
                            setTimeout(function(){
                                $('#tag_list').val("");
                            },100);
                        },
                        response: function(event, ui) {
                            if (!ui.content.length) {
                                var noResult = { value:"",label:"No results found" };
                                ui.content.push(noResult);
                            }
                        }
                    });
                }
            }
        });
    });
    function showHideServiceChargeOptions(service_mode){
        if(service_mode=='HOURLY' || service_mode=='FLEXIBLE'){
            $('#fixed_div').hide();
            $('#flexible_div').show();
        }else if(service_mode=='FIXED'){
            $('#fixed_div').show();
            $('#flexible_div').hide();
        }
    }  
    $('#submit').click(function(){
        var user_type = '<?php echo isset($user->user_type)?$user->user_type:'';?>';
        if($("#service_category_id").val()==''){
            alert("Please select category");
            $("#service_category_id").focus();
            return false;
        }else if($("#selectedStateIds").val()=='' && $("#selectedCountryIds").val()==''){
            alert("Please select location(s)");
            $("#location_list").focus();
            return false;
        }if($("#current_location").val()==''){
            alert("Please enter current location");
            $("#current_location").focus();
            return false;
        }if($("#selectedTagIds").val()==''){
            alert("Please select keyword(s)");
            $("#tag_list").focus();
            return false;
        }if($("#job_description").val()==''){
            alert("Please enter job description");
            $("#job_description").focus();
            return false;
        }if($("#driver_license").val()==''){
            alert("Please enter driver license");
            $("#driver_license").focus();
            return false;
        }if($("#ssn").val()==''){
            alert("Please enter SSN");
            $("#ssn").focus();
            return false;
        }if(user_type=='BUSINESS' && $("#ein").val()==''){
            alert("Please enter EIN");
            $("#ein").focus();
            return false;
        }else if ($('input[name="expertise_level"]:checked').length == 0) {
            alert('Please select expertise level');
            return false;     
        }else if ($('input[name="service_mode"]:checked').length == 0) {
            alert('Please select service mode');
            return false;       
        }else if($("#availability_hours").val()==''){
            alert("Please select availability");
            $("#availability_hours").focus();
            return false;
        }else{
            $('#loader').show();
            var formPostData = $('#formProfileSetup').serialize();
            //console.log(formPostData);return false;
            $.ajax({
                type:'POST',
                url:'/profile-setup',
                data:formPostData,
                async: false,
                success:function(data){
                    if(data.status=='done'){
                        localStorage.setItem("action_name", "signup");
                        window.location.href = payment_path;
                    }
                }
            });
        }
    });

    $("#fileInput").change(function(){
        var allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.ms-office', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        var file = this.files[0];
        var fileType = file.type;
        if(!allowedTypes.includes(fileType)){
            alert('Please select a valid file (PDF/DOC/DOCX/JPEG/JPG/PNG/GIF).');
            $("#fileInput").val('');
            return false;
        }else{     
            $('.progress').show();       
            var file = this.files[0];
            var formData = new FormData();
            formData.append("media_files[]", file);
            $.ajax({                
                xhr: function() {
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function(evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = ((evt.loaded / evt.total) * 100);
                            $(".progress-bar").width(percentComplete + '%');
                            $(".progress-bar").html(percentComplete+'%');
                        }
                    }, false);
                    return xhr;
                },
                type: 'POST',
                url: '/api/upload-medias',
                data: formData,
                contentType: false,
                cache: false,
                processData:false,
                beforeSend: function(){
                    $(".progress-bar").width('0%');
                    //$('#uploadStatus').html('<img src="images/loading.gif"/>');
                },
                error:function(){
                    $('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
                },
                success: function(resp){                    
                    if(resp.code == 200){
                        $('.progress').hide();
                        var media_id = resp.media_ids;
                        var media_files = resp.media_files;
                        if($('#attachment_ids').val()!=''){
                            $('#attachment_ids').val($('#attachment_ids').val()+','+media_id[0]);
                        }else{
                            $('#attachment_ids').val(media_id[0]);
                        }                     
                        //$('#fileInput')[0].reset();
                        $('#uploadStatus').append('<p class="docStyle text-success">'+'<i class="fas fa-file mr-2"></i>'+media_files[0]+'</p>');
                    }else if(resp.code == 401){
                        $('#uploadStatus').html('<p class="text-dark">Please select a valid file to upload.</p>');
                    }
                }
            });
        }
    });    
    var wordLen = 700,len;
    $('#job_description').keyup(function(event) {	
        
        if($(this).val()==''){
            $('#rcharst').html(wordLen+' Words');
        }else{
            var words = $(this).val().match(/\S+/g).length;
            if (words > 700) {
                // Split the string on first 200 words and rejoin on spaces
                var trimmed = $(this).val().split(/\s+/, 700).join(" ");
                // Add a space at the end to make sure more typing creates new words
                $(this).val(trimmed + " ");
            }
            else {
                var wordsLeft = wordLen - words;
                if(wordsLeft<=0){
                    $('#rcharst').css({'color':'red'}).prepend('<i class="fa fa-exclamation-triangle"></i>');
                }else{
                    $('#rcharst').css({'color':'black'})
                }
                $('#rcharst').html(wordsLeft+' Word(s) left');
            }    
        }    
    });
    $(document).ready(function(){
        var wordLen = 700,len;
        len = $('#job_description').val().split(/[\s]+/);
        wordsLeft = (wordLen) - len.length;
        if($('#job_description').val()==''){
            $('#rcharst').html('700 Word(s) left');
        }else if(wordsLeft==700){
            $('#rcharst').html(wordsLeft+" Words");
        }else{
            $('#rcharst').html(wordsLeft+' Word(s) left');
        } 

        ////range slider
        var rangeSlider = document.getElementById('slider-range');
        var moneyFormat = wNumb({
            decimals: 0,
            thousand: ',',
            prefix: '$'
        });
        noUiSlider.create(rangeSlider, {
            start: [<?php echo isset($user->service_charges_low)?$user->service_charges_low:1;?>, <?php echo isset($user->service_charges_high)?$user->service_charges_high:100;?>],
            step: 1,
            range: {
            'min': [1],
            'max': [100]
            },
            format: moneyFormat,
            connect: true
        });        
        // Set visual min and max values and also update value hidden form inputs
        rangeSlider.noUiSlider.on('update', function(values, handle) {
            document.getElementById('slider-range-value1').innerHTML = values[0];
            document.getElementById('slider-range-value2').innerHTML = values[1];
            document.getElementById('service_charges_low').value = moneyFormat.from(values[0]);
            document.getElementById('service_charges_high').value = moneyFormat.from(values[1]);
        });
        var service_mode = '';
        <?php if($user->service_mode=="FIXED"){?>
            $("#flexible_div").hide();
            var service_mode = 'FIXED';
        <?php }?>
        if(service_mode==''){service_mode = 'HOURLY';}
        showHideServiceChargeOptions(service_mode);

    });
    function removeTag(span_id){
        $('#tag'+span_id).remove();
        var value = span_id;
        var arr = $("#selectedTagIds").val().split(",");
        arr = arr.filter(function(item) {
            return item != value;
        });
        $("#selectedTagIds").val(arr.join(","));
    }
    function removeLocation(span_id,type){
        if(type==1){
            $('#country'+span_id).remove();
            var value = span_id;
            var arr = $("#selectedCountryIds").val().split(",");
            arr = arr.filter(function(item) {
                return item != value;
            });
            $("#selectedCountryIds").val(arr.join(","));
        }else if(type==2){
            $('#state'+span_id).remove();
            var value = span_id;
            var arr = $("#selectedStateIds").val().split(",");
            arr = arr.filter(function(item) {
                return item != value;
            });
            $("#selectedStateIds").val(arr.join(","));
        }
    }
</script>
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('GOOGLE_API_KEY')); ?>&libraries=places"></script> -->
<script>
$(document).ready(function(){
    init();
});
function init(){
    var address_selected = '<?php echo isset($user->current_location)?false:true;?>';
    if (navigator.geolocation) {
        if(address_selected){
            navigator.geolocation.getCurrentPosition(showPosition);
        }
    }
}
function showPosition(position) {
    var latitude = "latitude=" + position.coords.latitude;
    var longitude = "&longitude=" + position.coords.longitude;
    var query = latitude + longitude + "&localityLanguage=en";
    const Http = new XMLHttpRequest();
    var bigdatacloud_api ="https://api.bigdatacloud.net/data/reverse-geocode-client?";
    bigdatacloud_api += query;
    Http.open("GET", bigdatacloud_api);
    Http.send();
    Http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);
            var address = myObj.locality;
            if(myObj.principalSubdivision!='') address += ', '+myObj.principalSubdivision;
            if(myObj.postcode!='undefined') address += ', '+myObj.postcode;
            $('#current_location').val(address);
        }
    };
    $("#current_location_lat_long").val(position.coords.latitude+','+position.coords.longitude);
}
// function showPosition(position) {
//     //var address = getReverseGeocodingData(position.coords.latitude,position.coords.longitude);    
//     //$('#current_location').val(address);
//     //$("#current_location_lat_long").val(position.coords.latitude+','+position.coords.longitude);
// } 
$('#service_fixed_charge').keydown(function(event){        
    if ( event.keyCode == 46 || event.keyCode == 8 ) {
    }
    else {
        if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault(); 
        }             
    }
});
// function initialize() {
//     var input = document.getElementById('current_location');
//     new google.maps.places.Autocomplete(input);
// }
// google.maps.event.addDomListener(window, 'load', initialize);
</script>
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/profile-setup.blade.php ENDPATH**/ ?>