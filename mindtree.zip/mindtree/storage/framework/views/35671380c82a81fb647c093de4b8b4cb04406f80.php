
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                    <button type="button" class="btn btn-sm btn-dark px-5">Update</button>
                </div>
                <div class="row mt-5">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">                        
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/password-and-security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('notifications')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- section 2 -->
                        <div class="w-100 mb-2">
                            <a class="text-dark text-decoration" data-toggle="collapse"
                                href="#passwordAccordian" role="button" aria-expanded="false"
                                aria-controls="collapseExample">
                                <div class="bg-light p-3 d-flex justify-content-between align-items-center">
                                    <h5 class="font-300 mb-0">Password</h5>
                                    <i class="fas fa-caret-down fa-lg cursor-pointer"></i>
                                </div>
                            </a>
                            <div class="collapse show" id="passwordAccordian">
                                <div class="col-lg-12">
                                    <div class="d-flex align-items-center my-4">
                                        <div class="flex-shrink-0 mr-4">
                                            <i class="far fa-check-circle fa-2x"></i>
                                        </div>
                                        <div class="w-100">
                                            <p class="mb-0 text-muted">Password has been set</p>
                                            <p class="mb-0 text-muted">Choose a Strong,unique password that's at
                                                least 8 characters long.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="password" class="form-control cus-input"
                                                    placeholder="Old Password" />
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="password" class="form-control cus-input"
                                                    placeholder="New Password" />
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="row mb-3">
                                                <div class="col-sm-4 pr-lg-1 text-center">
                                                    <div class="d-flex flex-column">
                                                        <div class="bg-warning height-6 mb-1"></div>
                                                        <span class="small">Weak</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 pr-lg-1 text-center">
                                                    <div class="d-flex flex-column">
                                                        <div class="bg-success height-6 mb-1 opacity-4"></div>
                                                        <span class="small">Good</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 pr-lg-1 text-center">
                                                    <div class="d-flex flex-column">
                                                        <div class="bg-success height-6 mb-1"></div>
                                                        <span class="small">Strong</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 text-center">
                                            <div class="form-group">
                                                <input type="password" class="form-control cus-input"
                                                    placeholder="Confirm Password" />
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <div class="custom-control custom-checkbox mr-sm-2">
                                                <input type="checkbox" class="custom-control-input"
                                                    id="customControlAutosizing">
                                                <label class="custom-control-label font-500 small"
                                                    for="customControlAutosizing">Require that all devices sign
                                                    in with new password</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-12 m-auto">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-12 col-12 px-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                <a href="choose_following_options.html"
                                                    class="btn btn-secondary btn-sm mb-0 w-100 text-white"
                                                    type="button">Cancel</a>
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-12 col-12 px-1">
                                                <a href="choose_following_options.html"
                                                    class="btn btn-dark btn-sm mb-0 w-100 text-white"
                                                    type="button">Save</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- section 2 -->
                        <!-- section 3-->
                        <div class="border w-100 mb-2">
                            <a class="text-dark text-decoration" data-toggle="collapse"
                                href="#two-stepAccordian" role="button" aria-expanded="false"
                                aria-controls="collapseExample">
                                <div class="bg-light p-3 d-flex justify-content-between align-items-center">
                                    <h6 class="font-300 mb-0">Two Step Verification</h6>
                                    <i class="fas fa-caret-down fa-lg cursor-pointer"></i>
                                </div>
                            </a>
                            <div class="collapse" id="two-stepAccordian">
                                <div class="col-lg-12 border-bottom">
                                    <p class="my-3">Security Question <span class="ml-2"><i class="fas fa-pencil-alt"></i></span></p>
                                    <div class="d-flex align-items-center my-4">
                                        <div class="flex-shrink-0 mr-4">
                                            <i class="far fa-check-circle fa-2x"></i>
                                        </div>
                                        <div class="w-100">
                                            <p class="mb-0 text-muted">Security Questions has been enabled</p>
                                            <p class="mb-0 text-muted">Confrim Your identity with a question only you know the answer to.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <p class="my-3">Phone Verification <span class="ml-2"><i class="fas fa-pencil-alt"></i></span></p>
                                    <div class="d-flex align-items-center my-4">
                                        <div class="flex-shrink-0 mr-4">
                                            <i class="far fa-check-circle fa-2x"></i>
                                        </div>
                                        <div class="w-100">
                                            <p class="mb-0 text-muted">Phone verification has been enabled</p>
                                            <p class="mb-0 text-muted">Recieve a unique 6-digit code to enter along with your password</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <p>Your Fav Teacher</p>
                                    <div class="form-group position-relative">
                                        <input class="form-control cus-input px-2" type="text" placeholder="......">
                                        <i class="fas fa-plus-square fa-2x position-absolute rightIcon text-muted"></i>
                                    </div>
                                    <div class="form-group">
                                        <div class="select-style-left">
                                            <select>
                                                <option>Your Best Friend Name</option>
                                                <option>Your First School Name</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control cus-input" placeholder="Answer">
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 mb-sm-0 mb-2">
                                                <a href="#" class="btn btn-secondary btn-sm mb-0 w-100 text-white" type="button">Cancel</a>
                                            </div>
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-dark btn-sm mb-0 w-100 text-white" type="button">Save</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 my-4">
                                    <p class="mb-2">Email</p>
                                    <span class="w-100 text-muted">*******0909</span>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group position-relative">
                                        <input class="form-control cus-input px-2" type="text" placeholder="......">
                                        <i class="fas fa-pen-square fa-2x position-absolute rightIcon text-muted"></i>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-secondary btn-sm mb-sm-0 mb-2 w-100 text-white" type="button">Cancel</a>
                                            </div>
                                            <div class="col-sm-6">
                                                <a href="#" class="btn btn-dark btn-sm mb-0 w-100 text-white" type="button">Save</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- section 3-->
                        <!-- section 4-->
                        <div class="border w-100">
                            <a class="text-dark text-decoration" data-toggle="collapse"
                                href="#notificationAccordian" role="button" aria-expanded="false"
                                aria-controls="collapseExample">
                                <div class="bg-light p-3 d-flex justify-content-between align-items-center">
                                    <h6 class="font-300 mb-0">Notifications</h6>
                                    <i class="fas fa-caret-down fa-lg cursor-pointer"></i>
                                </div>
                            </a>
                            <div class="collapse" id="notificationAccordian">
                                <div class="col-lg-12 border-bottom">
                                    <p class="mt-4">Desktop</p>
                                    <div class="custom-control custom-checkbox recover_pass mr-sm-2 my-3">
                                        <input type="checkbox" class="custom-control-input" id="customControlAutosizing1">
                                        <label class="custom-control-label font-500" for="customControlAutosizing1">Send Notifications</label>
                                    </div>
                                    <p class="mt-4">Mobile</p>
                                    <div class="custom-control custom-checkbox recover_pass mr-sm-2 my-3">
                                        <input type="checkbox" class="custom-control-input" id="customControlAutosizing2">
                                        <label class="custom-control-label font-500" for="customControlAutosizing2">Send Notifications</label>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        <!-- section 4-->  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    
});
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/password-and-security.blade.php ENDPATH**/ ?>