
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">                        
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- section 2 -->
                        <div class="w-100 mb-2">
                            <a class="text-dark text-decoration" data-toggle="collapse"
                                href="#passwordAccordian" role="button" aria-expanded="false"
                                aria-controls="collapseExample">
                                <div class="bg-light p-3 d-flex justify-content-between align-items-center">
                                    <h5 class="font-300 mb-0">Password</h5>
                                    <i class="fas fa-caret-down fa-lg cursor-pointer"></i>
                                </div>
                            </a>
                            <div class="collapse show" id="passwordAccordian">
                                <div class="col-lg-12">
                                    <div class="d-flex align-items-center my-4">
                                        <div class="flex-shrink-0 mr-4">
                                            <i class="far fa-check-circle fa-2x"></i>
                                        </div>
                                        <div class="w-100">
                                            <p class="mb-0 text-muted">Password has been set</p>
                                            <p class="mb-0 text-muted">Choose a strong, unique password that's at least 8 characters long.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="password" name="old_password" id="old_password" class="form-control cus-input" placeholder="Old Password" />
                                            </div>
                                        </div>                                        
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <input type="password" id="password" name="password" class="form-control cus-input" placeholder="New Password" />
                                            </div>
                                        </div>
                                        <div class="col-sm-6" id="password-label" style="display:none">
                                            <div class="row mb-3">
                                                <div class="col-sm-4 pr-lg-1 text-center" id="password-weak" style="display:none">
                                                    <div class="d-flex flex-column">
                                                        <div class="bg-warning height-6 mb-1"></div>
                                                        <span class="small">Weak</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 pr-lg-1 text-center" id="password-good" style="display:none">
                                                    <div class="d-flex flex-column">
                                                        <div class="bg-success height-6 mb-1 opacity-4"></div>
                                                        <span class="small">Good</span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 pr-lg-1 text-center" id="password-strong" style="display:none">
                                                    <div class="d-flex flex-column">
                                                        <div class="bg-success height-6 mb-1"></div>
                                                        <span class="small">Strong</span>
                                                    </div>
                                                </div>  
                                            </div>
                                        </div>                                        
                                        <div class="col-lg-12 text-center">
                                            <div class="form-group">
                                                <input type="password" name="password-conf" id="password-conf" class="form-control cus-input" placeholder="Confirm Password" />
                                            </div>
                                        </div>                                       
                                    </div>
                                    <div class="col-sm-12 col-12 m-auto">
                                        <div class="row">                                           
                                            <div class="col-lg-12 col-md-6 col-sm-12 col-12 px-1">
                                                <button id="btn-update-password" class="btn btn-dark btn-sm mb-0 w-100 text-white" type="button">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- section 2 -->
                        <!-- section 3-->
                        <div class="border w-100 mb-2">
                            <a class="text-dark text-decoration" data-toggle="collapse"
                                href="#two-stepAccordian" role="button" aria-expanded="false"
                                aria-controls="collapseExample">
                                <div class="bg-light p-3 d-flex justify-content-between align-items-center">
                                    <h6 class="font-300 mb-0">Two Step Verification</h6>
                                    <i class="fas fa-caret-down fa-lg cursor-pointer"></i>
                                </div>
                            </a>
                            <div class="collapse" id="two-stepAccordian">
                                <div class="col-lg-12 border-bottom">
                                    <div class="my-3 d-flex justify-content-between">
                                    <p data-toggle="modal" data-target="#securityQuestionModal">Security Question <span class="ml-2 cursor-pointer"><i class="fas fa-pencil-alt"></i></span></p>
                                    <label class="switch">
                                      <input type="checkbox" id="switch1" name="switch1" value="1" <?php if($user->user_settings->two_step_verification_question==1): ?> checked <?php endif; ?>>
                                      <span class="slider round"></span>
                                    </label>
                                    </div>
                                    <input type="hidden" id="total_question_added" value="<?php echo e(count($user->user_security_questions)); ?>">
                                    <div class="d-flex align-items-center my-4">
                                        <div class="flex-shrink-0 mr-4" id="two_step_status">
                                            <?php if($user->user_settings->two_step_verification_question==1): ?>
                                                <i class="far fa-check-circle fa-2x"></i>
                                            <?php else: ?>
                                                <i class="fas fa-times-circle fa-2x"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="w-100">
                                            <p class="mb-0 text-muted">Security Questions has been enabled</p>
                                            <p class="mb-0 text-muted">Confrim Your identity with a question only you know the answer to.</p>
                                        </div>
                                    </div>                                    
                                    <div class="d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center">
                                        <ul class="list-inline w-50" id="added_questions">                    
                                            <?php if(count($user->user_security_questions)>0): ?>
                                            <?php $__currentLoopData = $user->user_security_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="bg-light p-2 mb-2 rounded d-flex justify-content-between align-items-center">
                                                <p class="mb-0"><?php echo e($loop->iteration); ?>) <?php echo e($question->security_question); ?></p>
                                                <a href="javascript:void(0);" onClick="removeQuestion(<?php echo e($question->id); ?>)" class="text-muted">
                                                    <i class="fas fa-times-circle"></i> 
                                                </a>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>                                    
                                </div>
                                <div class="col-lg-12">
                                    <div class="my-3 d-flex justify-content-between">
                                    <p>Phone Verification <span class="ml-2"></span></p>
                                    <label class="switch">
                                      <input type="checkbox" id="switch2" name="switch2" value="1" <?php if($user->user_settings->two_step_verification_phone==1): ?> checked <?php endif; ?>>
                                      <span class="slider round"></span>
                                    </label>
                                    </div>
                                    <div class="d-flex align-items-center my-4">
                                        <div class="flex-shrink-0 mr-4" id="phone_status">
                                            <?php if($user->user_settings->two_step_verification_phone==1): ?>
                                                <i class="far fa-check-circle fa-2x"></i>
                                            <?php else: ?>
                                                <i class="fas fa-times-circle fa-2x"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="w-100">
                                            <p class="mb-0 text-muted">Phone verification has been enabled</p>
                                            <p class="mb-0 text-muted">Recieve a unique 6-digit code to enter along with your password</p>
                                        </div>
                                    </div>
                                </div>                                
                                <div class="col-lg-6 my-4">
                                    <p class="mb-2">Phone</p>
                                    <span class="w-100 text-muted">******<?php echo e(substr($user->mobile,6)); ?></span>
                                </div>                                
                            </div>
                        </div>
                        <!-- section 3--> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- modal content -->
<div class="modal fade" id="securityQuestionModal" tabindex="-1" role="dialog" aria-labelledby="securityQuestionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="close rightCorner" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <form>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12"> 
                        <p>Security question has been enabled</p>   
                        <p>Confirm your identity with a question only you know the answer to.</p>
                        <hr/>
                        <p>Please Select Your Security Question</p>
                        <div class="form-group">
                            <div class="select-style-left">
                                <select name="security_question" id="security_question">
                                    <option value="">Select</option>
                                    <?php if(count($user->security_questions)>0): ?>
                                        <?php $__currentLoopData = $user->security_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $security_question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($security_question->id); ?>"><?php echo e($security_question->security_question); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" id="security_answer" name="security_answer" class="form-control cus-input"  placeholder="Answer"/>
                        </div>
                    </div>            
                </div>
                <div class="d-flex justify-content-end small text-muted mb-2">
                    You can select maximum 3 Security questions  
                </div>
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn" onClick="AddSecurityQuestion(0);">Add More</button>
                    &nbsp;
                    <button type="button" class="btn btn-dark" onClick="AddSecurityQuestion(1);">Save</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<!-- modal content -->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
var pattern = new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{6,}$/);
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    
});
$('#password').keyup(function(){
    if($(this).val().length<1){
        $("#password-label").hide();
        $("#password-weak").hide();
        $("#password-good").hide();
        $("#password-strong").hide();
    }else if($(this).val().length<=4){
        $("#password-label").show();
        $("#password-weak").show();
        $("#password-good").hide();
        $("#password-strong").hide();
    }else if($(this).val().length>6 && !pattern.test($(this).val())){
        $("#password-label").show();
        $("#password-good").show();
        $("#password-weak").hide();
        $("#password-strong").hide();
    }else if($(this).val().length>6 && pattern.test($(this).val()) ){
        $("#password-label").show();			
        $("#password-strong").show();
        $("#password-weak").hide();
        $("#password-good").hide();
    }
});
$("#btn-update-password").click(function(e){		
    e.preventDefault();
    if($('#old_password').val()==''){
        alert("Please enter old password.");
        return false;
    }else if($('#password').val()==''){
        alert("Please enter password.");
        $('#password').focus();
        return false;
    }else if($('#password').val().length<6){
        alert("Password should be minimum 6 characters.");
        $('#password').focus();
        return false;
    }else if($('#password-conf').val()==''){
        alert("Please enter confirm password.");
        $('#password-conf').focus();
        return false;
    }else if($('#password').val()!=$('#password-conf').val()){
        alert("Password and confirm password does not match.");
        $('#password').focus();
        return false;	
    }else{
        var formData = {action:'UpdatePassword',old_password:$('#old_password').val(),password:$('#password').val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data:formData,
            async: false,
            success:function(data){
                if(data.code==200){
                    alert("Your password has been reset successfully.");
                    window.location.href= document.URL;
                }else if(data.code==212){
                    alert(data.message);
                    $('#password').focus();
                    return false;
                }
            }
        });
    }
});	
function AddSecurityQuestion(is_close_popup){
    if($('#security_question').val()==''){
        alert("Please select security question.");
        $('#security_question').focus();
        return false;	
    }else if($('#security_answer').val()==''){
        alert("Please enter answer.");
        $('#security_answer').focus();
        return false;	
    }else{
        var formData = {action:'AddUserSecurityQuestion',question:$('#security_question').val(),answer:$('#security_answer').val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data:formData,
            async: false,
            success:function(data){
                if(data.code==200){
                    alert("Question added successfully.");
                    var li_questions = '';
                    var k=0
                    var added_questions = data.questions;
                    $("#total_question_added").val(added_questions.length);
                    for (i in added_questions) {
                        k = parseInt(i)+1;
                        li_questions +='<li class="bg-light p-2 mb-2 rounded d-flex justify-content-between align-items-center">';
                        li_questions +='<p class="mb-0">'+k+') '+added_questions[i].security_question+'</p>';
                        li_questions +='<a href="javascript:void(0);" onClick="removeQuestion('+added_questions[i].id+')" class="text-muted">';
                        li_questions +='<i class="fas fa-times-circle"></i>';
                        li_questions +='</a></li>';
                    }                  
                    $("#added_questions").html(li_questions);
                    $("#security_question").val("");
                    $("#security_answer").val("");
                    if(is_close_popup==1){                        
                        $(".close").trigger("click");
                    }                   
                }else{
                    alert("Already added");
                    return false;
                }
            }
        });
    }
}
function removeQuestion(id){
    $.ajax({
        type: 'DELETE',
        url: '/api/delete-user-question/' + id,
        async: false,
        success: function(data) {
            if (data.code == 200) {
                var li_questions = '';
                var k=0
                var added_questions = data.questions;
                $("#total_question_added").val(added_questions.length);
                for (i in added_questions) {
                    k = parseInt(i)+1;
                    li_questions +='<li class="bg-light p-2 mb-2 rounded d-flex justify-content-between align-items-center">';
                    li_questions +='<p class="mb-0">'+k+') '+added_questions[i].security_question+'</p>';
                    li_questions +='<a href="javascript:void(0);" onClick="removeQuestion('+added_questions[i].id+')" class="text-muted">';
                    li_questions +='<i class="fas fa-times-circle"></i>';
                    li_questions +='</a></li>';
                } 
                $("#added_questions").html(li_questions);
                if(added_questions.length<2){
                    $.ajax({
                        type: 'POST',
                        url: '/AjaxRequest',
                        data: {action:'UpdateUserSettings',two_step_verification_question:0},
                        async: false,
                        success: function(data) {    
                            $("#two_step_status").html('<i class="fas fa-times-circle fa-2x"></i>');        
                        }
                    });
                    $("#switch1").prop('checked',false);
                }
            }
        }
    });
}
$("#switch1").click(function(){
    if($(this).prop("checked") == true){
        if($("#total_question_added").val()<2){
            $("#securityQuestionModal").modal();
            return false;
        }else{
            $("#two_step_status").html('<i class="far fa-check-circle fa-2x"></i>');
            var two_step_verification_question = 1;
        }        
    }else{
        $("#two_step_status").html('<i class="fas fa-times-circle fa-2x"></i>');
        var two_step_verification_question = 0;
    }
    $.ajax({
        type: 'POST',
        url: '/AjaxRequest',
        data: {action:'UpdateUserSettings',two_step_verification_question:two_step_verification_question},
        async: false,
        success: function(data) {            
        }
    });
});
$("#switch2").click(function(){
    if($(this).prop("checked") == true){
        $("#phone_status").html('<i class="far fa-check-circle fa-2x"></i>');        
        var two_step_verification_phone = 1;
    }else{
        $("#phone_status").html('<i class="fas fa-times-circle fa-2x"></i>');
        var two_step_verification_phone = 0;
    }
    $.ajax({
        type: 'POST',
        url: '/AjaxRequest',
        data: {action:'UpdateUserSettings',two_step_verification_phone:two_step_verification_phone},
        async: false,
        success: function(data) {            
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/security.blade.php ENDPATH**/ ?>