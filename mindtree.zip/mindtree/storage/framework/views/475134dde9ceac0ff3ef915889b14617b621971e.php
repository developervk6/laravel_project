
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-5">
        <div class="text-center">
            <h2>Please Add Your Payment Method</h2>
        </div>
        <div class="row mt-5">
            <div class="col-lg-5 m-auto">
                <div class="form-group position-relative">
                    <input class="form-control form-control-lg pl-5" type="text" placeholder="Use/integrate Stripe">
                    <i class="fab fa-cc-stripe fa-lg text-primary position-absolute leftIcon"></i>
                </div>
                <div class="form-group">
                    <div class="text-center">OR</div>
                </div>
                <div class="form-group">
                    <label>Use Credit/Debit Card</label>
                    <input class="form-control form-control-lg" type="text" name="card_holder_name" id="card_holder_name" placeholder="Card Holder Name">
                </div>
                <div class="form-group position-relative">
                    <input class="form-control form-control-lg pl-5" type="text" placeholder="Card Number">
                    <i class="fab fa-cc-visa fa-lg text-muted position-absolute leftIcon"></i>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-lg-0 mb-md-0 mb-sm-0 mb-3">
                            <input class="form-control form-control-lg" type="text" placeholder="Expiry Date">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                            <input class="form-control form-control-lg" type="text" placeholder="CVV">
                        </div>
                    </div>
                </div>
                <div class="form-group mt-4">
                    <button class="btn btn-dark btn-sm btn-block" type="button" id="btn-submit">Add</button>                    
                    <button class="btn btn-outline-dark btn-sm btn-block" type="button" id="btn-skip">Skip</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">   
            <div class="bg-white shadow cus-rounded pb-5">
                <p class="pt-5 pb-4 h5 font-300 text-center px-2">Congratulations! You've Completed <br /> Registration
                            Process.</p>
                <div class="col-sm-9 m-auto">
                    <div class="col-lg-6 m-auto mb-3">
                        <img class="img-fluid animated bounce" src="public/images/congratulations.png" alt="congratulation" />
                    </div>
                    <p class="text-center mt-4">You're All Set! <br/> Please post your first job.</p>
                </div>
            </div>
    </div>
  </div>
</div>  

<div id="myModalCreateJob" class="modal fade" role="dialog" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">   
            <div class="bg-white shadow cus-rounded pb-5">
                <p class="pt-5 pb-4 h5 font-300 text-center px-2">Congratulations!<br> You've Posted a New Job</p>
                <div class="col-sm-9 m-auto">
                    <div class="col-lg-6 m-auto mb-3">
                        <img class="img-fluid animated bounce" src="public/images/congratulations.png" />
                    </div>
                </div>
            </div>
    </div>
  </div>
</div> 
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<script>
$("#btn-submit").click(function(e){		
    e.preventDefault();
    if($('#card_holder_name').val()==''){
        alert("Please enter card holder name.");
        $('#card_holder_name').focus();
        return false;	
    }else{
        var action_name = localStorage.getItem("action_name");
        if(action_name=='create_job'){
            $('#myModalCreateJob').modal('toggle'); 
        }else{
            $('#myModal').modal('toggle'); 
        }     
        setTimeout(() => {
            window.location.href = home_path;
        }, 5000);  
    }
});
$("#btn-skip").click(function(e){  
    var action_name = localStorage.getItem("action_name");
    if(action_name=='create_job'){
        $('#myModalCreateJob').modal('toggle'); 
    }else{
        $('#myModal').modal('toggle'); 
    }        
    setTimeout(() => {
        window.location.href = home_path;
    }, 5000);  
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/payment-method.blade.php ENDPATH**/ ?>