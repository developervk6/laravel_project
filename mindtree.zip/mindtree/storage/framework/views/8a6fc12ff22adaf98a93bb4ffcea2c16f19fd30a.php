
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container">
    <p class="text-center my-5 h4 font-300 px-2" id="form-total-h-0">Please Complete your Registration Process for <br /> <strong>Better Experience</strong></p>
	<div class="wizard-form">
		<form class="form-register" action="" method="post" id="signupstep2From">
        <input type="hidden" name="id" id="id" value="<?php echo e($id); ?>">
        <input type="hidden" name="user_type" id="user_type" value="<?php echo e($user_type); ?>">
        <input type="hidden" name="verification_code_user" id="verification_code_user" value="<?php isset($verification_code)?$verification_code:'';?>">
			<div id="form-total">
				<!-- SECTION 1 -->
				<h2>1</h2>
				<section>
					<div class="col-lg-5 m-auto">
						<div class="bg-white shadow cus-rounded pb-5">
							<div class="col-sm-9 m-auto">
								<div class="col-lg-12 text-center mb-3">
									<form>
										<div class="col-lg-12 userImg float-left py-4">
											<div class="rounded-circle uploadImg shadow m-auto bg-white position-relative">
												<span id="profile_image_span">
													<?php if(isset($profile_image) && !empty($profile_image)){
														echo '<img src="'.$profile_image.'" style="width:100px">';
													}else{
														echo '<i class="fas fa-user fa-3x position-absolute setIcon"></i>';
													}?>
												</span>
												<input class="custom-file-input" type="file" name="image" id="image" title="" onChange="return uploadprofilephoto('signupstep2From');"/>
												<input type="hidden"  title="" name="profile_image" id="profile_image" value="<?php if(isset($profile_image)){echo $profile_image;}?>">
											</div>
											<span class="mt-2 d-block">Upload Picture</span>
										</div>
										<?php if($user_type!='BUSINESS'){?>
                                        <div class="form-group">
											<input type="text" id="first_name" name="first_name" class="form-control cus-input text-center"  placeholder="First Name" value="<?php echo e($first_name); ?>" />
										</div>
										<div class="form-group">
											<input type="text" id="last_name" name="last_name" class="form-control cus-input text-center"  placeholder="Last Name" value="<?php echo e($last_name); ?>"/>
										</div>
                                        <?php }else {?>
                                        <div class="form-group">
											<input type="text" id="business_name" name="business_name" class="form-control cus-input text-center"  placeholder="Business Name" />
										</div>
                                        <?php }?>
										<div class="form-group">
											<input type="email" id="email" name="email" class="form-control cus-input text-center" placeholder="Email Address" value="<?php echo e($email); ?>" <?php if(isset($email))echo 'readonly';	?> />
										</div>
										<div class="form-group">
										   <div class="input-group mb-3">
											  <div class="input-group-prepend">
												<span class="input-group-text bg-white p-0" id="password-icon">
                                                    <select name="country_code" id="country_code" class="border-0 bg-white cus-input">
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($country->phonecode); ?>" <?php echo ($country->phonecode=='1'?'selected':'')?>>+<?php echo e($country->phonecode); ?> (<?php echo e($country->sortname); ?>)</option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <option></option>
                                                    </select>
                                                </span>
											  </div>
											  <input type="text" id="mobile" maxlength="10" name="mobile" class="form-control cus-input text-center"  placeholder="Phone Number" />
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</section>
				<!-- SECTION 2 -->
				<h2>2</h2>
				<section>
					<div class="col-lg-5 m-auto">
						<div class="bg-white shadow cus-rounded py-5">
							<p class="pb-3 h4 font-300 text-center px-2">Congratulations!
								<br /> You're Almost Done</p>
							<div class="col-sm-9 m-auto">
								<div class="col-lg-12 text-center mb-3">
									<p class="text-muted mb-4 small">Please Provide 4 Digit Verification code sent to your Email Address &amp; Phone Number.</p>
									<form>
										<div class="form-group d-flex justify-content-center">
											<div class="row">
												<!-- <div class="col-lg-12 pr-1">
													<input type="text" name="verifivation_code" id="verification_code" class="form-control cus-input text-center" />												
												</div> -->
												<div class="col pr-1">
													<input type="text" id="otp1" class="form-control cus-input text-center" maxlength="1" onkeyup="validateOtpInput(this.value,1);"/>
												</div>
												<div class="col px-1">
													<input type="text" id="otp2" class="form-control cus-input text-center"  maxlength="1" onkeyup="validateOtpInput(this.value,2);"/>
												</div>
												<div class="col px-1">
													<input type="text" id="otp3" class="form-control cus-input text-center"  maxlength="1" onkeyup="validateOtpInput(this.value,3);"/>
												</div>
												<div class="col pl-1">
													<input type="text" id="otp4" class="form-control cus-input text-center"  maxlength="1" onkeyup="validateOtpInput(this.value,4);"/>
												</div>
											</div>
										</div>
									</form>
								</div>
								<p class="d-flex justify-content-center">Didn't Recieve Code? <a class="text-dark ml-2" href="javascript:void(0);" onClick="return ResendVerificationCode();"><b>Send Again</b></a></p>
							</div>
						</div>
					</div>
				</section>
				<!-- SECTION 3 -->
				<h2>3</h2>
				<section>
					<div class="col-lg-5 m-auto">
						<div class="bg-white shadow rounded pb-5">
							<p class="pt-5 pb-4 h5 font-300 text-center px-2">Please Provide Following Details</p>
							<div class="col-sm-9 m-auto">
								<div class="col-lg-12 text-center mb-3">
									<form>										
										<div class="form-group">
											<input type="hidden" id="country" name="country" value="">
										   	<input type="text" id="country_name" name="country_name" readonly class="form-control cus-input text-center" value="">
                                        </div>
										<!-- <div class="form-group" style="display:none;">
                                           <div class="select-style">
                                            <select name="country" id="country" onChange="populateStatesOfCountry(this.value);">                                               
                                            </select>
                                            </div>
										</div> -->
										<div class="form-group">
                                           <div class="select-style">
                                                <select name="state" id="state" onChange="populateCitiesOfState(this.value);">
                                                    <option class="">State</option>                                               
                                                </select>
                                            </div>
										</div>
                                        <div class="form-group">
                                           <div class="select-style">
                                            <select name="city" id="city">
                                                <option class="">City</option>                                                
                                            </select>
                                            </div>
										</div>
										<div class="form-group">
											<input type="text" id="zipcode" maxlength="6" class="form-control cus-input text-center" placeholder="Zip Code"/>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</section>
				<!-- SECTION 4 -->
				<h2>4</h2>
				<section>
					<div class="col-lg-5 m-auto">
						<div class="bg-white shadow cus-rounded pb-5">
							<p class="pt-5 pb-4 h5 font-300 text-center px-2">Congratulations! You've Completed <br /> Registration
                                        Process.</p>
							<div class="col-sm-9 m-auto">
								<div class="col-lg-6 m-auto mb-3">
									<img class="img-fluid animated bounce" src="public/images/congratulations.png" alt="congratulation" />
								</div>
								<p class="text-center mt-4">You're All Set! <br/> Please post your first job.</p>
							</div>
						</div>
					</div>
				</section>
			</div>
		</form>
	</div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<!-- Footer section -->
<script>
function validateOtpInput(otp,box){
	if(otp==''){
		if(box!=1){
			var box = parseInt(box)-1;
			$("#otp"+box).focus();
		}
	}else if(isNaN(otp)){
		alert("Invalid otp");
	}else if(otp!=''){
		if(box<4){
			var box = parseInt(box)+1;
			$("#otp"+box).focus();
		}
	}
}
</script>
<style>
    .disabled {
        pointer-events: none;
        cursor: default;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/complete-profile.blade.php ENDPATH**/ ?>