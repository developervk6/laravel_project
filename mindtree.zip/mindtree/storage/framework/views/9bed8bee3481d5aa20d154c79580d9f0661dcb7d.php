
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <h2 class="mb-3 text-sm-left text-center">My Subscribers (<?php echo e($my_subscribers->total()); ?>)</h2>
                <!-- section 1 -->
                <?php if($my_subscribers->total()): ?>
                <?php $__currentLoopData = $my_subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->last): ?>
                <div class="d-flex justify-content-sm-between flex-sm-row flex-column">
                <?php else: ?>
                <div class="d-flex justify-content-sm-between flex-sm-row flex-column border-bottom">
                <?php endif; ?>
                    <div class="d-flex text-sm-left text-center flex-sm-row flex-column py-4">
                        <div class="flex-shrink-0 mb-lg-0 mb-md-0 mb-sm-0 mb-4">
                            <a href="/profile/<?php echo e($subscriber->id); ?>" class="text-center">
                                <img class="rounded-circle img-50 mr-3" src="<?php echo e(getUserProfileImage($subscriber->profile_thumb_image)); ?>"/>
                            </a>
                        </div>
                        <div class="w-100">
                            <a href="/profile/<?php echo e($subscriber->id); ?>" class="text-muted">
                                <h5><?php if($subscriber->user_type=='BUSINESS'): ?> <?php echo e($subscriber->business_name); ?> <?php else: ?> <?php echo e($subscriber->first_name); ?> <?php echo e($subscriber->last_name); ?> <?php endif; ?></h5>
                            </a>
                            <p class="text-muted mb-0"><?php echo e($subscriber->service_category_name); ?></p>
                        </div>
                    </div>
                    <div class="p-4 dropdown text-sm-left text-center">
                        <div class="d-flex flex-column">
                            <div>
                            <i class="fas fa-star mr-1 text-warning"></i>
                            <i class="fas fa-star mr-1 text-warning"></i>
                            <i class="fas fa-star mr-1 text-warning"></i>
                            <i class="fas fa-star mr-1 text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            </div>
                            <div class="text-sm-right text-center mt-2">
                                <i class="fas fa-heart fa-lg"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $my_subscribers->appends(request()->query())->links()?>
                <?php else: ?>
                    <div class="d-flex justify-content-center align-items-center mb-3 bg-light p-2 rounded border">
                        No records found
                    </div>   
                <?php endif; ?>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
</script> 
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/my-subscribers.blade.php ENDPATH**/ ?>