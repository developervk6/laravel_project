
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                        <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link active" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" role="tab" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" role="tab" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">                                            
                                            <div class="tab-pane fade show active" id="portfolio" role="tabpanel" aria-labelledby="nav-contact-tab">
                                                        <!-- portfolio -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                                <p class="text-dark text-sm-left text-center mb-sm-0 mb-2">Note: <span class="text-muted">To make changes in your portfolio
                                                                        please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white">
                                                                    <span
                                                                        class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                            class="fas fa-pen text-dark"></i></span>
                                                                    Edit</a>
                                                            </div>
                                                        </div>
                                                        <div id="addPortfolio">
                                                            <div class="w-100 d-inline-block border rounded my-4 p-3">
                                                                <!-- portfolio images -->                                                               
                                                                <div class="row" id="setting-portfolio">
                                                                    <?php if(count($user->portfolios)>0): ?>
                                                                    <?php $__currentLoopData = $user->portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(isset($portfolio->cover_media->media_type)): ?>
                                                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4">
                                                                        <div class="card border-0 position-relative">
                                                                            <div class="position-absolute portfolioIcon">
                                                                                <a href="/settings/edit-portfolio/<?php echo e($portfolio->id); ?>">
                                                                                    <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">
                                                                                        <i class="fas fa-pen text-dark"></i>
                                                                                    </span>
                                                                                </a>
                                                                                <a href="javascript:void(0);" onClick="deletePortfolio(<?php echo e($portfolio->id); ?>);"> 
                                                                                    <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">
                                                                                        <i class="fas fa-trash text-dark"></i>
                                                                                    </span>
                                                                                </a>
                                                                            </div>                                                                             
                                                                            <?php if(isset($portfolio->cover_media->media_type) && $portfolio->cover_media->media_type=='youtube'): ?>
                                                                            <?php 
                                                                                $video_arr = explode("?v=",$portfolio->cover_media->media_file);
                                                                                $video_id = $video_arr[1];
                                                                            ?>
                                                                                <iframe width="420" height="315" src="https://www.youtube.com/embed/<?php echo e($video_id); ?>"></iframe>
                                                                            <?php else: ?>
                                                                                <img class="card-img-top" src="<?php echo e(URL($portfolio->cover_media->media_file)); ?>">
                                                                            <?php endif; ?>
                                                                            <div class="card-body px-0">
                                                                                <h5 class="card-title"><?php echo e($portfolio->title); ?></h5>
                                                                                <p class="card-text text-muted"><?php echo e($portfolio->description); ?></p>
                                                                                <!-- <p data-toggle="modal" data-target="#imageSlider">[<?php echo e(count($portfolio->medias)); ?>] Photos</p> -->
                                                                                <a href="javascript:void(0);" onClick="PortfolioImages('<?php echo e($portfolio->media_ids); ?>');">[<?php echo e(count($portfolio->medias)); ?>] Photos</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php else: ?>
                                                                    <div class="p-4">
                                                                        <p class="mb-0 text-muted text-sm-left text-center">No portfolio added.</p>
                                                                    </div>
                                                                    <?php endif; ?>                                                                    
                                                                </div>
                                                                <!-- portfolio images -->
                                                            </div>
                                                            <!-- portfolio -->
                                                            <!-- add portfolio -->
                                                            <div class="border my-4 rounded p-4">
                                                                <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                                                                    <h5 class="font-300">Add Portfolio</h5>
                                                                    <a role="button" id="addButton" class="btn btn-dark text-white" onclick="$('#addPortfolio').hide();$('#addNewPortfolio').show();"><i class="fas fa-plus-circle mr-1"></i> Add</a>
                                                                </div>
                                                                <div class="my-4">
                                                                    <p class="mb-0 text-muted text-sm-left text-center">You can add photos and videos in your portfolio</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- add portfolio -->

                                                        <!-- drag and drop -->
                                                        <form name="" id="frmAddPortfolio" action="" method="post">
                                                        <div class="border rounded p-4 mt-2" id="addNewPortfolio" style="display:none;">
                                                            <div class="row mt-2">
                                                                <div class="col-lg-12">
                                                                    <div class="drapDrop-full rounded d-flex align-items-center justify-content-center mb-lg-0 mb-sm-4 mb-4">
                                                                        <input class="custom-file-input dragDropFile" type="file" id="fileInput" multiple size="50">
                                                                        <p class="text-muted-50 text-center mb-0 position-absolute">Drag your files or <strong>Browse</strong> to upload</p>
                                                                        
                                                                    </div>
                                                                    <p class="font-bold text-center my-3">OR Embed a link
                                                                    </p>
                                                                    <div class="shadow text-center p-3">
                                                                        <a class="text-dark" href="#"
                                                                            data-toggle="modal"
                                                                            data-target="#addVideoLink">
                                                                            <i class="fas fa-video mr-2"></i> Add Video Link
                                                                        </a>
                                                                    </div>
                                                                    <span
                                                                        class="d-block text-center text-muted-50 py-5 border-bottom">Upload
                                                                        .jpg, .gif, .png images upto 10MB each. Images
                                                                        will
                                                                        be displayed at 690px wide, at maximum. You can
                                                                        also
                                                                        embed YouTube or Vimeo videos.</span>
                                                                </div>
                                                            </div>
                                                            <input type="hidden" name="portfolio_media_ids" id="portfolio_media_ids" value="">
                                                            <input type="hidden" name="portfolio_cover_media_id" id="portfolio_cover_media_id" value="">
                                                            <!-- drag and drop -->
                                                            <!-- cover image -->
                                                            <div id="coverImage">
                                                                <div class="row my-3" id="addeed-portfolios">
                                                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4">
                                                                        &nbsp;                                                                        
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- album form -->
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <h5 class="font-300">Album Title/Project Name</h5>
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control cus-input" name="title" id="title" placeholder="Title" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <textarea class="form-control" placeholder="Description" name="description" id="description" rows="4"></textarea>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <button type="button" id="btnAddNewPortfolio" class="btn btn-dark btn-sm btn-block">Save</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- album form -->
                                                        </div>
                                                        </form>
                                                        <!-- cover image-->
                                                    </div>                                                      
                                                </div>
                                            </div>
                                </section>
                                <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Modal -->
<div class="modal fade" id="addVideoLink" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Add a video link</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Paste the link to your Youtube or Vimeo video here</p>
                <form>
                    <div class="form-group">
                        <input type="text" name="video_link" id="video_link" class="form-control cus-input" placeholder="Link" />
                        <p class="mt-2 text-muted-50">Any data which not meet United Market guidlines will be deleted.</p>
                    </div>
                </form>
                    <button type="button" id="btnAddVideoLink" class="btn btn-dark btn-sm btn-block">Save</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<!-- slider Modal -->
<div class="modal fade" id="imageSlider" tabindex="-1" role="dialog" aria-labelledby="imageSliderLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="close font-300 position-absolute rightCorner" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="height:auto;">
                    <ol class="carousel-indicators">
                       
                    </ol>
                    <div class="carousel-inner">
                            
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--slider Modal -->

<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
function PortfolioImages(media_ids){
    var top_li;
    var bottom_li;
    $.ajax({
        type:'GET',
        url:'/common/portfolio-images/'+media_ids,
        async: false,
        success:function(data){
            if(data.code==200){
                $(".carousel-indicators").html("");
                $(".carousel-inner").html("");
                for(var i in data.portfolio_medias){
                    var media = data.portfolio_medias[i];
                    if(i==0){
                        top_li = '<li data-target="#carouselExampleIndicators" data-slide-to="'+i+'" class="active"></li>';
                    }else{
                        top_li = '<li data-target="#carouselExampleIndicators" data-slide-to="'+i+'"></li>';
                    }                    
                    $(".carousel-indicators").append(top_li);
                    if(i==0){
                        bottom_li = '<div class="carousel-item active"><img class="d-block w-100" src="'+media.media_file+'"></div>';
                    }else{
                        bottom_li = '<div class="carousel-item"><img class="d-block w-100" src="'+media.media_file+'"></div>';
                    }                    
                    $(".carousel-inner").append(bottom_li);
                }                 
                $("#imageSlider").modal();       
            }
        }
    });
}
$(document).ready(function(){
   
});
// drag and drop
function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            var htmlPreview =
                '<img class="img-fluid" src="' + e.target.result + '" />'
            //'<p>' + input.files[0].name + '</p>';
            var wrapperZone = $(input).parent();
            var previewZone = $(input).parent().parent().find('.preview-zone');
            var boxZone = $(input).parent().parent().find('.preview-zone').find('.box1').find('.box-body');

            wrapperZone.removeClass('dragover');
            previewZone.removeClass('hidden');
            boxZone.empty();
            boxZone.append(htmlPreview);
        };

        reader.readAsDataURL(input.files[0]);
    }
}
$("#btnAddVideoLink").click(function(){
    if($('#video_link').val()==''){
        alert("Please add video link.");
        $('#video_link').focus();
        return false;    
    }else{
        var formData = {video_link:$('#video_link').val()}  
        $.ajax({
            type:'POST',
            url:'/api/add-video-link',
            data:formData,
            success:function(data){
                if(data.code==200){
                    var media_ids = data.media_ids;
                    var media_files = data.media_files;
                    var media_urls = data.media_urls;
                    var thumbnails = data.thumbnails;
                    var video_ids = data.video_ids;
                    if($('#portfolio_media_ids').val()!=''){
                        $('#portfolio_media_ids').val($('#portfolio_media_ids').val()+','+media_ids[0]);
                    }else{
                        $('#portfolio_media_ids').val(media_ids[0]);
                    }  
                    var media_html = '';
                    media_html += '<div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4" id="portfolio_item_'+media_ids[0]+'">';
                    media_html += '<div class="card border-0 position-relative">';
                    media_html += '<div class="position-absolute portfolioIcon">';
                    media_html += '<a href="javascript:void(0);" onClick="deletePortfolioAddedItem('+media_ids[0]+')">';
                    media_html += '<span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">';
                    media_html += '<i class="fas fa-trash text-dark"></i>';
                    media_html += '</span>';
                    media_html += '</a>';
                    media_html += '</div>';
                    media_html += '<iframe width="420" height="315" src="https://www.youtube.com/embed/'+video_ids[0]+'"></iframe>';
                    media_html += '<div class="card-body px-0">';
                    media_html += '<div class="form-group">';
                    media_html += '<input type="text" name="caption_'+media_ids[0]+'" class="form-control cus-input" placeholder="Enter Caption" />';
                    media_html += '</div>';
                    media_html += '<div class="form-group mr-4">';
                    media_html += '<div class="custom-control custom-radio">';
                    media_html += '<input type="radio" id="customRadio'+media_ids[0]+'" name="customRadio" class="custom-control-input" onclick="setCoverMedia('+media_ids[0]+');">';
                    media_html += '<label class="custom-control-label" for="customRadio'+media_ids[0]+'">Cover Image</label>';
                    media_html += '</div>';
                    media_html += '</div>';
                    media_html += '</div>';
                    media_html += '</div>';
                    media_html += '</div>';
                    $('#addeed-portfolios').prepend(media_html);
                    $(".close").trigger("click");
                }
            }
        });
    }
});
$("#fileInput").change(function(){
    var allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    var file = this.files[0];
    var fileType = file.type;
    if(!allowedTypes.includes(fileType)){
        alert('Please select a valid file (JPEG/JPG/PNG/GIF).');
        $("#fileInput").val('');
        return false;
    }else{     
        $('.progress').show();       
        var file = this.files[0];
        var formData = new FormData();
        formData.append("media_files[]", file);
        $.ajax({                
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = ((evt.loaded / evt.total) * 100);
                        $(".progress-bar").width(percentComplete + '%');
                        $(".progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
            type: 'POST',
            url: '/api/upload-medias',
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                //$(".progress-bar").width('0%');
                //$('#uploadStatus').html('<img src="images/loading.gif"/>');
            },
            error:function(){
                //$('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
            },
            success: function(resp){                    
                if(resp.code == 200){
                    var media_ids = resp.media_ids;
                    var media_files = resp.media_files;
                    var media_urls = resp.media_urls;
                    if($('#portfolio_media_ids').val()!=''){
                        $('#portfolio_media_ids').val($('#portfolio_media_ids').val()+','+media_ids[0]);
                    }else{
                        $('#portfolio_media_ids').val(media_ids[0]);
                    }                     
                    for(i=0;i<media_ids.length;i++){
                        var media_html = '';
                        media_html += '<div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4" id="portfolio_item_'+media_ids[i]+'">';
                        media_html += '<div class="card border-0 position-relative">';
                        media_html += '<div class="position-absolute portfolioIcon">';
                        media_html += '<a href="javascript:void(0);" onClick="deletePortfolioAddedItem('+media_ids[i]+')">';
                        media_html += '<span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">';
                        media_html += '<i class="fas fa-trash text-dark"></i>';
                        media_html += '</span>';
                        media_html += '</a>';
                        media_html += '</div>';
                        media_html += '<img class="card-img-top" src="'+media_urls[i]+'" alt="Card image cap">';
                        media_html += '<div class="card-body px-0">';
                        media_html += '<div class="form-group">';
                        media_html += '<input type="text" name="caption_'+media_ids[i]+'" class="form-control cus-input" placeholder="Enter Caption" />';
                        media_html += '</div>';
                        media_html += '<div class="form-group mr-4">';
                        media_html += '<div class="custom-control custom-radio">';
                        media_html += '<input type="radio" id="customRadio'+media_ids[i]+'" name="customRadio" class="custom-control-input" onclick="setCoverMedia('+media_ids[i]+');">';
                        media_html += '<label class="custom-control-label" for="customRadio'+media_ids[i]+'">Cover Image</label>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                    }
                    $('#addeed-portfolios').prepend(media_html);
                }else if(resp.code == 401){
                    $('#uploadStatus').html('<p class="text-dark">Please select a valid file to upload.</p>');
                }
            } 
        });
    }
});
function deletePortfolioAddedItem(media_id){
    $("#portfolio_item_"+media_id).remove();
    var value = media_id;
    var arr = $("#portfolio_media_ids").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#portfolio_media_ids").val(arr.join(","));
    $.ajax({
        type:'DELETE',
        url:'/api/delete-media/'+media_id,
        async: false,
        success:function(data){
            if(data.code==200){               
            }
        }
    });
}
function setCoverMedia(media_id){
    $("#portfolio_cover_media_id").val(media_id);
}
$('#btnAddNewPortfolio').click(function(e){
    e.preventDefault();
    if($('#title').val()==''){
        alert("Please select title.");
        $('#title').focus();
        return false;
    }else if($('#description').val()==''){
        alert("Please select description.");
        $('#description').focus();
        return false;
    }else{
        var formData = $("#frmAddPortfolio").serialize();
        // var title = $("#title").val();
        // var description = $("#description").val();
        // var portfolio_media_ids = $("#portfolio_media_ids").val();                   
        // var portfolio_cover_media_id = $("#portfolio_cover_media_id").val();
        // var formData = {title:title,description:description,portfolio_media_ids:portfolio_media_ids,portfolio_cover_media_id:portfolio_cover_media_id};     

        $.ajax({
            type:'POST',
            url:'/AddUserPortfolio',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
function deletePortfolio(portfolio_id){
    if(confirm("Are you sure you want to delete this?")){
        $.ajax({
            type:'GET',
            url:'/api/delete-portfolio/'+portfolio_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    window.location.href=document.URL;                 
                }
            }
        });
    }
}
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/portfolio.blade.php ENDPATH**/ ?>