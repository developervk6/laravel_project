<div class="bg-dark p-3 footer">
    <div class="container">
        <p class="mb-0 text-silver text-center">@All  Rights Reserved, United Market 2020</p>
    </div>
</div>
<script src="<?php echo e(URL('/')); ?>/public/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo e(URL('/')); ?>/public/js/jquery.steps.js"></script>
<?php echo view("common.js-vars");?>
<script type="text/javascript" src="<?php echo e(URL('/')); ?>/public/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo e(URL('/')); ?>/public/js/bootstrap.min.js"></script>
<script src="<?php echo e(URL('/')); ?>/public/js/owl/owl.carousel.js"></script>
<script src="<?php echo e(URL('/')); ?>/public/js/common-functions.js"></script>

<script src="<?php echo e(URL('/')); ?>/public/js/two-handle-slider.js"></script>
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
<script src="<?php echo e(URL('/')); ?>/public/js/fancymetags.jQuery.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?php echo e(URL('/')); ?>/public/js/mBox.js"></script>
<script>
  $('.mBox').mBox();
</script>
<script>
    $(document).ready(function () {
        // accordian
        $('.panel-collapse').on('show.bs.collapse', function () {
            $(this).siblings('.panel-heading').addClass('active');
        });

        $('.panel-collapse').on('hide.bs.collapse', function () {
            $(this).siblings('.panel-heading').removeClass('active');
        });
    });

    function myFunction() {
            var dots = document.getElementById("dots");
            var moreText = document.getElementById("more");
            var btnText = document.getElementById("myBtn");

            if (dots.style.display === "none") {
                dots.style.display = "inline";
                btnText.innerHTML = "More"; 
                moreText.style.display = "none";
            } else {
                dots.style.display = "none";
                btnText.innerHTML = "Less"; 
                moreText.style.display = "inline";
            }
        }
</script>
</body>
</html><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/common/footer.blade.php ENDPATH**/ ?>