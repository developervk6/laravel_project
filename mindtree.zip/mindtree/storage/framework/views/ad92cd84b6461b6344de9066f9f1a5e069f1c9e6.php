
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('notifications')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" aria-selected="false">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link active" id="nav-about-tab" href="/settings/team" aria-controls="nav-about" aria-selected="true">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0">                                            
                                        <div class="border rounded my-4 p-3">
                                            <div class="row my-5" id="profile-team">
                                                <?php if(!empty($user->members)): ?>
                                                <?php $__currentLoopData = $user->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-3 col-sm-6 col-12 top-suggestion mb-lg-0 mb-md-3 mb-sm-3 mb-3">
                                                    <div class="card rounded p-3">
                                                        <a href="javascript:void(0);" onClick="deleteTeamMember(<?php echo e($member->id); ?>);" class="text-dark">
                                                        <i class="fas fa-times-circle fa-lg rightIcon position-absolute"></i>
                                                        </a>
                                                        <a href="/profile/<?php echo e($member->id); ?>" class="text-center">
                                                            <img class="rounded-circle m-auto" src="<?php echo e(getUserProfileImage($member->profile_thumb_image)); ?>">
                                                        </a>
                                                        <div class="card-body text-center p-0">
                                                            <a href="/profile/<?php echo e($member->id); ?>" class="text-muted">
                                                                <p class="card-title mt-3 mb-0 font-500"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></p>
                                                            </a>
                                                            <p class="text-muted-50 mb-0">
                                                                <?php echo e($member->service_sub_category_name); ?>

                                                            </p>
                                                            <div class="d-flex justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>                                                
                                                <div class="col-lg-3 col-sm-6 col-12 top-suggestion mb-lg-0 mb-md-3 mb-sm-3 mb-3">
                                                    <a href="#" data-toggle="modal" data-target="#inviteMember" class="card rounded p-3 h-100 text-center">
                                                        <i class="fas fa-plus fa-5x text-muted-50 my-3"></i>
                                                        <p class="text-dark">Add New</p>
                                                    </a>
                                                </div>
                                            </div>
                                        </div> 
                                        </div>  
                                    </div>  
                                </div> 
                            </div>                                           
                        </section>
                        <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->

<!-- Modal -->
<div class="modal fade" id="inviteMember" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel"
     aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered" role="document">
         <div class="modal-content">
             <div class="modal-header pb-0">
                 <h2 class="pl-4 pt-3">Invite Team Member</h2>
                 <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body px-5 pb-5">
                 <form>
                     <div class="form-group">
                         <input type="text" name="email" id="email" class="form-control cus-input" placeholder="Add Email Address" />
                     </div>
                     <div class="form-group">
                        <input type="text" name="join_url" id="join_url" class="form-control cus-input" value="<?php echo e($user->join_url); ?>" readonly/>
                    </div>
                    <div class="form-group">
                        <input type="text" name="business_code" id="business_code" class="form-control cus-input" value="<?php echo e($user->join_code); ?>" readonly/>
                    </div>
                 </form>
                 <div class="row">
                 <div class="col-lg-12 m-auto">
                     <button type="button" onClick="AddTeamMember(0);" class="btn btn-light btn-sm btn-block">Add More Member</button>
                     <button type="button" onClick="AddTeamMember(1);" class="btn btn-dark btn-sm btn-block">Invite</button>
                 </div>
                </div>
             </div>
         </div>
     </div>
 </div>
 <!-- Modal -->

<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
function deleteTeamMember(member_id){
    if(confirm("Are you sure you want to delete this member?")){
        $.ajax({
            type:'DELETE',
            url:'/api/delete-team-member/'+member_id,
            async: false,
            success:function(data){
                if(data.code==200){
                    alert("Deleted successfully");
                    window.location.href=document.URL;               
                }
            }
        });
    }
}
function AddTeamMember(is_popup_close){
    if($("#email").val()=='')
    {
        alert("Please enter email.");
        $("#email").focus();
        return false;
    }
    else
    {
        var formData = {action:'AddTeamMember',email:$("#email").val(),business_code:$("#business_code").val(),join_url:$("#join_url").val()};
        $.ajax({
            type:'POST',
            url:'/AjaxRequest',
            data:formData,
            async: false,
            success:function(data){
                if(data.code==200){
                    alert("Request sent successfully");
                    if(is_popup_close==1){
                        $(".close").trigger("click");
                    }else{
                        $("email").val("");
                    }
                }
            }
        });
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/team.blade.php ENDPATH**/ ?>