<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="United Market for Business">
    <meta name="keywords" content="Business, Services, Client, jobs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>United Market</title>
    <!-- stylesheets -->
    <link rel="shortcut icon" href="public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/bootstrap-4.css">
	
	<!-- Owl Stylesheets -->
    <link rel="stylesheet" href="public/css/owl/owl.carousel.min.css">
    <link rel="stylesheet" href="public/css/owl/owl.theme.default.css">
	
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css"
        integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <!-- stylesheets -->
</head>
<body>
    <div class="wrapper">
		<!-- header -->		
		<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container">
                <a class="navbar-brand py-3"  href="<?php echo e(url('/')); ?>">
					<img src="public/images/logo.png" alt="logo" />
				</a>
                <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarCollapse"
					aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto d-flex align-items-center">
                        <li class="nav-item mr-lg-4 mobile-menu">
                            <a class="nav-link mb-0 text-white" href="<?php echo e(url('/about-us')); ?>">About Us</a>
                        </li>
                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item mr-lg-4 mobile-menu">
                            <a class="nav-link mb-0 text-white" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item mr-lg-5 mobile-menu">
                            <a class="nav-link mb-0 text-white" href="<?php echo e(route('signup')); ?>"><?php echo e(__('Signup')); ?></a>
                        </li>
                        <?php else: ?>
							<li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->first_name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>   
                        <li class="bg-white rounded px-lg-4 my-sm-4 small"><a role="button" href="#" class="btn btn-lg text-dark">Post a job</a></li>
                    </ul>
                </div>
            </div>
        </nav>
		<!-- header -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/layouts/apphomepage.blade.php ENDPATH**/ ?>