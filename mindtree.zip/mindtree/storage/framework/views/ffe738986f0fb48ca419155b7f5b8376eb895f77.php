
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(route('my-profile')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('notifications')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#basic-info" role="tab" aria-controls="nav-home" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#skills" role="tab" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#portfolio" role="tab" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#experience" role="tab" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#education" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#contact-info" role="tab" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                                            <div class="tab-pane fade show active" id="basic-info" role="tabpanel" aria-labelledby="nav-home-tab">
                                                <!-- basic info -->
                                                <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <p class="text-dark mb-0">Note: <span class="text-muted">To make changes in your basic profile please click on edit button</span></p>
                                                        <a role="button" class="btn btn-dark text-white">
                                                            <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i class="fas fa-pen text-dark"></i></span> Edit</a>
                                                    </div>
                                                </div>
                                                <div class="border rounded my-4 p-3">
                                                    <div class="d-flex align-items-center">
                                                        <form class="form-register" action="" method="post" id="mediaForm">
                                                        <input type="hidden" name="id" id="id" value="<?php echo e($user->id); ?>">
                                                        <div class="flex-shrink-0 mr-3">
                                                            <div class="position-relative dropdown dropright">
                                                                <div class="profile-pic rounded-circle" style="background: url(<?php echo e(getUserProfileImage($user->profile_thumb_image)); ?>)"></div>
                                                                <span class="bg-white position-absolute profile-pen cursor-pointer" data-toggle="dropdown"><i class="fas fa-pencil-alt"></i></span>
                                                                <div class="dropdown-menu dropdown-menu-right shadow-sm cus-rounded py-0 overflow-hidden">
                                                                    <a class="dropdown-item" href="javascript:void(0);" onclick="$('#image').click();">Change Picture</a>
                                                                    <a class="dropdown-item" href="javascript:void(0);" onclick="$('#video').click();">Add short video</a>
                                                                </div>
                                                                <input id="image" name="image" type="file" style="display:none" onChange="return UploadProfileImage('mediaForm');" />
                                                                <input id="video" name="video" type="file" style="display:none" onChange="return UploadProfileVideo('mediaForm');" />
                                                            </div>
                                                        </div>
                                                        </form>
                                                        <div class="w-100">
                                                            <h5 class="mb-0">
                                                                <?php if($user->user_type=='BUSINESS'): ?><?php echo e($user->business_name); ?> <?php else: ?> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> <?php endif; ?> 
                                                                <a href="javascript:void(0);"  data-toggle="modal" data-target="#basicProfile">
                                                                    <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-4"></i>
                                                                </a>
                                                            </h5>
                                                            <p class="mb-0"><i class="fas fa-map-marker-alt"></i> <?php echo e($user->state_name); ?>, <?php echo e($user->country_name); ?> - 11:11 PM Local Time <a href="#" data-toggle="modal" data-target="#changeLocation"><i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-3"></i></a></p>
                                                        </div>
                                                    </div>
                                                    <!-- content -->
                                                    <div class="border my-4 rounded p-2">
                                                        <div class="w-100 text-right">
                                                            <a href="javascript:void(0);"  data-toggle="modal" data-target="#overviewModal">
                                                                <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg"></i>
                                                            </a>
                                                        </div>
                                                        <p class="text-muted"><?php echo e($user->overview); ?></p>
                                                    </div>
                                                    <!-- content -->
                                                </div>
                                                <!-- basic info -->

                                                <!-- identity verification -->
                                                <div class="border my-4 rounded p-4">
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <h5 class="font-300">Identity Verification</h5>
                                                        <a class="btn btn-dark text-white" href="javascript:void(0);" onClick="showIdProofBox();"><i class="fas fa-plus-circle mr-1"></i> Add</a>
                                                    </div>
                                                    <div class="d-flex align-items-center my-4">
                                                        <div class="flex-shrink-0 mr-4">
                                                            <i class="far fa-check-circle fa-2x"></i>
                                                        </div>
                                                        <div class="w-100">
                                                            <p class="mb-0 text-muted">Identity verification is a good to get best client and it helps in disputs and all.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- identity verification -->
                                                <!-- Drag and Drop -->
                                                <div class="border my-4 rounded p-4" id="id_proof" style="display:none;">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                                            <div class="drapDrop rounded d-flex align-items-center justify-content-center mb-lg-0 mb-sm-4 mb-4">
                                                                <p class="text-muted text-center mb-0">Drag Your Files or <strong>Browse</strong> to upload</p>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-6 col-12 d-flex align-self-end flex-column">
                                                            <h4 class="font-300">Please Attach Your Govt, ID to verify your account</h4>
                                                            <p class="text-muted">Our Concern Team will verify your identity Proof and update you about your verification badge.</p>
                                                            <span class="small text-muted">This Process will take 24 to 72 Hours.</span>
                                                            <a role="button" class="btn btn-dark btn-sm text-white mt-3">Upload</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Drag and Drop -->

                                            </div>
                                            <div class="tab-pane fade" id="skills" role="tabpanel" aria-labelledby="nav-profile-tab">
                                                <!-- skills keywords -->
                                                <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <p class="text-dark mb-0">Note: <span class="text-muted">To make changes in your basic profile please click on edit button</span></p>
                                                        <a role="button" class="btn btn-dark text-white" data-toggle="modal" data-target="#basicProfile">
                                                            <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i class="fas fa-pen text-dark"></i></span> Edit</a>
                                                    </div>
                                                </div>
                                                <div class="w-100 d-inline-block border rounded my-4 p-3">
                                                    <div class="form-group">
                                                        <div id="tagfield" class="black fancyme-tags">
                                                            <input id="tag_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Keywords" autocomplete="off">
                                                            <div id="shownlist">
                                                                <?php 
                                                                    if(!empty($user->tags)){
                                                                        foreach($user->tags as $tag){
                                                                            echo '<span id="tag'.$tag->id.'">'.$tag->tag.'<a href="javascript:void(0);" onclick="removeTag('.$tag->id.')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                                                        }
                                                                    }
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <input type="hidden" id="selectedTagIds" name="selectedTagIds" value="<?php echo e($user->tag_ids); ?>">  
                                                </div>
                                                <!-- skills keywords -->
                                            </div>
                                            <div class="tab-pane fade" id="portfolio" role="tabpanel" aria-labelledby="nav-contact-tab">
                                                        <!-- portfolio -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                                <p class="text-dark mb-0">Note: <span class="text-muted">To make changes in your basic
                                                                        profile please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white">
                                                                    <span
                                                                        class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                            class="fas fa-pen text-dark"></i></span>
                                                                    Edit</a>
                                                            </div>
                                                        </div>
                                                        <div id="addPortfolio">
                                                            <div class="w-100 d-inline-block border rounded my-4 p-3">
                                                                <!-- portfolio images -->
                                                                <div class="row" id="setting-portfolio">
                                                                    <?php if(!empty($user->portfolios)): ?>
                                                                    <?php $__currentLoopData = $user->portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4">
                                                                        <div class="card border-0 position-relative">
                                                                            <div class="position-absolute portfolioIcon">
                                                                                <a href="#">
                                                                                    <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">
                                                                                        <i class="fas fa-pen text-dark"></i>
                                                                                    </span>
                                                                                </a>
                                                                                <a href="javascript:void(0);" onClick="deletePortfolio(<?php echo e($portfolio->id); ?>);"> 
                                                                                    <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">
                                                                                        <i class="fas fa-trash text-dark"></i>
                                                                                    </span>
                                                                                </a>
                                                                            </div>
                                                                            <img class="card-img-top" src="<?php echo e(URL($portfolio->cover_media->media_file)); ?>">
                                                                            <div class="card-body px-0">
                                                                                <h5 class="card-title"><?php echo e($portfolio->title); ?></h5>
                                                                                <p class="card-text text-muted"><?php echo e($portfolio->description); ?></p>
                                                                                <p>[<?php echo e(count($portfolio->medias)); ?>] Photos</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>                                                                    
                                                                </div>
                                                                <!-- portfolio images -->
                                                            </div>
                                                            <!-- portfolio -->
                                                            <!-- add portfolio -->
                                                            <div class="border my-4 rounded p-4">
                                                                <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                                                                    <h5 class="font-300">Add Portfolio</h5>
                                                                    <a role="button" id="addButton" class="btn btn-dark text-white" onclick="$('#addPortfolio').hide();$('#addNewPortfolio').show();"><i class="fas fa-plus-circle mr-1"></i> Add</a>
                                                                </div>
                                                                <div class="my-4">
                                                                    <p class="mb-0 text-muted text-sm-left text-center">You can add photos and videos in your portfolio</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- add portfolio -->

                                                        <!-- drag and drop -->
                                                        <div class="border rounded p-4 mt-2" id="addNewPortfolio" style="display:none;">
                                                            <div class="row mt-2">
                                                                <div class="col-lg-12">
                                                                    <div class="drapDrop-full rounded d-flex align-items-center justify-content-center mb-lg-0 mb-sm-4 mb-4">
                                                                        <input class="custom-file-input" type="file" id="fileInput" multiple size="50">
                                                                        <p class="text-muted-50 text-center mb-0">Drag your files or <strong>Browse</strong> to upload</p>
                                                                        
                                                                    </div>
                                                                    <p class="font-bold text-center my-3">OR Embed a link
                                                                    </p>
                                                                    <div class="shadow text-center p-3">
                                                                        <a class="text-dark" href="#"
                                                                            data-toggle="modal"
                                                                            data-target="#addVideoLink">
                                                                            <i class="fas fa-video mr-2"></i> Add Video Link
                                                                        </a>
                                                                    </div>
                                                                    <span
                                                                        class="d-block text-center text-muted-50 py-5 border-bottom">Upload
                                                                        .jpg, .gif, .png images upto 10MB each. Images
                                                                        will
                                                                        be displayed at 690px wide, at maximum. You can
                                                                        also
                                                                        embed YouTube or Vimeo videos.</span>
                                                                </div>
                                                            </div>
                                                            <input type="hidden" id="portfolio_media_ids" value="">
                                                            <input type="hidden" id="portfolio_cover_media_id" value="">
                                                            <!-- drag and drop -->
                                                            <!-- cover image -->
                                                            <div id="coverImage">
                                                                <div class="row mt-5" id="addeed-portfolios">
                                                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4">
                                                                        &nbsp;                                                                        
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- album form -->
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <h5 class="font-300">Album Title/Project Name</h5>
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control cus-input" name="title" id="title" placeholder="Title" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <textarea class="form-control" placeholder="Description" name="description" id="description" rows="4"></textarea>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <button type="button" id="btnAddNewPortfolio" class="btn btn-dark btn-sm btn-block">Save</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- album form -->
                                                        </div>
                                                        <!-- cover image-->
                                                    </div>
                                                    <div class="tab-pane fade" id="experience" role="tabpanel" aria-labelledby="nav-about-tab">
                                                        <!-- note -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div
                                                                class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                                <p class="text-dark mb-0">Note: <span
                                                                        class="text-muted">To make changes in your basic
                                                                        profile please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white"
                                                                    data-toggle="modal" data-target="#basicProfile">
                                                                    <span
                                                                        class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                            class="fas fa-pen text-dark"></i></span>
                                                                    Edit</a>
                                                            </div>
                                                        </div>
                                                        <!-- note -->
                                                        <!-- section 1 -->
                                                        <div class="border rounded my-4 p-3" id="experience_list">
                                                            <?php if(count($user->experiences)>0): ?>
                                                            <?php $__currentLoopData = $user->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="expRowClass" id="experience_row_<?php echo e($experience->id); ?>">
                                                                <div class="d-flex align-items-center">
                                                                    <h5 class="font-300 mr-2"><?php echo e($experience->title); ?></h5>
                                                                    <span>
                                                                        <a href="javascript:void(0);" onClick="editExperience(<?php echo e($experience->id); ?>)">
                                                                            <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-2"></i>
                                                                        </a>
                                                                    </span>
                                                                    <span>
                                                                        <a href="javascript:void(0);" onClick="deleteExperience(<?php echo e($experience->id); ?>)">
                                                                            <i class="fas fa-window-close cursor-pointer text-dark fa-lg ml-1"></i>
                                                                        </a>
                                                                    </span>
                                                                </div>
                                                                <p class="small text-muted-50"><?php echo e($experience->description); ?></p>
                                                                <div class="d-flex">
                                                                    <p class="font-bold mr-5"><?php echo e(date("M Y",strtotime($experience->from_date))); ?></p>
                                                                    <p class="font-bold"><?php echo e(date("M Y",strtotime($experience->to_date))); ?></p>
                                                                </div>
                                                            </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            <div id="no_experience">
                                                                You have not added experience.
                                                            </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <!-- section 1 -->
                                                        <!-- section 2-->
                                                        <div class="border my-4 rounded p-4">
                                                            <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                                                                <p class="font-bold mb-sm-0 mb-2">Want to add new experience?</p>
                                                                <a href="javascript:void(0);" class="btn btn-dark text-white" data-toggle="modal" data-target="#experienceModal">
                                                                    <i class="fas fa-plus-circle mr-1"></i> Add
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <!-- section 2-->
                                                    </div>
                                                    <div class="tab-pane fade" id="education" role="tabpanel"
                                                        aria-labelledby="nav-about-tab">
                                                        <!-- note -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div
                                                                class="d-flex align-items-center justify-content-between flex-sm-row flex-column">
                                                                <p class="text-dark mb-0">Note: <span
                                                                        class="text-muted">To make changes in your
                                                                        Education please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white"
                                                                    data-toggle="modal" data-target="#basicProfile">
                                                                    <span
                                                                        class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                            class="fas fa-pen text-dark"></i></span>
                                                                    Edit</a>
                                                            </div>
                                                        </div>
                                                        <!-- note -->
                                                        <!-- section 1 -->
                                                        <div class="border rounded my-4 p-3" id="education_list">
                                                            <?php if(count($user->educations)>0): ?>
                                                                <?php $__currentLoopData = $user->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="eduRowClass" id="education_row_<?php echo e($education->id); ?>">
                                                                    <div class="d-flex align-items-center">
                                                                        <h5 class="font-300 mr-2"><?php echo e($education->institute_name); ?></h5>
                                                                        <span><i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-2"></i></span>
                                                                        <span>
                                                                            <a href="javascript:void(0);" onClick="deleteEducation(<?php echo e($education->id); ?>)">
                                                                                <i class="fas fa-window-close cursor-pointer text-dark fa-lg ml-1"></i>
                                                                            <a>
                                                                        </span>
                                                                    </div>
                                                                    <p class="small text-muted-50"><?php echo e($education->description); ?></p>
                                                                    <div class="d-flex">
                                                                        <p class="font-bold mr-5"><?php echo e(date("M Y",strtotime($education->from_date))); ?></p>
                                                                        <p class="font-bold"><?php echo e(date("M Y",strtotime($education->to_date))); ?></p>
                                                                    </div>
                                                                </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            <div id="no_education">You have not added education.</div>
                                                            <?php endif; ?>                                                            
                                                        </div>
                                                        <!-- section 1 -->
                                                        <!-- section 2-->
                                                        <div class="border my-4 rounded p-4">
                                                            <div
                                                                class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                                                                <p class="font-bold mb-sm-0 mb-2">Want to add new education?</p>
                                                                <a href="javascript:void(0);" class="btn btn-dark text-white" data-toggle="modal" data-target="#educationModal">
                                                                    <i class="fas fa-plus-circle mr-1"></i> Add
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <!-- section 2-->                                                        
                                                    </div>
                                                    <div class="tab-pane fade" id="contact-info" role="tabpanel"
                                                        aria-labelledby="nav-about-tab">
                                                        <!-- note -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div
                                                                class="d-flex align-items-center justify-content-between">
                                                                <p class="text-dark mb-0">Note: <span
                                                                        class="text-muted">To make changes in your
                                                                        Contact please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white"
                                                                    data-toggle="modal" data-target="#basicProfile">
                                                                    <span
                                                                        class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                            class="fas fa-pen text-dark"></i></span>
                                                                    Edit</a>
                                                            </div>
                                                        </div>
                                                        <!-- note -->
                                                        <!-- section 1 -->
                                                        <div class="border rounded my-4 p-3">
                                                            <div class="row">
                                                                <!-- line 1 -->
                                                                <div class="col-lg-5">
                                                                    <div class="d-flex align-items-center">
                                                                        <h5 class="font-300 mr-2">Phone Number</h5>
                                                                        <a data-toggle="modal" data-target="#phoneModal"><i
                                                                                class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-5"></i></a>
                                                                    </div>
                                                                    <p class="small text-muted-50">123 456 789</p>
                                                                </div>
                                                                <!-- line 1 -->
                                                                <!-- line 2 -->
                                                                <div class="col-lg-5">
                                                                    <div class="d-flex align-items-center">
                                                                        <h5 class="font-300 mr-2">Email Address</h5>
                                                                        <a data-toggle="modal" data-target="#emailModal"><i
                                                                                class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-5"></i></a>
                                                                    </div>
                                                                    <p class="small text-muted-50">userone@gmail.com</p>
                                                                </div>
                                                                <!-- line 2 -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane fade" id="team" role="tabpanel"
                                                        aria-labelledby="nav-about-tab">
                                                        <!-- note -->
                                                        <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                            <div
                                                                class="d-flex align-items-center justify-content-between">
                                                                <p class="text-dark mb-0">Note: <span
                                                                        class="text-muted">To make changes in your
                                                                        Education please click on edit button</span></p>
                                                                <a role="button" class="btn btn-dark text-white"
                                                                    data-toggle="modal" data-target="#basicProfile">
                                                                    <span
                                                                        class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i
                                                                            class="fas fa-pen text-dark"></i></span>
                                                                    Edit</a>
                                                            </div>
                                                        </div>
                                                        <!-- note -->
                                                        <!-- section 1 -->
                                                        <div class="border rounded my-4 p-3">
                                                            <div class="row my-5" id="profile-team">
                                                                <div class="col-lg-3 col-sm-6 col-12 top-suggestion mb-lg-0 mb-md-3 mb-sm-3 mb-3">
                                                                    <div class="card rounded p-3">
                                                                        <a href="#" class="text-dark">
                                                                        <i class="fas fa-times-circle fa-lg rightIcon position-absolute"></i>
                                                                        </a>
                                                                        <img class="rounded-circle m-auto" src="images/img-1.png" alt="img">
                                                                        <div class="card-body text-center p-0">
                                                                            <p class="card-title mt-3 mb-0 font-500">Michael Kors</p>
                                                                            <p class="text-muted-50 mb-0">
                                                                                Candid Photographer
                                                                            </p>
                                                                            <div class="d-flex justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3 col-sm-6 col-12 top-suggestion mb-lg-0 mb-md-3 mb-sm-3 mb-3">
                                                                    <div class="card rounded p-3">
                                                                        <a href="#" class="text-dark">
                                                                        <i class="fas fa-times-circle fa-lg rightIcon position-absolute"></i>
                                                                        </a>
                                                                        <img class="rounded-circle m-auto" src="images/img-1.png" alt="img">
                                                                        <div class="card-body text-center p-0">
                                                                            <p class="card-title mt-3 mb-0 font-500">Michael Kors</p>
                                                                            <p class="text-muted-50 mb-0">
                                                                                Candid Photographer
                                                                            </p>
                                                                            <div class="d-flex justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3 col-sm-6 col-12 top-suggestion mb-lg-0 mb-md-3 mb-sm-3 mb-3">
                                                                    <div class="card rounded p-3">
                                                                        <a href="#" class="text-dark">
                                                                        <i class="fas fa-times-circle fa-lg rightIcon position-absolute"></i>
                                                                        </a>
                                                                        <img class="rounded-circle m-auto" src="images/img-1.png" alt="img">
                                                                        <div class="card-body text-center p-0">
                                                                            <p class="card-title mt-3 mb-0 font-500">Michael Kors</p>
                                                                            <p class="text-muted-50 mb-0">
                                                                                Candid Photographer
                                                                            </p>
                                                                            <div class="d-flex justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                                <i class="fas fa-star fa-sm mr-1 text-warning"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-3 col-sm-6 col-12 top-suggestion mb-lg-0 mb-md-3 mb-sm-3 mb-3">
                                                                    <a href="#" data-toggle="modal" data-target="#inviteMember" class="card rounded p-3 h-100 text-center">
                                                                        <i class="fas fa-plus fa-5x text-muted-50 my-3"></i>
                                                                        <p class="text-dark">Add New</p>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>    
                                                </div>
                                            </div>
                                </section>
                                <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<!-- Modal Basic Info Start-->
<div class="modal fade" id="basicProfile" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Basic Profile</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <p>NOTE: You can't change your first name &amp; last name after verification</p>
                <form method="POST" action="" id="ProfileForm">
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_type" id="user_type" value="<?php echo e($user->user_type); ?>">
                    <?php if($user->user_type=='BUSINESS'): ?>
                    <div class="form-group">
                        <input type="text" name="business_name" id="business_name" class="form-control cus-input" value="<?php echo e($user->business_name); ?>"/>
                    </div>
                    <?php else: ?>
                    <div class="form-group">
                        <input type="text" name="first_name" id="first_name" class="form-control cus-input" value="<?php echo e($user->first_name); ?>" />
                    </div>
                    <div class="form-group">
                        <input type="text" name="first_name" id="last_name" class="form-control cus-input" value="<?php echo e($user->last_name); ?>" />
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <div class="position-relative">
                            <input type="text" id="user_name" name="user_name" class="form-control cus-input pr-5" placeholder="User Name" value="<?php echo e($user->user_name); ?>" <?php if(isset($user->user_name)): ?> readonly <?php endif; ?>/>
                            <span class="rightIcon position-absolute" id="isAvailableIcon" style="display:none;">
                                <i class="fas fa-check-circle text-success"></i>
                            </span>
                        </div>
                        <?php if(!isset($user->user_name)): ?> 
                        <div class="d-flex justify-content-between">
                            <p class="small text-muted mt-2">Select unique username </p>
                            <span class="small text-success mt-2" id="isAvailable" style="display:none;">Available</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnAddBasicProfile" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal  Basic Info End-->
<!-- Modal Current Location Start-->
<div class="modal fade" id="changeLocation" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Change Location</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <p>Please provide following details</p>
                <form method="POST" action="" id="LocationForm">
                <?php echo csrf_field(); ?>                 
                    <div class="form-group">
                        <div class="select-style-left">
                        <select name="country" id="country" onChange="populateStatesOfCountry(this.value);">                                               
                            <option value="">Country</option>
                            <?php if(!empty($countries)): ?>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" <?php if($country->id==$user->country): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="select-style-left">
                            <select name="state" id="state" onChange="populateCitiesOfState(this.value);">
                            <?php if(!empty($states_of_selected_country)): ?>
                                <?php $__currentLoopData = $states_of_selected_country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->id); ?>" <?php if($state->id==$user->state): ?> selected <?php endif; ?>><?php echo e($state->name); ?></option>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>                                             
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="select-style-left">
                            <select name="city" id="city">
                            <?php if(!empty($cities_of_selected_state)): ?>
                                <?php $__currentLoopData = $cities_of_selected_state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>" <?php if($city->id==$user->city): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>                                                  
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" id="zipcode" name="zipcode" value="<?php echo e($user->zipcode); ?>" maxlength="6" class="form-control cus-input" placeholder="Zip Code"/>
                    </div>
                    <div class="form-group">
                        <label>Add Address (Optional)</label>
                        <textarea class="form-control" placeholder="Address" rows="4" id="address2" name="address2"><?php echo e($user->address2); ?></textarea>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button id="btnCurrentLocation" type="button" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>               
            </div>
        </div>
    </div>
</div>
<!-- Modal Current Location End-->
<!-- Modal About Us Start-->
<div class="modal fade" id="overviewModal" tabindex="-1" role="dialog" aria-labelledby="overviewLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Overview</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <form method="POST" action="" id="OverviewForm">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Overview</label>
                        <textarea class="form-control" placeholder="Overview" rows="10" id="overview" name="overview"><?php echo e($user->overview); ?></textarea>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnOverview" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal About Us End-->

<!-- Modal Add experience-->
<div class="modal fade" id="experienceModal" tabindex="-1" role="dialog" aria-labelledby="experiencelabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Experience</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body px-5 pb-5">
                <p class="text-muted-50">Please provide your experience details</p>
                <form method="POST" action="" id="ExpForm">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" id="experience_title" name="experience_title" class="form-control cus-input" placeholder="Title"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="experience_description" name="experience_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="experience_from" autocomplete="off" />
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="experience_to" autocomplete="off" />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnAddNewExperience" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal Add experience End-->
<!-- Modal Edit experience-->
<div class="modal fade" id="edit_experience_modal" tabindex="-1" role="dialog" aria-labelledby="edit_experience_modal_label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Edit Experience</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body px-5 pb-5">
                <form method="POST" action="" id="ExpEditForm">
                <input type="hidden" id="experience_id" value=""/>
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" id="edit_experience_title" name="edit_experience_title" class="form-control cus-input" placeholder="Title"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="edit_experience_description" name="edit_experience_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="edit_experience_from" autocomplete="off" />
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="edit_experience_to" autocomplete="off" />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnEditExperience" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal edit experience End-->

<!-- Modal Add education-->
<div class="modal fade" id="educationModal" tabindex="-1" role="dialog" aria-labelledby="educationlabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Education</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>            
            <div class="modal-body px-5 pb-5">
                <p class="text-muted-50">Please provide your education details</p>
                <form method="POST" action="" id="ExpForm">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Institute Name</label>
                        <input type="text" id="institute_name" name="institute_name" class="form-control cus-input" placeholder="Institute Name"/>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Description" rows="4" id="institute_description" name="institute_description"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>From</label>                                
                                <input class="form-control cus-input border-right-0" placeholder="From" id="education_from" autocomplete="off"/>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>To</label>   
                                <input class="form-control cus-input border-right-0" placeholder="To" id="education_to" autocomplete="off"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 m-auto">
                        <button type="button" id="btnAddNewEducation" class="btn btn-dark btn-sm btn-block mt-2">Save</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal Add education End-->
<!-- Modal -->
<div class="modal fade" id="addVideoLink" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Add a Video Link</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <p>Paste the link to your Youtube or Vimeo Video Here</p>
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" placeholder="Link" />
                        <p class="mt-2 text-muted-50">Any Data which not meet United Market Guidlines will be
                            deleted.</p>
                    </div>
                </form>
                <div class="col-lg-6 m-auto">
                    <button type="button" class="btn btn-dark btn-sm btn-block mt-5">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="phoneModal" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Contact Info</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <p>NOTE: Please provide your phone number or email address</p>
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" placeholder="Phone Number" />
                    </div>
                </form>
                <div class="col-lg-6 m-auto">
                    <button type="button" class="btn btn-dark btn-sm btn-block mt-5">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="emailModal" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Contact Info</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <p>NOTE: Please provide your phone number or email address</p>
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" placeholder="Email Address" />
                    </div>
                </form>
                <div class="col-lg-6 m-auto">
                    <button type="button" class="btn btn-dark btn-sm btn-block mt-5">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="inviteMember" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header pb-0">
                <h2 class="pl-4 pt-3">Invite Team Member</h2>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <form>
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" placeholder="Add Email Address" />
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" placeholder="UM.co/Business/Join" />
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control cus-input" placeholder="New Code" />
                    </div>
                </form>
                <div class="row">
                <div class="col-lg-12 m-auto">
                    <button type="button" class="btn btn-light btn-sm btn-block">Add More Member</button>
                    <button type="button" class="btn btn-dark btn-sm btn-block">Invite</button>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){

    $('#experience_from').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'
    });
    $('#experience_to').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'      
    });
    $('#education_from').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'
    });
    $('#education_to').datepicker({
        uiLibrary: 'bootstrap4',
        maxDate: 'today'
    });

    $.ajax({
        type:'GET',
        url:'/GetTags',
        success:function(data){
            if(data.status=='done'){                   
                $( "#tag_list" ).autocomplete({
                    classes: {
                        "ui-autocomplete": "tag-style",
                    },
                    minLength: 1,
                    maxShowItems: 10,
                    source: data.data,                       
                    select: function(e, item){
                        var selectedTagIds = $("#selectedTagIds").val();
                        if (selectedTagIds.split(",").includes(item.item.id+"") || item.item.value=='') {
                        } else {
                            var spanHtml = '<span id="tag'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeTag('+item.item.id+')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                            $(".fancyme-tags #shownlist").append(spanHtml);
                            if($("#selectedTagIds").val()==''){
                                $("#selectedTagIds").val(item.item.id);
                            }else{
                                $("#selectedTagIds").val($("#selectedTagIds").val()+','+item.item.id);
                            }
                        }
                        setTimeout(function(){
                            $('#tag_list').val("");
                        },100);
                    },
                    response: function(event, ui) {
                        if (!ui.content.length) {
                            var noResult = { value:"",label:"No results found" };
                            ui.content.push(noResult);
                        }
                    }
                });
            }
        }
    });
})  
function showIdProofBox(){
    $("#id_proof").show();
}
var timer;
var x;
$('#user_name').keyup(function(){
    var user_name = $('#user_name').val();
    if (x) { x.abort() } 
    clearTimeout(timer); 
    timer = setTimeout(function() { 
        var formPostData = {user_name: user_name};
        $.ajax({
            type:'POST',
            url:'/isUsernameAvailable',
            data:formPostData,
            async: false,
            success:function(data){
                if(data.isAvailable==1){
                    $("#isAvailableIcon").show();
                    $("#isAvailable").show();
                }else{
                    $("#isAvailableIcon").show();
                    $("#isAvailable").show();
                    return false;
                }
            }
        }); 
    }, 1000); 
});
$('#btnAddBasicProfile').click(function(e){
    e.preventDefault();
    var user_type = $("#user_type").val();                
    if(user_type!='BUSINESS' && $('#first_name').val()==''){
        alert("Please enter first name.");
        $('#first_name').focus();
        return false;
    }else if(user_type!='BUSINESS' && $('#last_name').val()==''){
        alert("Please enter last name.");
        $('#last_name').focus();
        return false;			
    }else if(user_type=='BUSINESS' && $('#business_name').val()==''){
        alert("Please enter business name.");
        $('#business_name').focus();
        return false;  
    }else{
        if(user_type=='BUSINESS'){
            var business_name = $("#business_name").val();
            formPostData = {business_name:business_name,user_name:$("#user_name").val()};
        }else{
            var first_name = $("#first_name").val();
            var last_name = $("#last_name").val();
            formPostData = {first_name:first_name,last_name:last_name,user_name:$("#user_name").val()};
        }     
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:formPostData,
            async: false,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        }); 
    }
});
$('#btnCurrentLocation').click(function(e){
    e.preventDefault();
    if($('#country').val()==''){
        alert("Please select country.");
        $('#country').focus();
        return false;
    }else if($('#state').val()==''){
        alert("Please select state.");
        $('#state').focus();
        return false;
    }else if($('#city').val()==''){
        alert("Please select city.");
        $('#city').focus();
        return false;
    }else if($('#zipcode').val()==''){
        alert("Please enter zip code.");
        $('#zipcode').focus();
        return false;
    }else if($('#zipcode').val() !='' && $('#zipcode').val().length<4){
        alert("Invalid zip code");
        $('#zipcode').focus();
        return false;
    }else{
        var country = $("#country").val();
        var state = $("#state").val();
        var city = $("#city").val();                   
        var zipcode = $("#zipcode").val();
        var address2 = $("#address2").val();
        var formData = {city:city,state:state,country:country,zipcode:zipcode,address2:address2};     
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
$('#btnOverview').click(function(e){
    e.preventDefault();
    if($('#overview').val()==''){
        alert("Please enter overview.");
        $('#overview').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:{overview:$("#overview").val()},
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
function removeTag(span_id){
    $('#tag'+span_id).remove();
    var value = span_id;
    var arr = $("#selectedTagIds").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#selectedTagIds").val(arr.join(","));
}
function UploadProfileImage(formID) {
    $('#loader').show();
    $.ajax({
        type: "POST",
        url: base_path+"/upload_profile_image",
        data:new FormData($("#"+formID)[0]),
        dataType:'json',
        async:false,
        processData: false,
        contentType: false,
        success:function(response){
            if(response.success=='done'){
                window.location.href=document.URL;
            }
        },
    });
}
function UploadProfileVideo(formID) {
    $('#loader').show();
    $.ajax({
        type: "POST",
        url: base_path+"/upload_profile_image",
        data:new FormData($("#"+formID)[0]),
        dataType:'json',
        async:false,
        processData: false,
        contentType: false,
        success:function(response){
            if(response.success=='done'){
                window.location.href=document.URL;
            }
        },
    });
}
// drag and drop
function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            var htmlPreview =
                '<img class="img-fluid" src="' + e.target.result + '" />'
            //'<p>' + input.files[0].name + '</p>';
            var wrapperZone = $(input).parent();
            var previewZone = $(input).parent().parent().find('.preview-zone');
            var boxZone = $(input).parent().parent().find('.preview-zone').find('.box1').find('.box-body');

            wrapperZone.removeClass('dragover');
            previewZone.removeClass('hidden');
            boxZone.empty();
            boxZone.append(htmlPreview);
        };

        reader.readAsDataURL(input.files[0]);
    }
}
$("#fileInput").change(function(){
    var allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    var file = this.files[0];
    var fileType = file.type;
    if(!allowedTypes.includes(fileType)){
        alert('Please select a valid file (JPEG/JPG/PNG/GIF).');
        $("#fileInput").val('');
        return false;
    }else{     
        $('.progress').show();       
        var file = this.files[0];
        var formData = new FormData();
        formData.append("media_files[]", file);
        $.ajax({                
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = ((evt.loaded / evt.total) * 100);
                        $(".progress-bar").width(percentComplete + '%');
                        $(".progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
            type: 'POST',
            url: '/api/upload-medias',
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                //$(".progress-bar").width('0%');
                //$('#uploadStatus').html('<img src="images/loading.gif"/>');
            },
            error:function(){
                //$('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
            },
            success: function(resp){                    
                if(resp.code == 200){
                    var media_ids = resp.media_ids;
                    var media_files = resp.media_files;
                    var media_urls = resp.media_urls;
                    if($('#portfolio_media_ids').val()!=''){
                        $('#portfolio_media_ids').val($('#portfolio_media_ids').val()+','+media_ids[0]);
                    }else{
                        $('#portfolio_media_ids').val(media_ids[0]);
                    }                     
                    for(i=0;i<media_ids.length;i++){
                        var media_html = '';
                        media_html += '<div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-4" id="portfolio_item_'+media_ids[i]+'">';
                        media_html += '<div class="card border-0 position-relative">';
                        media_html += '<div class="position-absolute portfolioIcon">';
                        media_html += '<a href="javascript:void(0);" onClick="deletePortfolioAddedItem('+media_ids[i]+')">';
                        media_html += '<span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1">';
                        media_html += '<i class="fas fa-trash text-dark"></i>';
                        media_html += '</span>';
                        media_html += '</a>';
                        media_html += '</div>';
                        media_html += '<img class="card-img-top" src="'+media_urls[i]+'" alt="Card image cap">';
                        media_html += '<div class="card-body px-0">';
                        media_html += '<div class="form-group">';
                        media_html += '<input type="text" class="form-control cus-input" placeholder="Enter Caption" />';
                        media_html += '</div>';
                        media_html += '<div class="form-group mr-4">';
                        media_html += '<div class="custom-control custom-radio">';
                        media_html += '<input type="radio" id="customRadio'+media_ids[i]+'" name="customRadio" class="custom-control-input" onclick="setCoverMedia('+media_ids[i]+');">';
                        media_html += '<label class="custom-control-label" for="customRadio'+media_ids[i]+'">Cover Image</label>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                        media_html += '</div>';
                    }
                    $('#addeed-portfolios').prepend(media_html);
                }else if(resp.code == 401){
                    $('#uploadStatus').html('<p class="text-dark">Please select a valid file to upload.</p>');
                }
            } 
        });
    }
});
function deletePortfolioAddedItem(media_id){
    $("#portfolio_item_"+media_id).remove();
    var value = media_id;
    var arr = $("#portfolio_media_ids").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#portfolio_media_ids").val(arr.join(","));
    $.ajax({
        type:'DELETE',
        url:'/api/delete-media/'+media_id,
        async: false,
        success:function(data){
            if(data.code==200){               
            }
        }
    });
}
function setCoverMedia(media_id){
    $("#portfolio_cover_media_id").val(media_id);
}
$('#btnAddNewPortfolio').click(function(e){
    e.preventDefault();
    if($('#title').val()==''){
        alert("Please select title.");
        $('#title').focus();
        return false;
    }else if($('#description').val()==''){
        alert("Please select description.");
        $('#description').focus();
        return false;
    }else{
        var title = $("#title").val();
        var description = $("#description").val();
        var portfolio_media_ids = $("#portfolio_media_ids").val();                   
        var portfolio_cover_media_id = $("#portfolio_cover_media_id").val();
        var formData = {title:title,description:description,portfolio_media_ids:portfolio_media_ids,portfolio_cover_media_id:portfolio_cover_media_id};     
        $.ajax({
            type:'POST',
            url:'/AddUserPortfolio',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
$('#btnAddNewExperience').click(function(e){
    e.preventDefault();
    if($('#experience_title').val()==''){
        alert("Please enter title.");
        $('#experience_title').focus();
        return false;
    }else if($('#experience_description').val()==''){
        alert("Please enter description.");
        $('#experience_description').focus();
        return false;
    }else if($('#experience_from').val()==''){
        alert("Please select from date.");
        $('#experience_from').focus();
        return false;
    }else if($('#experience_to').val()==''){
        alert("Please select to date.");
        $('#experience_to').focus();
        return false;
    }else{
        var title = $("#experience_title").val();
        var description = $("#experience_description").val();
        var from_date = $("#experience_from").val();                   
        var to_date = $("#experience_to").val();
        var formData = {title:title,description:description,from_date:from_date,to_date:to_date};     
        $.ajax({
            type:'POST',
            url:'/AddUserExperience',
            data:formData,
            success:function(data){
                if(data.code==200){
                    
                    $("#experience_title").val("");
                    $("#experience_description").val("");
                    $("#experience_from").val("");                   
                    $("#experience_to").val("");

                    var monthNames = [ "January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December" ];
                    var newDate = new Date(from_date);
                    var formattedFromDate = monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear();
                    var newDate2 = new Date(to_date);
                    var formattedToDate = monthNames[newDate2.getMonth()] + ' ' + newDate2.getFullYear();

                    var exp_html = '<div id="experience_row_'+data.id+'">';
                    exp_html += '<div class="d-flex align-items-center">';
                    exp_html += '<h5 class="font-300 mr-2">'+title+'</h5>';
                    exp_html += '<span>';
                    exp_html += '<a href="javascript:void(0);" onClick="editExperience('+data.id+')">';
                    exp_html += '<i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-2"></i>';
                    exp_html += '</a>';
                    exp_html += '</span>';
                    exp_html += '<span>';
                    exp_html += '<a href="javascript:void(0);" onClick="deleteExperience('+data.id+')">';
                    exp_html += '<i class="fas fa-window-close cursor-pointer text-dark fa-lg ml-1"></i>';
                    exp_html += '</a>';
                    exp_html += '</span>';
                    exp_html += '</div>';
                    exp_html += '<p class="small text-muted-50">'+description+'</p>';
                    exp_html += '<div class="d-flex">';
                    exp_html += '<p class="font-bold mr-5">'+formattedFromDate+'</p>';
                    exp_html += '<p class="font-bold">'+formattedToDate+'</p>';
                    exp_html += '</div>';
                    $("#no_experience").hide();
                    $("#experience_list").prepend(exp_html);
                    $(".close").trigger('click');
                }
            }
        });
    }
});
$('#btnAddNewEducation').click(function(e){
    e.preventDefault();
    if($('#institute_name').val()==''){
        alert("Please enter institute name.");
        $('#institute_name').focus();
        return false;
    }else if($('#institute_description').val()==''){
        alert("Please enter description.");
        $('#institute_description').focus();
        return false;
    }else if($('#education_from').val()==''){
        alert("Please select from date.");
        $('#education_from').focus();
        return false;
    }else if($('#education_to').val()==''){
        alert("Please select to date.");
        $('#education_to').focus();
        return false;
    }else{
        var institute_name = $("#institute_name").val();
        var description = $("#institute_description").val();
        var from_date = $("#education_from").val();                   
        var to_date = $("#education_to").val();
        var formData = {institute_name:institute_name,description:description,from_date:from_date,to_date:to_date};     
        $.ajax({
            type:'POST',
            url:'/AddUserEducation',
            data:formData,
            success:function(data){
                if(data.code==200){

                    $("#institute_name").val("");
                    $("#institute_description").val("");
                    $("#education_from").val("");                   
                    $("#education_to").val("");

                    var monthNames = [ "January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December" ];
                    var newDate = new Date(from_date);
                    var formattedFromDate = monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear();
                    var newDate2 = new Date(to_date);
                    var formattedToDate = monthNames[newDate2.getMonth()] + ' ' + newDate2.getFullYear();
                    
                    var edu_html = '<div id="education_row_'+data.id+'">';
                    edu_html += '<div class="d-flex align-items-center">';
                    edu_html += '<h5 class="font-300 mr-2">'+institute_name+'</h5>';
                    edu_html += '<span>';
                    edu_html += '<i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-2"></i>';
                    edu_html += '</span>';
                    edu_html += '<span>';
                    edu_html += '<a href="javascript:void(0);" onClick="deleteEducation('+data.id+')">';
                    edu_html += '<i class="fas fa-window-close cursor-pointer text-dark fa-lg ml-1"></i>';
                    edu_html += '</a>';
                    edu_html += '</span>';
                    edu_html += '</div>';
                    edu_html += '<p class="small text-muted-50">'+description+'</p>';
                    edu_html += '<div class="d-flex">';
                    edu_html += '<p class="font-bold mr-5">'+formattedFromDate+'</p>';
                    edu_html += '<p class="font-bold">'+formattedToDate+'</p>';
                    edu_html += '</div>';
                    edu_html += '</div>';
                    $("#no_education").hide();
                    $("#education_list").prepend(edu_html);
                    $(".close").trigger('click');
                }
            }
        });
    }
});
function deletePortfolio(portfolio_id){
    if(confirm("Are you sure? do you want to delete this?")){
        $.ajax({
            type:'DELETE',
            url:'/api/delete-portfolio/'+portfolio_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    alert("Deleted");                  
                }
            }
        });
    }
}
function deleteExperience(experience_id){
    if(confirm("Are you sure? do you want to delete this?")){
        $.ajax({
            type:'DELETE',
            url:'/api/delete-experience/'+experience_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    $("#experience_row_"+experience_id).remove();
                    var sum = 0;
                    $('.expRowClass').each(function()
                    {
                        sum = 1;
                    });
                    if(sum==0){
                        var listHtml = $("#experience_list").html();
                        if(listHtml.trim()==''){
                            $("#experience_list").html("<div id='no_experience'>You have not added experience.</div>")
                        }else{
                            $("#no_experience").show();
                        }                        
                    }               
                }
            }
        });
    }
}
function deleteEducation(education_id){
    if(confirm("Are you sure? do you want to delete this?")){
        $.ajax({
            type:'DELETE',
            url:'/api/delete-education/'+education_id,
            async: false,
            success:function(data){
                if(data.code==200){ 
                    $("#education_row_"+education_id).remove();
                    var sum = 0;
                    $('.eduRowClass').each(function()
                    {
                        sum = 1;
                    });                    
                    if(sum==0){
                        var listHtml = $("#education_list").html();
                        if(listHtml.trim()==''){
                            $("#education_list").html("<div id='no_education'>You have not added education.</div>")
                        }else{
                            $("#no_education").show();
                        }                        
                    }             
                }
            }
        });
    }
}
function editExperience(experience_id){
    $.ajax({
        type:'GET',
        url:'/api/experience-details/'+experience_id,
        async: false,
        success:function(data){
            if(data.code==200){ 
                $("#edit_experience_title").val(data.data.title); 
                $("#edit_experience_description").val(data.data.description); 
                $("#edit_experience_from").val(data.data.from_date); 
                $("#edit_experience_to").val(data.data.to_date);   
                $("#edit_experience_modal").modal();       
            }
        }
    });
}
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/my-profile.blade.php ENDPATH**/ ?>