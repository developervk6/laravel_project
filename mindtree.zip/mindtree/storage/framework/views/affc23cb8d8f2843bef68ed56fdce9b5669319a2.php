<?php $__env->startSection('content'); ?>
<div class="container py-5">
            <div class="bg-white shadow rounded">
                <div class="row m-0">
                    <!-- left side -->
                    <div class="col-lg-2 col-md-3 p-3">
                        <h5 class="mb-4">Job Categories</h5>
                        <!-- accordian -->
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel panel-default">
                                <div class="panel-heading active" role="tab" id="headingOne">
                                    <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion"
                                            href="#collapse<?php echo e($category->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                            <?php echo e($category->service_category_name); ?>

                                        </a>
                                    </h4>
                                </div>
                                <div id="collapse<?php echo e($category->id); ?>" class="panel-collapse collapse <?php if($key==0): ?>in show <?php endif; ?>" role="tabpanel"
                                    aria-labelledby="headingOne">
                                    <div class="panel-body">
                                        <ul class="list-unstyled font-14">
                                            <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a class="text-muted" href="advance-search-results?service_sub_category_id=<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->service_name); ?></a></li>  
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>                           
                        <!-- accordian -->
                    </div>
                    <!-- left side -->
                    <!-- content side -->
                    <div
                        class="col-lg-7 col-md-9 p-3 px-lg-4 border-left border-right border-md-right-0 border-sm-left-0">
                        <div class="d-flex justify-content-sm-between justify-content-center align-items-center flex-sm-row flex-column mb-4">
                            <h5 class="mb-sm-0 mb-4">Top Suggestions</h5>
                            <div class="col-lg-4 col-md-4 col-sm-4 p-0 d-flex justify-content-sm-end justify-content-center align-items-center">
                                <i class="fas fa-sliders-h fa-lg mr-5 text-muted cursor-pointer" data-toggle="modal" data-target="#searchPopupModal" data-backdrop="static"></i>
                                <button type="button" class="btn btn-outline-dark" >View All</button>
                            </div>
                        </div>
                        <div class="row my-4 border-bottom pb-5">

                            <?php $__currentLoopData = $top_suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-sm-4 col-12 top-suggestion mb-lg-0 mb-md-0 mb-sm-3 mb-3">
                                <div class="card cus-rounded p-3">
                                    <a href="/profile/<?php echo e($user->id); ?>" class="text-center">
                                        <img class="rounded-circle m-auto" src="<?php echo e(getUserProfileImage($user->profile_image)); ?>">
                                    </a>
                                    <div class="card-body text-center p-0">
                                        <a href="/profile/<?php echo e($user->id); ?>" class="text-muted">
                                            <p class="card-title mt-3 mb-0 font-500"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>
                                        </a>
                                        <p class="text-muted mb-0">
                                            <i class="fas fa-map-marker-alt mr-2"></i>
                                            <?php echo e($user->state_name); ?>

                                        </p>
                                        <p class="mb-0">5+ Jobs Done</p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row">
                            <!-- available for -->
                            <?php if($user_type=='CLIENT'): ?>
                                <?php $__currentLoopData = $bottom_suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border-bottom pb-4 mb-5 w-100">
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                                                <div class="d-flex flex-lg-row flex-md-row flex-sm-column flex-column text-lg-left text-md-left text-sm-center text-center">
                                                    <div class="flex-shrink-0 mr-3 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                        <a href="/profile/<?php echo e($user->id); ?>">
                                                            <img class="img-w-60 rounded-circle" src="<?php echo e(getUserProfileImage($user->profile_image)); ?>" alt="img" />
                                                        </a>
                                                    </div>
                                                    <div class="w-100 overflow-hidden">
                                                        <a href="/profile/<?php echo e($user->id); ?>" class="text-dark">
                                                            <h4 class="mb-0"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h4>
                                                        </a>
                                                        <p class="text-muted mb-0"><i class="fas fa-map-marker-alt mr-2"></i><?php echo e($user->state_name); ?></p>
                                                        <p class="mb-0"><?php echo !empty($user->service_name)?$user->service_name:'&nbsp;';?></p>
                                                        <div class="d-flex justify-content-lg-start justify-content-md-start justify-content-sm-center justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-12 col-12 text-lg-right text-md-right text-sm-center text-center">
                                                <p class="text-dark">
                                                <strong><?php echo e(ucfirst(strtolower($user->service_mode))); ?></strong>
                                                <?php 
                                                    if($user->service_mode=='FIXED'){
                                                        if(empty($user->service_fixed_charge)){
                                                            echo 'NA';
                                                        }else{
                                                            echo "$".$user->service_fixed_charge; 
                                                        }                                                       
                                                    }else{
                                                        if(empty($user->service_charges_low) || empty($user->service_charges_high)){
                                                            echo 'NA';
                                                        }else{
                                                            echo "$".$user->service_charges_low." - $".$user->service_charges_high;
                                                        }
                                                    } 
                                                ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mt-sm-4 mt-2">
                                        <ul class="list-inline text-lg-left text-md-left text-sm-center text-center">
                                            <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                <div class="border p-2 text-center">
                                                    <p class="mb-0">$20.00</p>
                                                    <small class="text-muted">Hourly Rate</small>
                                                </div>
                                            </li>
                                            <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                <div class="border p-2 text-center">
                                                    <p class="mb-0">$30k</p>
                                                    <small class="text-muted">Total Earned</small>
                                                </div>
                                            </li>
                                            <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                <div class="border p-2 text-center">
                                                    <p class="mb-0">200+</p>
                                                    <small class="text-muted">Jobs</small>
                                                </div>
                                            </li>
                                            <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                <div class="border p-2 text-center">
                                                    <p class="mb-0">120Hrs</p>
                                                    <small class="text-muted">UM Hours</small>
                                                </div>
                                            </li>
                                        </ul>
                                        <p class="text-muted text-lg-left text-md-left text-sm-center text-center mb-0"><?php echo e($user->job_description); ?></p>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $bottom_suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border-bottom pb-4 mb-5 w-100">
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                                                <div class="d-flex flex-lg-row flex-md-row flex-sm-column flex-column text-lg-left text-md-left text-sm-center text-center">                                                    
                                                    <div class="w-100 overflow-hidden">
                                                        <a href="/job-details/<?php echo e($job->job_id); ?>" class="text-dark">
                                                            <h4 class="mb-0"><?php echo e($job->job_title); ?></h4>
                                                        </a>
                                                        <p class="text-muted mb-0">
                                                            <i class="fas fa-map-marker-alt mr-2"></i><?php echo e($job->state_name); ?>

                                                            &nbsp;&nbsp;&nbsp;&nbsp;
                                                            <?php echo e(ucfirst(strtolower($job->service_mode))); ?>

                                                            &nbsp;&nbsp;&nbsp;&nbsp;
                                                            <?php 
                                                                if($job->service_mode=='FIXED'){
                                                                    if(empty($job->service_fixed_charge)){
                                                                        echo 'NA';
                                                                    }else{
                                                                        echo "$".$job->service_fixed_charge; 
                                                                    }                                                       
                                                                }else{
                                                                    if(empty($job->service_charges_low) || empty($job->service_charges_high)){
                                                                        echo 'NA';
                                                                    }else{
                                                                        echo "$".$job->service_charges_low." - $".$job->service_charges_high;
                                                                    }
                                                                } 
                                                            ?>
                                                        </p>
                                                        <div class="d-flex justify-content-lg-start justify-content-md-start justify-content-sm-center justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                            <i class="fas fa-star mr-1 text-warning"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-md-4 col-sm-12 col-12 text-lg-right text-md-right text-sm-center text-center">
                                                <p class="text-dark">
                                                <strong><?php echo e(GetTimeFromDateFormat($job->created_at)); ?></strong>                                               
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 mt-sm-4 mt-2">                                        
                                        <p class="text-muted text-lg-left text-md-left text-sm-center text-center mb-0"><?php echo e($job->job_description); ?></p>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <!-- available for -->
                            
                        </div>
                    </div>
                    <!-- content side -->
                    <!-- right side -->
                    <div class="col-lg-3 p-3">
                        <div class="form-group mb-3">
                            <div class="d-flex justify-content-between">
                                <p class="text-muted">Profile completion</p><span>90%</span>
                            </div>
                            <div class="progress completeProfile">
                                <div class="progress-bar bg-success" style="width:90%"></div>
                            </div>
                        </div>
                        <p class="text-center text-muted">Your profile is not completed<br /> yet, Please complete your profile</p>
                        <button type="button" class="btn btn-dark btn-sm btn-block my-4" data-toggle="modal" data-target="#createNewJob">Complete Profile</button>
                        <?php if($user_type=='CLIENT'): ?>
                        <p class="text-center text-muted">You don't have any posted job,<br /> Please create your job</p>
                        <!-- recieved 20+ proposals -->
                        <div class="border rounded p-3 text-center">
                            <p class="h6 mb-0">You have recieved 20+ proposals</p>
                        </div>
                        <!-- recieved 20+ proposals -->                       
                        <a class="btn btn-dark btn-sm btn-block my-4" href="<?php echo e(route('create-job')); ?>">Create New Job</a>
                        <?php endif; ?>
                        
                        <h4 class="text-muted">Tips <img src="public/images/idea.png" alt="idea" /></h4>
                        <p class="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam facere quae
                            delectus praesentium aspernatur eum animi non, harum dicta quis eaque similique, blanditiis
                            magnam! Tempore blanditiis dignissimos sit exercitationem soluta.</p>
                        <p class="text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Est nobis tempore
                            tempora dolorem, autem ratione? Fugiat natus corrupti labore facilis, voluptas itaque?
                            Aperiam quasi cumque, corrupti explicabo blanditiis similique rerum.</p>
                    </div>
                    <!-- right side -->
                </div>
            </div>
        </div>
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<!-- Modal -->
<?php echo $__env->make('user.search-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/home.blade.php ENDPATH**/ ?>