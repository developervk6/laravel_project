<!doctype html>
<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<style type="text/css">
	.container {max-width:940px;margin:0 auto;padding-left:20px;padding-right:20px;background-color:#fff;}	
	</style>
    </head>
    <body style="margin:0; padding:0;">
		<table border="0" style="font-family:Arial, Helvetica, sans-serif;padding-top:20px; padding-bottom:20px; outline:none; border:none; width:100%; font-size:16px;color:#000000; line-height:24px;" class="container">
		  <tr>
			<td colspan="2" align="left"><img border="0" alt="" src="<?php echo e(asset('public/images/logo.png')); ?>"></td>
		  </tr>		  
		  <tr>
			<td colspan="2" style="border-top:1px solid #545554;padding-top:20px; padding-bottom:20px; color: #000000;font-size: 24px;" ><?php echo app('translator')->get('messages.hello'); ?>,</td>
		  </tr>		  	  
		  <tr>
			<td bgcolor="#8cc63e" align="center" colspan="2" style="line-height:24px; padding:40px 20px;">
				 Verification Code: <?php echo e($verification_code); ?>

			</td>
		  </tr>			 
		  <tr>
			<td colspan="2" style="border-top:1px solid #000;padding-top:20px; font-size:14px; padding-bottom:20px; color:#545554;" ></td>
		  </tr>
		</table>
	</body>
</html>
<?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/common/verification-email-template.blade.php ENDPATH**/ ?>