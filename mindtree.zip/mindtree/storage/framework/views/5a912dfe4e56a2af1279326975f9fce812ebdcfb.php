

<?php $__env->startSection('content'); ?>
<div class="container py-5">
            <div class="bg-white shadow rounded">
                <div class="row m-0">
                    <!-- left side -->
                    <div class="col-lg-2 p-3">
                        <h5 class="mb-4">Job Categories</h5>
                        <!-- accordian -->
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel panel-default">
                                <div class="panel-heading active" role="tab" id="headingOne">
                                    <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion"
                                            href="#collapse<?php echo e($category->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                            <?php echo e($category->service_category_name); ?>

                                        </a>
                                    </h4>
                                </div>
                                <?php
                                    $active_class = '';
                                    if(isset($_GET['service_sub_category_id']) && $_GET['service_sub_category_id']>0 && $category->id==$selected_sub_categories_details->service_category_id){
                                        $active_class = "in show";
                                    }
                                ?>
                                <div id="collapse<?php echo e($category->id); ?>" class="panel-collapse collapse <?php echo e($active_class); ?>" role="tabpanel"
                                    aria-labelledby="headingOne">
                                    <div class="panel-body">
                                        <ul class="list-unstyled font-14">
                                            <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a class="text-muted" href="?service_sub_category_id=<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->service_name); ?></a></li>  
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>                           
                        <!-- accordian -->
                    </div>
                    <!-- left side -->                    
                    <!-- content side -->
                    <div
                        class="col-lg-10 p-3 px-lg-4 py-3 border-left border-right border-md-left-0 border-md-right-0 border-md-top-1">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="mb-0">Results as per search filters</h5>
                            <div class="col-lg-4 col-md-4 col-sm-4 p-0 d-flex justify-content-end align-items-center">
                                <i class="fas fa-sliders-h fa-lg text-success cursor-pointer" data-toggle="modal" data-target="#searchPopupModal" data-backdrop="static"></i>
                            </div>
                        </div>
                        <ul class="list-inline mb-4">                            
                            <?php if(isset($selected_categories_details) && !empty($selected_categories_details)): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e($selected_categories_details->service_category_name); ?></span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('service_category_id',<?php echo e($selected_categories_details->id); ?>);"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($selected_sub_categories_details) && !empty($selected_sub_categories_details)): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e($selected_sub_categories_details->service_name); ?></span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('service_sub_category_id',<?php echo e($selected_sub_categories_details->id); ?>);"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>                         
                            <?php if(isset($selected_tags) && !empty($selected_tags)): ?>
                                
                                <?php $__currentLoopData = $selected_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-inline-item mb-2">
                                    <div class="bg-light p-2 rounded">
                                        <span class="text-muted mr-2"><?php echo e($tag->tag); ?></span> 
                                        <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('tag_ids',<?php echo e($tag->id); ?>);"><i class="fas fa-times-circle"></i></a>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?> 
                            <?php if(isset($_GET['new_search'])): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e($_GET['new_search']==1?'New Search':'Ex Candidate'); ?></span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('new_search','<?php echo e($_GET['new_search']); ?>');"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($_GET['service_mode'])): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e(ucfirst(strtolower($_GET['service_mode']))); ?></span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('service_mode','<?php echo e($_GET['service_mode']); ?>');"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>                           
                            <?php if(isset($_GET['service_charges_low']) && isset($_GET['service_charges_high'])): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2">$<?php echo e($_GET['service_charges_low']); ?> to $<?php echo e($_GET['service_charges_high']); ?></span> 
                                        <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('service_charge',0);"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($_GET['fulfilment_of_services'])): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e($_GET['fulfilment_of_services']==0?'Face to Face':$_GET['fulfilment_of_services']==1?'Digital Service Fulfilment':'Flexible'); ?></span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('fulfilment_of_services','<?php echo e($_GET['fulfilment_of_services']); ?>');"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($_GET['expertise_level'])): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e(ucfirst(strtolower($_GET['expertise_level']))); ?></span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('expertise_level','<?php echo e($_GET['expertise_level']); ?>');"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?> 
                            <?php if(isset($_GET['distance']) && $_GET['distance']>0): ?>
                            <li class="list-inline-item mb-2">
                                <div class="bg-light p-2 rounded">
                                    <span class="text-muted mr-2"><?php echo e($_GET['distance']); ?> Miles</span> 
                                    <a class="text-dark" href="javascript:void(0);" onClick="removeSearch('distance','<?php echo e($_GET['distance']); ?>');"><i class="fas fa-times-circle"></i></a>
                                </div>
                            </li>
                            <?php endif; ?>    
                            <li class="list-inline-item mb-2">
                                <a class="text-dark" href="<?php echo e(route('home')); ?>"><u>Clear Filters</u></a>
                            </li>
                        </ul>
                        <?php if($searchResults->total()>0): ?>
                        <div class="row">
                            <!-- available for -->                           
                            <?php $__currentLoopData = $searchResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border-bottom pb-2 mb-4 w-100">
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                                            <div
                                                class="d-flex flex-lg-row flex-md-row flex-sm-column flex-column text-lg-left text-md-left text-sm-center text-center">
                                                <div class="flex-shrink-0 mr-3 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                    <a href="/profile/<?php echo e($user->id); ?>">
                                                        <img class="img-w-60 rounded-circle" src="<?php echo e(getUserProfileImage($user->profile_image)); ?>" alt="img">
                                                    </a>
                                                </div>
                                                <div class="w-100 overflow-hidden">
                                                    <div class="d-flex flex-lg-row flex-md-row flex-sm-column flex-column">
                                                        <h4 class="mb-lg-0 mb-md-0 mb-sm-2 mb-2 mr-2">
                                                            <a href="/profile/<?php echo e($user->id); ?>" class="text-muted">
                                                                <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                                            </a>
                                                        </h4>
                                                    </div>
                                                    <p class="text-muted my-2"><i class="fas fa-map-marker-alt mr-2"></i><?php echo e($user->state_name); ?></p>
                                                    <p class="mb-0"><?php echo e($user->service_name); ?></p>
                                                    <div
                                                        class="d-flex justify-content-lg-start justify-content-md-start justify-content-sm-center justify-content-center mt-2 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                                        <i class="fas fa-star mr-1 text-warning"></i>
                                                        <i class="fas fa-star mr-1 text-warning"></i>
                                                        <i class="fas fa-star mr-1 text-warning"></i>
                                                        <i class="fas fa-star mr-1 text-warning"></i>
                                                        <i class="fas fa-star mr-1 text-warning"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="d-flex flex-column col-lg-2 col-md-3 col-sm-12 col-12 text-lg-center text-md-center text-sm-center text-center">
                                            <p class="text-muted">
                                                <strong><?php echo e(ucfirst(strtolower($user->service_mode))); ?></strong>
                                                <?php 
                                                if($user->service_mode=='FIXED'){
                                                    if(empty($user->service_fixed_charge)){
                                                        echo 'NA';
                                                    }else{
                                                        echo "$".$user->service_fixed_charge; 
                                                    }                                                       
                                                }else{
                                                    if(empty($user->service_charges_low) || empty($user->service_charges_high)){
                                                        echo 'NA';
                                                    }else{
                                                        echo "$".$user->service_charges_low." - $".$user->service_charges_high;
                                                    }
                                                } 
                                                ?>
                                            </p> 
                                            <!-- <button type="button" class="btn btn-success btn-sm btn-block cus-rounded-sm">Invite</button> -->
                                            <button type="button" user_id="<?php echo e($user->id); ?>" class="InviteMemberBtn btn btn-success btn-sm btn-block cus-rounded-sm">Invite</button>
                                            <button type="button" class="btn btn-dark btn-sm btn-block cus-rounded-sm">Message</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 mt-2">
                                    <ul class="list-inline text-lg-left text-md-left text-sm-center text-center">
                                        <?php if($user->service_mode=='FIXED'): ?>
                                        <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                            <div class="border p-2 text-center">
                                                <p class="mb-0">$<?php echo e($user->service_fixed_charge); ?></p>
                                                <small class="text-muted">Hourly Rate</small>
                                            </div>
                                        </li>
                                        <?php endif; ?>
                                        <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                            <div class="border p-2 text-center">
                                                <p class="mb-0">$30k</p>
                                                <small class="text-muted">Total Earned</small>
                                            </div>
                                        </li>
                                        <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                            <div class="border p-2 text-center">
                                                <p class="mb-0">200+</p>
                                                <small class="text-muted">Jobs</small>
                                            </div>
                                        </li>
                                        <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                            <div class="border p-2 text-center">
                                                <p class="mb-0">120Hrs</p>
                                                <small class="text-muted">UM Hours</small>
                                            </div>
                                        </li>
                                    </ul>
                                    <p class="text-muted text-lg-left text-md-left text-sm-center text-center"><?php echo e($user->job_description); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- available for -->   
                            <?php echo $searchResults->appends(request()->query())->links()?>
                        </div>
                        <?php else: ?>
                            <div class="d-flex justify-content-center align-items-center mb-3 bg-light p-2 rounded border">
                                No results found
                            </div>                                
                        <?php endif; ?>                                                       
                    </div>
                    <!-- content side -->
        </div>
    </div>
</div>
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<!-- Modal -->
<?php echo $__env->make('user.search-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="inviteMember" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Send Invite</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php if(count($active_jobs)>0): ?>
                <form>
                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control cus-input" placeholder="Write Message"></textarea>
                    </div>  
                    <div class="form-group">
                        <select name="job_id" id="job_id" class="form-control">
                            <option value="">Select Job</option>                            
                            <?php $__currentLoopData = $active_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($job->id); ?>"><?php echo e($job->job_title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>  
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="hidden" name="user_id" id="user_id" value="">
                            <button type="button" id="btnInviteMember" class="btn btn-dark btn-sm btn-block">Invite</button>                            
                        </div>
                    </div>                                   
                </form>  
                <?php else: ?>
                    <div class="form-group text-center">
                        You didn't post any job yet<br>
                        Please create job to invite candidate.
                    </div> 
                    <div class="row">
                        <div class="col-lg-12">
                            <a class="btn btn-dark btn-sm btn-block my-4" href="<?php echo e(route('create-job')); ?>">Create Job</a>
                        </div>
                    </div>
                <?php endif; ?>              
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<script>
function removeSearch(type,id)
{
    var urlParams = new URLSearchParams(window.location.search);    
    var entries = urlParams.entries();
    var newQueryString = '';
    for(pair of entries) { 
        if(pair[0]==type){
            if(type=='tag_ids' && pair[1]!=''){
                var arrTagIds = pair[1].split(",");
                ararrTagIdsr = arrTagIds.filter(e => e != id);                
                var newTags =  ararrTagIdsr.join(",");           
                newQueryString += pair[0]+'='+newTags;
                newQueryString += "&";
            }  
        }else {
            if(type=='service_charge' && ( pair[0] =='service_charges_low' || pair[0] =='service_charges_high' ) ){
                
            }  else if(pair[1]!='') {
                newQueryString += pair[0]+'='+pair[1];
                newQueryString += "&";
            }          
        }        
    } 
    newQueryString = newQueryString.substring(0, newQueryString.length - 1);
    console.log(newQueryString);
    if(newQueryString==''){
        window.location.href = home_path;
    }else{
        window.location.href = '?'+newQueryString;
    }
    
}
$(".InviteMemberBtn").click(function(){
    $("#user_id").val($(this).attr("user_id"));
    $("#inviteMember").modal();
});
$("#btnInviteMember").click(function(){
    var formPostData = {action:'InviteForJob',user_id:$("#user_id").val(),job_id:$("#job_id").val(),message:$("#message").val()};
    $.ajax({
        type:'POST',
        url:'/AjaxRequest',
        data:formPostData,
        async: false,
        success:function(data){ 
            if(data.code==200){
                alert("This user has invited for job.");
                $('.close').trigger('click');
            } 
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/advance-search-results.blade.php ENDPATH**/ ?>