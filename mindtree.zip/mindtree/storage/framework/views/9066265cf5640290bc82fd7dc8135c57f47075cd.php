
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container my-5">
	<div class="col-lg-5 m-auto">
		<div class="bg-white shadow cus-rounded pb-5">
		<form method="POST" action="/business/join" id="frmJoinBuisness">
            <?php echo csrf_field(); ?>
			<p class="pt-5 pb-4 h5 font-300 text-center px-2">Please enter business code to join</p>
			<div class="col-sm-9 m-auto">
			<?php if(session('message')): ?>
			<div class="col-sm-12">
			<div class="alert alert-danger text-center">
			  <?php echo e(session('message')); ?>

			</div>
			</div>
			<?php endif; ?>
			<div class="col-lg-12 text-center">
                <div class="d-flex"> 				
					<div class="form-group mr-6">
						<div class="custom-control custom-radio">
							<input type="radio" id="customRadio1" name="new_or_existing_user" class="custom-control-input" value="1" checked>
							<label class="custom-control-label" for="customRadio1">New User</label>
						</div>
					</div>
					&nbsp;
					<div class="form-group mr-6">
						<div class="custom-control custom-radio">
							<input type="radio" id="customRadio2" name="new_or_existing_user" class="custom-control-input" value="2">
							<label class="custom-control-label" for="customRadio2">Existing User</label>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 text-center">
				<div class="form-group">
					<input type="text" name="business_code" id="business_code" class="form-control cus-input text-center" placeholder="Business Code"/>
					<?php $__errorArgs = ['business_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>			
			<div class="col-lg-12">
				<button id="btn-submit" type="submit" class="btn btn-dark btn-sm w-100 text-white">
					<?php echo e(__('Join')); ?>

				</button>
			</div>
			</div>		
		</form>
		</div>
	</div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<script>
$("#btn-submit").click(function(e){	
	if($("#business_code").val()==''){
		alert("Please enter business code.");
		return false;
	}else{
		$('#loader').show();
		$("#frmJoinBuisness").submit();	
	}		
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/business/join.blade.php ENDPATH**/ ?>