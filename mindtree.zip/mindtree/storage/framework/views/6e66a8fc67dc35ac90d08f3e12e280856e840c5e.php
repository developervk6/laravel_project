<div class="modal fade" id="searchPopupModal" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
                <button type="button" class="close rightCorner" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            <form name="frmAdvanceSearch" action="/advance-search-results" method="get">
            <div class="modal-body">
                <div class="row">
                <div class="col-lg-6">    
                <div class="form-group">
                    <div class="select-style-left">
                        <select name="service_category_id" id="service_category_id" onChange="populateServiceSubCategories(this.value);">
                        <option value="">Category</option>
                            <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($service_category->id); ?>" <?php echo (isset($_GET['service_category_id']) && $_GET['service_category_id']==$service_category->id)?'selected':'';?>><?php echo e($service_category->service_category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <div class="select-style-left">
                        <select name="service_sub_category_id" id="service_sub_category_id">
                            <option value="">Sub Category</option> 
                            <?php if(isset($selected_sub_categories)): ?>
                                <?php $__currentLoopData = $selected_sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($service_sub_category->id); ?>" <?php echo (isset($_GET['service_sub_category_id']) && $_GET['service_sub_category_id']==$service_sub_category->id)?'selected':'';?>><?php echo e($service_sub_category->service_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>                         
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div id="tagfield" class="black fancyme-tags">
                    <input id="tag_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Keywords" autocomplete="off">
                    <div id="shownlist">
                    <?php 
                        if(isset($selected_tags) && !empty($selected_tags)){
                            foreach($selected_tags as $tag){
                                echo '<span id="tag'.$tag->id.'">'.$tag->tag.'<a href="javascript:void(0);" onclick="removeTag('.$tag->id.')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                            }
                        }
                    ?>
                    </div>
                </div>
            </div> 
            <input type="hidden" id="tag_ids" name="tag_ids" value="">             
            </div>
                <?php if(Auth::user()->user_type=='CLIENT'): ?>
                <div class="d-flex flex-sm-row flex-column mt-3 mb-2 checkBox">
                    <div class="form-group mr-5 mb-sm-0 mb-1">
                        <div class="custom-control custom-radio">
                            <input type="radio" class="custom-control-input" id="customRadio10" name="new_search" value="2" <?php echo (isset($_GET['new_search']) && $_GET['new_search']==2)?'checked':'';?>>
                            <label class="custom-control-label" for="customRadio10">Ex Candidate</label>
                        </div>
                    </div>
                    <div class="form-group mb-sm-0 mb-1">
                        <div class="custom-control custom-radio">
                            <input type="radio" class="custom-control-input" id="customRadio11" name="new_search" value="1" <?php echo (isset($_GET['new_search']) && $_GET['new_search']==1)?'checked':'';?>>
                            <label class="custom-control-label" for="customRadio11">New Search</label>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <p class="my-2 font-bold">Services By</p>
                <div class="d-flex flex-sm-row flex-column checkBox">
                    <?php $i = 1;?>
                    <?php $__currentLoopData = $service_mode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group mr-4 mb-sm-0 mb-1">
                            <div class="custom-control custom-radio">
                                <input type="radio" id="customRadio<?php echo e($i); ?>" name="service_mode" class="custom-control-input" value="<?php echo e($value); ?>" <?php echo (isset($_GET['service_mode']) && $_GET['service_mode']==$value)?'checked':'';?>>
                                <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e(ucfirst(strtolower($value))); ?></label>
                            </div>
                        </div>
                        <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
                <div class="form-group mb-0">
                    <label class="mt-2 mb-3 font-bold">Income Offer</label>
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="slider-range"></div>
                        </div>
                    </div>
                    <div class="row slider-labels mt-3">
                        <div class="col-sm-6 caption">
                            Min:&nbsp;<span id="slider-range-value1"></span>
                        </div>
                        <div class="col-sm-6 d-flex justify-content-end caption">
                           Max:&nbsp;<span id="slider-range-value2"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                                <input type="hidden" name="service_charges_low" id="service_charges_low" value="">
                                <input type="hidden" name="service_charges_high" id="service_charges_high" value="">
                        </div>
                    </div>
                </div>
                <p class="my-2 font-bold">Job Type</p>
                <div class="d-flex flex-sm-row flex-column">
                    <?php $__currentLoopData = $fulfilment_of_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        <div class="form-group mr-4 mb-sm-0 mb-1">
                            <div class="custom-control custom-radio">
                                <input type="radio" id="customRadio<?php echo e($i); ?>" name="fulfilment_of_services" class="custom-control-input" value="<?php echo e($key); ?>" <?php echo (isset($_GET['fulfilment_of_services']) && $_GET['fulfilment_of_services']==$key)?'checked':'';?>>
                                <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e($value); ?></label>
                            </div>
                        </div>
                        <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                </div>                
                <p class="my-2 font-bold">Expertise Level</p>
                <div class="d-flex flex-sm-row flex-column checkBox">
                    <?php $__currentLoopData = $expertise_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        <div class="form-group mr-4 mb-sm-0 mb-1">
                            <div class="custom-control custom-radio">
                                <input type="radio" id="customRadio<?php echo e($i); ?>" name="expertise_level" class="custom-control-input" value="<?php echo e($value); ?>" <?php echo (isset($_GET['expertise_level']) && $_GET['expertise_level']==$value)?'checked':'';?>>
                                <label class="custom-control-label" for="customRadio<?php echo e($i); ?>"><?php echo e(ucfirst(strtolower($value))); ?></label>
                            </div>
                        </div>
                        <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                </div>
                <div class="form-group mt-3">
                    <div class="select-style-left">
                        <select name="distance" id="distance">
                            <option value="">Select Distance</option>
                            <?php $__currentLoopData = $distance_dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <option value="<?php echo e($value); ?>"  <?php echo (isset($_GET['distance']) && $_GET['distance']==$value)?'selected':'';?>><?php echo e($value); ?> Miles</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                    <button id="btn-search" type="submit" class="btn btn-dark btn-sm btn-block">Apply</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    var rangeSlider = document.getElementById('slider-range');
    var moneyFormat = wNumb({
        decimals: 0,
        thousand: ',',
        prefix: '$'
    });
    noUiSlider.create(rangeSlider, {
        start: [<?php echo isset($_GET['service_charges_low'])?$_GET['service_charges_low']:1;?>, <?php echo isset($_GET['service_charges_high'])?$_GET['service_charges_high']:100;?>],
        step: 1,
        range: {
        'min': [1],
        'max': [100]
        },
        format: moneyFormat,
        connect: true
    });        
    // Set visual min and max values and also update value hidden form inputs
    rangeSlider.noUiSlider.on('update', function(values, handle) {
        document.getElementById('slider-range-value1').innerHTML = values[0];
        document.getElementById('slider-range-value2').innerHTML = values[1];
        document.getElementById('service_charges_low').value = moneyFormat.from(values[0]);
        document.getElementById('service_charges_high').value = moneyFormat.from(values[1]);
    });
    $.ajax({
        type:'GET',
        url:'/GetTags',
        success:function(data){
            if(data.status=='done'){
                $("#tag_list").autocomplete({
                    source: data.data,
                    classes: {
                        "ui-autocomplete": "keyword_zindex",
                    },
                    select: function(e, item){
                        var selectedTagIds = $("#tag_ids").val();
                        if (selectedTagIds.split(",").includes(item.item.id+"")) {
                        } else {
                            var spanHtml = '<span id="tag'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeTag('+item.item.id+')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                            $(".fancyme-tags #shownlist").append(spanHtml);
                            if($("#tag_ids").val()==''){
                                $("#tag_ids").val(item.item.id);
                            }else{
                                $("#tag_ids").val($("#tag_ids").val()+','+item.item.id);
                            }
                        }
                        setTimeout(function(){
                            $('#tag_list').val("");
                        },100);
                    }
                });
            }
        }
    });
});
function removeTag(span_id){
    $('#tag'+span_id).remove();
    var value = span_id;
    var arr = $("#tag_ids").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#tag_ids").val(arr.join(","));
}
$("#btn-search").click(function(e){	
    $('.close').trigger('click');
    setTimeout(() => {
        $('#loader').show();
        $("#frmAdvanceSearch").submit();	
    }, 200);    
});
</script>
<style>
.keyword_zindex
{
   z-index: 99999; 
}
</style><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/search-modal.blade.php ENDPATH**/ ?>