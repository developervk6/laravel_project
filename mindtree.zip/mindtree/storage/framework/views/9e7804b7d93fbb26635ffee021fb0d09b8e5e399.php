
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('notifications')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link" id="nav-home-tab" href="/settings/basic-info" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link active" id="nav-profile-tab" href="/settings/skills" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" href="/settings/portfolio" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" role="tab" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" role="tab" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0">                                            
                                            <div class="tab-pane fade show active" id="skills">
                                                <!-- skills keywords -->
                                                
                                                <div class="w-100 d-inline-block border rounded my-4 p-3">
                                                    <div class="form-group">
                                                        <div id="tagfield" class="black fancyme-tags">
                                                            <input id="tag_list" class="form-control cus-input ui-autocomplete-input" type="text" placeholder="Keywords" autocomplete="off">
                                                            <p class="small text-muted mt-2 mb-0">Select your relevent skills/keywords</p>
                                                            <div id="shownlist" class="w-100 border-bottom mb-3">
                                                                <?php 
                                                                    if(!empty($user->tags)){
                                                                        foreach($user->tags as $tag){
                                                                            echo '<span id="tag'.$tag->id.'">'.$tag->tag.'<a href="javascript:void(0);" onclick="removeTag('.$tag->id.')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                                                                        }
                                                                    }
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <input type="hidden" id="selectedTagIds" name="selectedTagIds" value="<?php echo e($user->tag_ids); ?>">  
                                                        <div class="col-lg-12 px-1 text-center">
                                                            <button type="button" id="btnSkillsUpdate" class="btn btn-sm btn-dark px-5">Update</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- skills keywords -->
                                            </div>  
                                        </div>  
                                    </div>  
                                </div> 
                            </div>                                           
                        </section>
                        <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    $.ajax({
        type:'GET',
        url:'/GetTags',
        success:function(data){
            if(data.status=='done'){                   
                $( "#tag_list" ).autocomplete({
                    classes: {
                        "ui-autocomplete": "tag-style",
                    },
                    minLength: 1,
                    maxShowItems: 10,
                    source: data.data,                       
                    select: function(e, item){
                        var selectedTagIds = $("#selectedTagIds").val();
                        if (selectedTagIds.split(",").includes(item.item.id+"") || item.item.value=='') {
                        } else {
                            var spanHtml = '<span id="tag'+item.item.id+'">'+item.item.value+'<a href="javascript:void(0);" onclick="removeTag('+item.item.id+')"><i class="fas fa-times-circle ml-2"></i></a></span>';
                            $(".fancyme-tags #shownlist").append(spanHtml);
                            if($("#selectedTagIds").val()==''){
                                $("#selectedTagIds").val(item.item.id);
                            }else{
                                $("#selectedTagIds").val($("#selectedTagIds").val()+','+item.item.id);
                            }
                        }
                        setTimeout(function(){
                            $('#tag_list').val("");
                        },100);
                    },
                    response: function(event, ui) {
                        if (!ui.content.length) {
                            var noResult = { value:"",label:"No results found" };
                            ui.content.push(noResult);
                        }
                    }
                });
            }
        }
    });
});
$('#btnSkillsUpdate').click(function(e){
    e.preventDefault();
    if($('#selectedTagIds').val()==''){
        alert("Please select skill(s).");
        $('#tag_list').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'/UpdateSkills',
            data:{skills:$("#selectedTagIds").val()},
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
function removeTag(span_id){
    $('#tag'+span_id).remove();
    var value = span_id;
    var arr = $("#selectedTagIds").val().split(",");
    arr = arr.filter(function(item) {
        return item != value;
    });
    $("#selectedTagIds").val(arr.join(","));
} 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/skills.blade.php ENDPATH**/ ?>