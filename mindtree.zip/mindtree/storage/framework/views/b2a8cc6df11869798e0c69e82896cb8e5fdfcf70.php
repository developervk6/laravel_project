
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <h4>
        <a href="<?php echo e(URL::previous()); ?>" class="text-dark">
            <i class="fas fa-arrow-left mr-2 mb-3"></i> 
        </a>
        <?php if(Auth::user()->id==$user->id): ?>
        My Profile
        <?php elseif($user->user_type=='CLIENT'): ?>Client Profile
        <?php else: ?> Applicant Profile 
        <?php endif; ?> 
    </h4>
    <div class="bg-white shadow cus-rounded">
        <div class="row p-4">
            <!-- content side -->
            <div class="col-lg-9 pb-3 border-right border-md-right-0 mt-2">
                <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0 mr-3">
                        <img class="img-box-lg rounded-circle" src="<?php echo e(getUserProfileImage($user->profile_thumb_image)); ?>">
                    </div>
                    <div class="w-100 overflow-hidden">
                        <h4><?php if($user->user_type=='BUSINESS'): ?><?php echo e($user->business_name); ?> <?php else: ?> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> <?php endif; ?></h4>
                        <h5><i class="fas fa-map-marker-alt"></i> <?php echo e($user->state_name); ?>, <?php echo e($user->country_name); ?> - <span class="text-muted">11:11PM Local Time</span></h5>
                        <div class="d-flex cus-w-stars">
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                            <i class="fas fa-star mr-1 text-warning"></i> 
                        </div>
                        <div class="d-flex my-3">
                        <span class="badge badge-light-border font-300 p-2 mr-2"><?php echo e($user->service_category_name); ?></span>
                        <span class="badge badge-light-border font-300 p-2 mr-2"><?php if(isset($user->service_sub_categories->service_name)): ?><?php echo e($user->service_sub_categories->service_name); ?><?php endif; ?></span>
                        </div>
                    </div>
                </div>
                </div>
                <?php if(Auth::user()->id!=$user->id): ?>
                <div class="col-lg-4 col-md-4 col-sm-12 col-12 text-lg-right text-md-right text-sm-left mt-lg-0 mt-md-0 mt-sm-4 mt-4">
                    <a role="button" class="btn btn-outline-secondary <?php if($user->is_favorite==1): ?>active <?php endif; ?>" id="favorite" onClick="FavoriteUnFavorite(<?php echo e($user->id); ?>);"><i class="far fa-heart"></i> Favourite</a>
                    
                    <a role="button" class="btn btn-outline-secondary <?php if($user->is_subscribe==1): ?>active <?php endif; ?>" id="subscribe" onClick="SubscribeInSubscribe(<?php echo e($user->id); ?>);"><i class="fas fa-rss"></i> Subscribe</a>
                </div>
                <?php endif; ?>
                </div>
                <!-- tabs -->
                <div class="mt-4">
                        <div class="custom-tab">
                        <nav class="mb-3">
                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Overview</a>
                            <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                            <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Portfolio</a>
                            <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Experience</a>
                            <?php if($user->user_type=='FREELANCER'): ?>
                            <a class="nav-item nav-link" id="nav-education-tab" data-toggle="tab" href="#nav-education" role="tab" aria-controls="nav-education" aria-selected="false">Education</a>
                            <?php endif; ?>
                                <?php if($user->user_type=='BUSINESS'): ?>
                                <a class="nav-item nav-link" id="nav-team-tab" data-toggle="tab" href="#nav-team" role="tab" aria-controls="nav-team" aria-selected="false">Team</a>
                                <?php endif; ?>                            
                            <?php endif; ?>
                            <a class="nav-item nav-link" id="nav-about-tab" data-toggle="tab" href="#nav-about" role="tab" aria-controls="nav-about" aria-selected="false">Reviews</a>
                            </div>
                        </nav>
                        <div class="tab-content py-3 px-sm-0" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                            <!-- overview -->  
                            <ul class="list-inline text-lg-left text-md-left text-sm-center text-center">
                                <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                    <div class="border p-2 text-left">
                                        <p class="mb-0">$20.00</p>
                                        <small class="text-muted">Hourly Rate</small>
                                    </div>
                                </li>
                                <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                    <div class="border p-2 text-left">
                                        <p class="mb-0">$30k</p>
                                        <small class="text-muted">Total Earned</small>
                                    </div>
                                </li>
                                <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                    <div class="border p-2 text-left">
                                        <p class="mb-0">200+</p>
                                        <small class="text-muted">Jobs</small>
                                    </div>
                                </li>
                                <li class="list-inline-item line-height-1 mb-lg-0 mb-md-0 mb-sm-2 mb-2">
                                    <div class="border p-2 text-left">
                                        <p class="mb-0">120Hrs</p>
                                        <small class="text-muted">UM Hours</small>
                                    </div>
                                </li>
                            </ul> 
                            <p class="text-muted"><?php echo e($user->overview); ?></p>
                            <!-- overview -->
                            </div>
                            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <!-- Portfolio --> 
                            <div class="row">
                                <?php if(count($user->portfolios)>0): ?>
                                <?php $__currentLoopData = $user->portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($portfolio->medias) && count($portfolio->medias)>0): ?>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                    <div class="card border-0">  
                                        <?php if(isset($portfolio->cover_media->media_file)): ?>                                    
                                        <div class="card-top-image" style="background:url('<?php echo e(URL($portfolio->cover_media->media_file)); ?>')"></div>
                                        <?php endif; ?>
                                        <img class="card-img-top" >
                                        <div class="card-body px-0">
                                            <h5 class="card-title text-muted"><?php echo e($portfolio->title); ?></h5>
                                            <p class="card-text text-muted"><?php echo e($portfolio->description); ?></p>
                                            <!-- <p class="mb-0">[<?php echo e(count($portfolio->medias)); ?>] Photos</p> -->
                                            <a href="javascript:void(0);" onClick="PortfolioImages('<?php echo e($portfolio->media_ids); ?>');">[<?php echo e(count($portfolio->medias)); ?>] Photos</a>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12">
                                    <button class="btn btn-secondary btn-sm btn-block">View More</button>
                                </div>
                                <?php endif; ?> 
                            </div>
                            <!-- Portfolio -->
                            </div>
                            <!-- Experience -->
                            <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">                             
                                <div class="row">
                                    <div class="col-lg-12">
                                        <?php if(!empty($user->experiences)): ?>                                    
                                        <?php $__currentLoopData = $user->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->last) $class='py-3'; else $class = 'border-bottom py-3 pb-3';?>
                                        <div class="<?php echo e($class); ?>">
                                            <h4 class="font-300"><?php echo e($experience->title); ?></h4 class="font-300">
                                            <p class="text-muted font-300"><?php echo e($experience->description); ?></p>
                                            <div class="d-flex">
                                                <p>2 Months (500 Hrs)</p>
                                                <span class="text-muted ml-4"><?php echo e(date("M Y",strtotime($experience->from_date))); ?> <strong class="mx-2">TO</strong> <?php echo e(date("M Y",strtotime($experience->to_date))); ?></span>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?> 
                                        No experience added.
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                            <!-- Experience -->
                            <!-- Education -->
                            <?php if($user->user_type=='FREELANCER'): ?>  
                            <div class="tab-pane fade" id="nav-education" role="tabpanel" aria-labelledby="nav-education-tab">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <?php if(!empty($user->educations)): ?>                                    
                                        <?php $__currentLoopData = $user->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->last) $class='py-3'; else $class = 'border-bottom py-3 pb-3';?>
                                        <div class="<?php echo e($class); ?>">
                                            <h4 class="font-300"><?php echo e($education->institute_name); ?></h4 class="font-300">
                                            <p class="text-muted font-300"><?php echo e($education->degree_name); ?></p>
                                            <p class="text-muted font-300"><?php echo e($education->description); ?></p>
                                            <div class="d-flex">
                                                <span class="text-muted"><?php echo e(date("M Y",strtotime($education->from_date))); ?> <strong class="mx-2">TO</strong> <?php echo e(date("M Y",strtotime($education->to_date))); ?></span>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?> 
                                        No education added.
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <!-- Education -->                            
                            <!-- team -->
                            <div class="tab-pane fade" id="nav-team" role="tabpanel" aria-labelledby="nav-team-tab">
                                <div class="row">
                                    <?php if(!empty($user->members)): ?>
                                    <?php $__currentLoopData = $user->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-3 col-sm-3 col-12 mb-lg-0 mb-md-0 mb-sm-3 mb-3">
                                        <div class="card cus-rounded p-3">
                                            <a href="/profile/<?php echo e($member->id); ?>" class="text-center">
                                                <img class="img-50 rounded-circle m-auto" src="<?php echo e(getUserProfileImage($user->profile_thumb_image)); ?>">
                                            </a>
                                            <div class="card-body text-center p-0">
                                                <h4 class="card-title mt-3 mb-0 font-300"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></h4>
                                                <p class="mb-0 text-muted"><?php echo e($member->service_sub_category_name); ?></p>
                                                <div class="my-2">
                                                <i class="fas fa-star mr-1 text-warning small"></i>
                                                <i class="fas fa-star mr-1 text-warning small"></i>
                                                <i class="fas fa-star mr-1 text-warning small"></i>
                                                <i class="fas fa-star mr-1 text-warning small"></i>
                                                <i class="fas fa-star mr-1 text-warning small"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!-- team -->

                            <div class="tab-pane fade" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab">
                            <!-- Reviews -->   
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="border-bottom pb-3">
                                    <h4 class="font-300">Town a Photography</h4 class="font-300">
                                    <div class="d-flex">
                                    <div>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <span>5.00</span>
                                    </div>   
                                    <span class="text-muted ml-4">March 2018 <strong class="mx-2">TO</strong> April 2018</span>
                                    </div>    
                                    <p class="text-muted font-300 mt-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
                                    <div class="d-flex">
                                        <p>$1200</p>
                                        <p class="text-muted ml-4">Fixed</p>
                                    </div>
                                </div>
                                <div class="py-3">
                                    <h4 class="font-300">Wedding Photographers</h4 class="font-300">
                                    <div class="d-flex">
                                    <div>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <i class="fas fa-star mr-1 text-warning"></i>
                                    <span>5.00</span>
                                    </div>   
                                    <span class="text-muted ml-4">March 2018 <strong class="mx-2">TO</strong> April 2018</span>
                                    </div>    
                                    <p class="text-muted font-300 mt-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
                                    <div class="d-flex">
                                        <p>$1200</p>
                                        <p class="text-muted ml-4">Fixed</p>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!-- Reviews -->
                            <button class="btn btn-secondary btn-sm btn-block">View More</button>
                            </div>
                        </div>
                        </div>
                </div>
                <!-- tabs -->
            </div>
            <!-- content side -->
            <!-- right side -->
            <?php echo $__env->make('user.profile-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- right side -->
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- slider Modal -->
<div class="modal fade" id="imageSlider" tabindex="-1" role="dialog" aria-labelledby="imageSliderLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="close font-300 position-absolute rightCorner" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="height:auto;">
                    <ol class="carousel-indicators">
                       
                    </ol>
                    <div class="carousel-inner">
                            
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--slider Modal -->
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});  
function PortfolioImages(media_ids){
    var top_li;
    var bottom_li;
    $.ajax({
        type:'GET',
        url:'/common/portfolio-images/'+media_ids,
        async: false,
        success:function(data){
            if(data.code==200){
                $(".carousel-indicators").html("");
                $(".carousel-inner").html("");
                for(var i in data.portfolio_medias){
                    var media = data.portfolio_medias[i];
                    if(i==0){
                        top_li = '<li data-target="#carouselExampleIndicators" data-slide-to="'+i+'" class="active"></li>';
                    }else{
                        top_li = '<li data-target="#carouselExampleIndicators" data-slide-to="'+i+'"></li>';
                    }                    
                    $(".carousel-indicators").append(top_li);
                    if(i==0){
                        bottom_li = '<div class="carousel-item active"><img class="d-block w-100" src="'+media.media_file+'"></div>';
                    }else{
                        bottom_li = '<div class="carousel-item"><img class="d-block w-100" src="'+media.media_file+'"></div>';
                    }                    
                    $(".carousel-inner").append(bottom_li);
                }                 
                $("#imageSlider").modal();       
            }
        }
    });
} 
$(document).ready(function () {
    // accordian
    $('.panel-collapse').on('show.bs.collapse', function () {
        $(this).siblings('.panel-heading').addClass('active');
    });

    $('.panel-collapse').on('hide.bs.collapse', function () {
        $(this).siblings('.panel-heading').removeClass('active');
    });
});
function FavoriteUnFavorite(favorite_user_id){  
    $('#loader').show();
    var formPostData = {favorite_user_id:favorite_user_id}
    $.ajax({
        type:'POST',
        url:'/favorite-unfavorite',
        data:formPostData,
        async: false,
        success:function(data){   
            if(data.favorite==1){
                $("#favorite").addClass('active');
            }else{
                $("#favorite").removeClass('active');
            }
            $('#loader').hide();           
        }
    });
}
function SubscribeInSubscribe(subscriber_user_id){  
    $('#loader').show();
    var formPostData = {subscriber_user_id:subscriber_user_id}
    $.ajax({
        type:'POST',
        url:'/subscribe-unsubscribe',
        data:formPostData,
        async: false,
        success:function(data){ 
            if(data.subscribe==1){
                $("#subscribe").addClass('active');
            }else{
                $("#subscribe").removeClass('active');
            } 
            $('#loader').hide();          
        }
    });
}
function BlockUnBlock(blocked_user_id){  
    $('#loader').show();
    var formPostData = {blocked_user_id:blocked_user_id}
    $.ajax({
        type:'POST',
        url:'/block-unblock',
        data:formPostData,
        async: false,
        success:function(data){  
            $('#loader').hide();          
        }
    });
}
$("#btnInviteMember").click(function(){
    var formPostData = {action:'InviteForJob',user_id:$("#user_id").val(),job_id:$("#job_id").val(),message:$("#message").val()};
    $.ajax({
        type:'POST',
        url:'/AjaxRequest',
        data:formPostData,
        async: false,
        success:function(data){ 
            if(data.code==200){
                alert("This user has invited for job.");
                $('.close').trigger('click');
            } 
        }
    });
});
</script>
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/profile.blade.php ENDPATH**/ ?>