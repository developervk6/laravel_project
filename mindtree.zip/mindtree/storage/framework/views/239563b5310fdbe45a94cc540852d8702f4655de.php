<?php $__env->startSection('content'); ?>
    <!-- slider -->
    <div id="carouselExampleIndicators" class="home carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>        
    </div>
    <!-- Footer section -->
    <div class="bg-dark-l">
        <div class="bg-dark p-3 footer">
            <div class="container text-md-left text-sm-center text-center">
                <p class="mb-0 text-silver">@All  Rights Reserved, Mind Tree 2020</p>
            </div>
        </div>
    </div> 
    <!-- Footer section -->
</body>
<script type="text/javascript" src="public/js/jquery-2.2.2.js"></script>
<script type="text/javascript" src="public/js/popper.min.js"></script>
<script type="text/javascript" src="public/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="public/js/common-functions.js"></script>
<script src="public/js/owl/owl.carousel.js"></script>
<!-- owl scripts -->
<script>
jQuery(document).ready(function($) {
        		"use strict";
        		//  TESTIMONIALS CAROUSEL HOOK
		        $('#customers-testimonials').owlCarousel({
		            loop: true,
		            center: true,
		            items: 3,
		            margin: 0,
		            autoplay: true,
		            dots:true,
		            autoplayTimeout: 8500,
		            smartSpeed: 450,
		            responsive: {
		              0: {
		                items: 1
		              },
		              768: {
		                items: 2
		              },
		              1170: {
		                items: 3
		              }
		            }
		        });
        	});
</script>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\mindtree2\resources\views/welcome.blade.php ENDPATH**/ ?>