
<?php $__env->startSection('content'); ?>
<!-- content section-->
<form action="" name="" method="post">
<?php echo csrf_field(); ?>
<input type="hidden" name="id" id="id" value="">
<input type="hidden" name="otp" id="otp" value="">
<input type="hidden" name="email_hidden" id="email_hidden" value="">
<input type="hidden" name="mobile_hidden" id="mobile_hidden" value="">
<input type="hidden" name="country_code" id="country_code" value="">
<!---Step 1 -->
<div class="container cus-margin" id="step1">
	<div class="col-lg-5 m-auto">
		<div class="bg-white shadow cus-rounded pb-5">
			<p class="pt-5 pb-4 h5 font-300 text-center">Please enter your email/phone number</p>
			<div class="col-sm-9 m-auto">
				<div class="col-lg-12 text-center mb-3">
					<div class="form-group">
						<input id="emailorphone" type="text" class="form-control cus-input text-center" name="emailorphone" value="<?php echo e(old('emailorphone')); ?>" required placeholder="<?php echo e(__('Email/Phone Number')); ?>">
					</div>
					<button type="button" id="btn-next" class="btn btn-dark btn-sm w-100 text-white">
						<?php echo e(__('Next')); ?>

					</button>
				</div>
			</div>
		</div>
	</div>
</div>
<!----Step 1-- End --->
<!----Step 2-- Start --->
<div class="container pt-5" id="step2" style="display:none;">
	<div class="row">
		<div class="col-lg-5 m-auto">
			<div class="bg-white shadow rounded p-5">
				<div class="row">
					<p class="h5 font-300 text-left line-height">Please select from following options to Recover your
						Password</p>
					<div class="form-group w-100" id="email_div">
						<div class="custom-control custom-checkbox recover_pass mr-sm-2 my-3">
							<input type="checkbox" class="custom-control-input" id="email-checkbox" name="email-checkbox" value="1">
							<label class="custom-control-label font-500"
								for="email-checkbox">Email</label>
						</div>
						<span class="w-100 text-muted pl-4" id="email_span"></span>
					</div>
					<div class="form-group w-100" id="mobile_div">
						<div class="custom-control custom-checkbox recover_pass mr-sm-2 my-3">
							<input type="checkbox" class="custom-control-input" id="mobile-checkbox" name="mobile-checkbox" value="1">
							<label class="custom-control-label font-500"
								for="mobile-checkbox">Phone Number</label>
						</div>
						<span class="w-100 text-muted pl-4" id="mobile_span"></span>
					</div>
					<button type="button" id="btn-send-code" class="btn btn-dark btn-sm w-100 text-white mt-4">
					<?php echo e(__('Send Code')); ?>

				    </button>
				</div>
			</div>
		</div>
	</div>
</div>
<!----Step2 End --->	
<!----Step3 Start --->
<div class="container pt-5" id="step3" style="display:none;">
	<div class="row">
		<div class="col-lg-5 m-auto">
			<div class="bg-white shadow rounded p-5">
				<div class="row">
					<p class="h5 font-300 text-center line-height">Please Provide the code to reset the password sent to your Email Address &amp; Phone Number</p>
					<div class="col-lg-8 col-md-12 col-sm-12 col-12 m-auto">
							<!-- <div class="form-group mt-3">
								<input type="text" name="verifivation_code" id="verification_code" class="form-control cus-input text-center" />
							</div> -->
						<div class="row mt-4">
							<div class="col pr-1">
								<input type="text" id="otp1" class="form-control cus-input text-center" maxlength="1" onkeyup="validateOtpInput(this.value,1);"/>
							</div>
							<div class="col px-1">
								<input type="text" id="otp2" class="form-control cus-input text-center"  maxlength="1" onkeyup="validateOtpInput(this.value,2);"/>
							</div>
							<div class="col px-1">
								<input type="text" id="otp3" class="form-control cus-input text-center"  maxlength="1" onkeyup="validateOtpInput(this.value,3);"/>
							</div>
							<div class="col pl-1">
								<input type="text" id="otp4" class="form-control cus-input text-center"  maxlength="1" onkeyup="validateOtpInput(this.value,4);"/>
							</div>
                            <button type="button" id="btn-code-validate" class="btn btn-dark btn-sm w-100 text-white my-4">
                                <?php echo e(__('Next')); ?>

							</button>
						</div>
					</div>
					<p class="d-flex justify-content-center w-100">Didn't Recieve Code? <a class="text-dark ml-2" href="javascript:void();" onCLick="return resendCode();"><b>Send Again</b></a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<!----Step3 End --->	
<!----Step4 Start --->			
<div class="container py-5" id="step4" style="display:none">
	<div class="col-lg-5 m-auto">
		<div class="bg-white shadow cus-rounded p-lg-5 py-5">
			<div class="col-lg-12">
			<p class="pb-4 h5 font-300 text-left">Please Set New Password</p>
			</div>
			<div class="w-100">
			<div class="col-lg-12 text-center mb-3">
				<div class="form-group">
					<input type="password" name="password" id="password" class="form-control cus-input"  placeholder="New Password" autocomplete="off"/>
				</div>
			</div>
			<div class="col-sm-6" id="password-label" style="display:none">
				<div class="row mb-3">
					<div class="col-sm-4 pr-lg-1 text-center" id="password-weak" style="display:none">
						<div class="d-flex flex-column">
							<div class="bg-warning height-6 mb-1"></div>
							<span class="small">Weak</span>
						</div>
					</div>
					<div class="col-sm-4 pr-lg-1 text-center" id="password-good" style="display:none">
						<div class="d-flex flex-column">
							<div class="bg-success height-6 mb-1 opacity-4"></div>
							<span class="small">Good</span>
						</div>
					</div>
					<div class="col-sm-4 pr-lg-1 text-center" id="password-strong" style="display:none">
						<div class="d-flex flex-column">
							<div class="bg-success height-6 mb-1"></div>
							<span class="small">Strong</span>
						</div>
					</div>  
				</div>
			</div>
				
			<div class="col-lg-12 text-center mb-3">
				<div class="form-group">
					<input type="password" id="password-conf" name="password-conf" class="form-control cus-input"  placeholder="Confirm Password" autocomplete="off"/>
				</div>
			</div>
			<div class="form-group col-lg-12">
				<div class="custom-control custom-checkbox mr-sm-2 my-3">
					<input type="checkbox" class="custom-control-input" id="customControlAutosizing">
					<label class="custom-control-label font-500 small text-muted"
						for="customControlAutosizing">Require that all devices sign in with new password</label>
				</div>			
				<div class="col-lg-12 col-md-12 col-sm-12 col-12 px-1">
					<button type="button" id="btn-submit" class="btn btn-dark btn-sm w-100 text-white mt-2">
						<?php echo e(__('Submit')); ?>

					</button>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>
<!----Step4 End --->		
</form>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<script>
var pattern = new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{6,}$/);
	$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
	$("#btn-next").click(function(e){		
		e.preventDefault();
		if($('#emailorphone').val()==''){
			alert("Please enter Email/Phone Number.");
			$('#emailorphone').focus();
			return false;
		}else{
			var formData = {action:'account_check',emailorphone:$('#emailorphone').val()};
			$.ajax({
				type:'POST',
				url:'/AjaxForgotPassword',
				data:formData,
				async: false,
				success:function(data){
					if(data.status=='done'){
						if(data.code==200){
							$("#id").val(data.data.id);
							//document.getElementById("step1").style.display = "none !important";

							$('#step1').hide();
							//$('#step1').css("display","none !important");
							$('#step2').show();
							console.log(data.data);
							if(data.data.email=='' || data.data.email==null){
								$("#email_div").hide();
							}else{
								$("#email_div").show();
								var email = data.data.email;
								var avg, splitted, part1, part2;
								splitted = email.split("@");
								part1 = splitted[0];
								avg = parseInt(part1.length/2);
								part1 = part1.substring(avg, part1.length);
								part2 = splitted[1];
								var star = '';	
								for(i=0;i<avg;i++){
									star +='*';
								}
								splited_email = star+part1+"@" + part2;
								$("#email_span").html(splited_email);
							}
							if(data.data.mobile=='' || data.data.mobile==null){
								$("#mobile_div").hide();
							}else{
								$("#mobile_div").show();
								var mobile = data.data.mobile;
								var mobileSplited = mobile.substring(5, 10);
								var splitedMobile = "******"+mobileSplited;
								$("#mobile_span").html(splitedMobile);
							}
						}else if(data.code==404){
							alert("Email/Phone Number does not exists.");
							return false;
						}
					}
				}
			});
		}
	});	
	$("#btn-send-code").click(function(e){		
		e.preventDefault();
		if($('#email-checkbox').is(":not(:checked)") && $('#mobile-checkbox').is(":not(:checked)") ){
			alert("Please choose Email/Phone option.");
			return false;
		}else{
			var email_checked = 0;
			var mobile_checked = 0;
			if($('#email-checkbox').is(":checked")){
				email_checked = 1;
			}
			if($('#mobile-checkbox').is(":checked")){
				mobile_checked = 1;
			}
			if(email_checked==0 && mobile_checked==0){
				alert("Please select email or phone to recover your password.");
				return false;
			}else{
				var formData = {action:'send_code',user_id:$('#id').val(),send_to_email:email_checked,send_to_monbile:mobile_checked};
				$.ajax({
					type:'POST',
					url:'/AjaxForgotPassword',
					data:formData,
					async: false,
					success:function(data){
						if(data.code==200){
							$('#step1').hide();
							$('#step2').hide();
							$('#step3').show();
							$('#otp').val(data.data.otp);
						}else if(data.code==404){
							alert("Error in sending code");
							return false;
						}
					}
				});
			}
		}
	});
	$("#btn-code-validate").click(function(e){		
		e.preventDefault();

		var verification_code = $('#otp1').val()+$('#otp2').val()+$('#otp3').val()+$('#otp4').val();
		if($('#otp1').val()=='' || $('#otp2').val()=='' || $('#otp3').val()=='' || $('#otp4').val()==''){
			alert("Please enter verification code.");
			$('#otp1').focus();
			return false;
		}else if(verification_code!=$('#otp').val()){
			alert("Please enter valid verification code.");
			$('#otp1').val("");
			$('#otp2').val("");
			$('#otp3').val("");
			$('#otp4').val("");
			$('#otp1').focus();
			return false;		
		}else{
			$('#step1').hide();
			$('#step2').hide();
			$('#step3').hide();
			$('#step4').show();
		}
	});
	$("#btn-submit").click(function(e){		
		e.preventDefault();
		if($('#password').val()==''){
			alert("Please enter password.");
			return false;
		}else if($('#password').val().length<6){
			alert("Password should be minimum 6 characters.");
			$('#password').focus();
			return false;
		}else if($('#password-conf').val()==''){
			alert("Please enter confirm password.");
			return false;
		}else if($('#password').val()!=$('#password-conf').val()){
			alert("Password and confirm password does not match.");
			$('#password').focus();
			return false;	
		}else{
			var password = $('#password').val();			
			var formData = {action:'set_password',user_id:$('#id').val(),password:password};
			$.ajax({
				type:'POST',
				url:'/AjaxForgotPassword',
				data:formData,
				async: false,
				success:function(data){
					if(data.code==200){
						alert("Your password has been reset successfully.");
						window.location.href= "<?php echo URL('/login')?>"; 
					}else if(data.code==404){
						alert("Error in resetting password");
						return false;
					}
				}
			});
		}
	});	
	$('#password').keyup(function(){
		if($(this).val().length<1){
			$("#password-label").hide();
			$("#password-weak").hide();
			$("#password-good").hide();
			$("#password-strong").hide();
		}else if($(this).val().length<=4){
			$("#password-label").show();
			$("#password-weak").show();
			$("#password-good").hide();
			$("#password-strong").hide();
		}else if($(this).val().length>6 && !pattern.test($(this).val())){
			$("#password-label").show();
			$("#password-good").show();
			$("#password-weak").hide();
			$("#password-strong").hide();
		}else if($(this).val().length>6 && pattern.test($(this).val()) ){
			$("#password-label").show();			
			$("#password-strong").show();
			$("#password-weak").hide();
			$("#password-good").hide();
		}
	});
	function splitedEmail(user_email) {
		alert(user_email);
		var avg, splitted, part1, part2;
		splitted = user_email.split("@");
		part1 = splitted[0];
		avg = parseInt(part1.length/2);
		part1 = part1.substring(avg, part1.length);
		part2 = splitted[1];
		var star = '';	
		for(i=0;i<avg;i++){
			star +='*';
		}
		return star+part1+"@" + part2;
	}
	function resendCode(){
		var email_checked = 0;
		var mobile_checked = 0;
		if($('#email-checkbox').is(":checked")){
			email_checked = 1;
		}
		if($('#mobile-checkbox').is(":checked")){
			mobile_checked = 1;
		}
		if(email_checked==0 && mobile_checked==0){
			alert("Please select email or phone to recover your password.");
			return false;
		}else{
			var formData = {action:'send_code',user_id:$('#id').val(),send_to_email:email_checked,send_to_monbile:mobile_checked};
			$.ajax({
				type:'POST',
				url:'/AjaxForgotPassword',
				data:formData,
				async: false,
				success:function(data){
					if(data.code==200){
						alert("New verification code sent.");
						$('#otp').val(data.data.otp);
					}else if(data.code==404){
						alert("Error in sending code");
						return false;
					}
				}
			});
		}
	}
	function validateOtpInput(otp,box){
		if(otp==''){
			if(box!=1){
				var box = parseInt(box)-1;
				$("#otp"+box).focus();
			}
		}else if(isNaN(otp)){
			alert("Invalid otp");
		}else if(otp!=''){
			if(box<4){
				var box = parseInt(box)+1;
				$("#otp"+box).focus();
			}
		}
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/forgot-password.blade.php ENDPATH**/ ?>