
<?php $__env->startSection('page_title',__('404 Error')); ?>
<?php $__env->startSection('content'); ?>
<div class="body-area">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-login contributors">
                    <div class="login-title col-md-10 col-md-offset-1" style="top:120px;">
                    <h2 style="border-bottom:0px solid #27a9e1 !important;">404 Not Found</h2></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/error/404.blade.php ENDPATH**/ ?>