mailto:?subject=<?php echo e(rawurlencode($title)); ?>&body=<?php echo e(rawurlencode($url)); ?>

<?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/vendor/chencha/share/src/Chencha/Share/../../views/email.blade.php ENDPATH**/ ?>