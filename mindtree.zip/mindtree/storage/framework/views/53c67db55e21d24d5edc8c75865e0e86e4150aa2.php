
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow rounded p-5">
        <h1 class="text-lg-left text-md-left text-sm-center text-center">Search Results</h1>
        <p class="text-lg-left text-md-left text-sm-center text-center"><?php echo e($keyword); ?> (<?php echo $searchResults->total()>1?$searchResults->total()." Results":$searchResults->total()." Result";?>)</p>        
        <?php foreach ($searchResults as $user): ?>
            <div class="row my-5 pb-4 border-bottom">
                <div class="col-lg-8 col-md-8 col-sm-8  d-flex justify-content-lg-start justify-content-md-start justify-content-sm-start justify-content-center mb-sm-0 mb-4">
                    <div class="d-flex">
                        <div class="flex-shrink-0 mr-3">
                           
                            <a href="/profile/<?php echo e($user->id); ?>" class="text-center">
                                <img class="img-box rounded-circle m-auto" src="<?php echo e(getUserProfileImage($user->profile_image)); ?>">
                            </a>  
                        </div>
                        <div class="w-100 overflow-hidden">
                                <?php if($user->user_type=='BUSINESS'): ?>
                                    <h4>
                                        <a href="/profile/<?php echo e($user->id); ?>" class="text-muted">
                                            <?php echo e($user->business_name); ?> (<?php echo e(ucfirst(strtolower($user->user_type))); ?>)
                                        </a>
                                    </h4>
                                <?php else: ?>
                                    <h4>
                                        <a href="/profile/<?php echo e($user->id); ?>" class="text-muted">
                                            <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> (<?php echo e(ucfirst(strtolower($user->user_type))); ?>)
                                        </a>
                                    </h4>
                                <?php endif; ?>                          
                            <div class="d-flex">
                                <i class="fas fa-star mr-1 text-warning"></i> 
                                <i class="fas fa-star mr-1 text-warning"></i> 
                                <i class="fas fa-star mr-1 text-warning"></i> 
                                <i class="fas fa-star mr-1 text-warning"></i> 
                                <i class="fas fa-star mr-1 text-warning"></i> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 text-lg-right text-md-right text-sm-right text-center">
                    <p class="font-500 text-muted"><i class="fas fa-map-marker-alt mr-2"></i> <?php echo e($user->state_name); ?></p>
                    <h4>
                    <?php 
                        if($user->service_mode=='FIXED'){
                            if(empty($user->service_fixed_charge)){
                                echo 'NA';
                            }else{
                                echo "$".$user->service_fixed_charge."/hr"; 
                            }                                                       
                        }else{
                            if(empty($user->service_charges_low) || empty($user->service_charges_high)){
                                echo 'NA';
                            }else{
                                echo "$".$user->service_charges_low." - $".$user->service_charges_high."/hr";
                            }
                        } 
                    ?>
                    </h4>
                </div>
                <div class="col-lg-11 text-lg-left text-md-left text-sm-center text-center">
                    <p><?php echo e($user->job_description); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
        <?php echo $searchResults->appends(request()->query())->links()?>       
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/search-results.blade.php ENDPATH**/ ?>