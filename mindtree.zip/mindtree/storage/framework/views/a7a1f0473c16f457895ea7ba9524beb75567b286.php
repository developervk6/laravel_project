<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-sm-12">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div>
  <?php endif; ?>
</div>
<div class="col-sm-12">
    <h1 class="display-3">Routers</h1>  
	<div style="margin: 10px 10px 20px 0px;">
		<a href="<?php echo e(route('add-new-router')); ?>" class="btn btn-primary">Add New Router</a>
		<span style="float:right;"><input type="text" name="search_keyword" id="search_keyword" placeholder="Search"></span>
    </div>	
  <table class="table table-striped">
    <thead>
        <tr>
          <td style="width:10%;">ID</td>
          <td style="width:10%;">Type</td>
		  <td style="width:15%;">SapId</td>
          <td style="width:15%;">Hostname</td>
          <td style="width:15%;">Loopback</td>
          <td style="width:15%;">Mac Address</td>
          <td colspan ="2" style="width:20%;">Actions</td>
        </tr>
    </thead>
	</table>
	<div id="results_router">
		<?php if(count($networks)>0): ?>
			<?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<table class="table table-striped">
				<tr>
					<td style="width:10%;"><?php echo e($network->id); ?></td>
					<td style="width:10%;"><?php echo e($network->type); ?></td>
					<td style="width:15%;"><?php echo e($network->SapId); ?></td>
					<td style="width:15%;"><?php echo e($network->Hostname); ?></td>			
					<td style="width:15%;"><?php echo e($network->Loopback); ?></td>
					<td style="width:15%;"><?php echo e($network->MacAddress); ?></td>
					<td style="width:10%;">
						<a href="<?php echo e(URL('/')); ?>/network-routers/edit-router/<?php echo e($network->id); ?>" class="btn btn-primary">Edit</a>
					</td>
					<td style="width:10%;">
						<a class="btn btn-danger" href="javascript:void();" onClick="deleteNetworkRouter(<?php echo e($network->id); ?>);">Delete</button>
					</td>
				</tr>
			</table>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($networks->appends(request()->query())->links()); ?>

		<?php else: ?>
			No records found
		<?php endif; ?>
		
	</div>  
<div>
</div>
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$("#search_keyword").keyup(function(){
	var formPostData = {action:"SearchRouter",search_keyword:$(this).val()};
	$.ajax({
		type:'POST',
		url:"<?php echo e(URL('/')); ?>"+"/AjaxRequest",
		data:formPostData,
		async: false,
		success:function(data){
			if(data.code==200){
				var html = '<table class="table table-striped">';
				if(data.data.length>0){					
					for(i=0;i<data.data.length;i++){					
						var network = data.data[i];
						html += '<tr>';
						html += '<td style="width:10%;">'+network.id+'</td>';
						html += '<td style="width:10%;">'+network.type+'</td>';
						html += '<td style="width:15%;">'+network.SapId+'</td>';
						html += '<td style="width:15%;">'+network.Hostname+'</td>';
						html += '<td style="width:15%;">'+network.Loopback+'</td>';		
						html += '<td style="width:15%;">'+network.MacAddress+'</td>';
						html += '<td style="width:10%;">';
						html += '<a href="<?php echo e(URL("/")); ?>/network-routers/edit-router/'+network.id+'" class="btn btn-primary">Edit</a>';
						html += '</td>';
						html += '<td style="width:10%;">';
						html += '<form action="<?php echo e(URL("/")); ?>/network-routers/delete-router" method="post">';
						html += '<input type="hidden" name="id" value="'+network.id+'"/>';
						html += '<a class="btn btn-danger" href="javascript:void();" onClick="deleteNetworkRouter('+network.id+');">Delete</a>';
						html += '</form>';
						html += '</td>';
						html += '</tr>';
					}
				}else{
					html = 'No results found';
				}	
				html += '</table>';
				$("#results_router").html("");				
				$("#results_router").html(html);	
			}
		}
	}); 
});
function deleteNetworkRouter(id){
	var formPostData = {action:'deleteRouter',id:id};
	if(confirm("Are you sure do you wan to delete this?")){
		$.ajax({
			type:'POST',
			url:"<?php echo e(URL('/')); ?>/AjaxRequest",
			data:formPostData,
			async: false,
			success:function(data){
				if(data.code==200){
					alert("Deleted successfully");
					window.location.href=document.URL;
				}
			}
		});
	}
}	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\mindtree\resources\views/networks/index.blade.php ENDPATH**/ ?>