<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Mind Tree">
    <meta name="keywords" content="test">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Mind Tree</title>
    <!-- stylesheets -->
    <link rel="shortcut icon" href="<?php echo e(URL('/')); ?>/public/images/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/style.css">
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/bootstrap-4.css">
	
	<!-- Owl Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/owl/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/owl/owl.theme.default.css">
	
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css"
        integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <!-- stylesheets -->
    <link rel="stylesheet" href="<?php echo e(URL('/')); ?>/public/css/stepper.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link href="<?php echo e(URL('/')); ?>/public/css/two-handle.css" rel="stylesheet" />
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL('/')); ?>/public/css/fancymetags.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL('/')); ?>/public/css/mBox.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <?php //echo view("common.js-vars");?>
</head>
<body>
    <div class="wrapper bg-light">
		<!-- header -->
            <nav class="navbar navbar-expand-md navbar-dark bg-dark py-0 pb-sm-0">
            <div class="container">
                <a class="navbar-brand logo py-3"  href="<?php echo e(url('/')); ?>">
					Mind Tree
				</a>
                <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarCollapse"
					aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto d-flex align-items-center">						
						<li class="nav-item mr-lg-4 mr-md-4 mobile-menu">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('network-routers')); ?>"><?php echo e(__('Routers')); ?></a>
                        </li>
                        <li class="nav-item mr-lg-4 mr-md-4 mobile-menu">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item mr-lg-5 mr-md-5 mobile-menu">
                            <a class="nav-link mb-0 text-white font-300" href="<?php echo e(route('signup')); ?>"><?php echo e(__('Signup')); ?></a>
                        </li>                       
                    </ul>
                </div>
            </div>
            </nav>            
		<!-- header -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
<!-- loader -->
<div id="loader" class="loader-wrap">
    <div class="loader"></div>
</div>
<!-- loader --> 
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});  
</script>
</body>
</html>
<?php /**PATH F:\xampp\htdocs\mindtree2\resources\views/layouts/app.blade.php ENDPATH**/ ?>