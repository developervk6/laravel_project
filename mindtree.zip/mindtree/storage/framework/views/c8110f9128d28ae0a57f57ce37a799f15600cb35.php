
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">
                    <div class="col-lg-2 col-md-3 col-sm-12 col-12">
                        <ul id="setting" class="list-unstyled text-lg-left text-md-left text-sm-center text-center border">
                            <li><a class="bg-success border-bottom border-light text-white d-block p-2" href="<?php echo e(URL('settings/basic-info')); ?>">Profile</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/security')); ?>">Password &amp; Security</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(URL('settings/notification')); ?>">Notifications</a></li>
                            <li><a class="bg-light border-bottom border-light text-dark d-block p-2" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-12 col-12">
                        <!-- Tabs -->
                        <section id="profileTab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <nav>
                                            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                                                <a class="nav-item nav-link active" id="nav-home-tab" href="/settings/basic-info" role="tab" aria-selected="true">Basic Info</a>
                                                <?php if($user->user_type=='BUSINESS' || $user->user_type=='FREELANCER'): ?>
                                                <a class="nav-item nav-link" id="nav-profile-tab" href="/settings/skills" role="tab" aria-controls="nav-profile" aria-selected="false">Skills/Keyword</a>
                                                <a class="nav-item nav-link" id="nav-contact-tab" href="/settings/portfolio" role="tab" aria-controls="nav-contact" aria-selected="false">Portfolio</a>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/experience" role="tab" aria-controls="nav-about" aria-selected="false">Experience</a>
                                                    <?php if($user->user_type=='FREELANCER'): ?>
                                                    <a class="nav-item nav-link" id="nav-about-tab" href="/settings/education" role="tab" aria-controls="nav-about" aria-selected="false">Education</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/contact-info" role="tab" aria-controls="nav-about" aria-selected="false">Contact Info</a>
                                                <?php if($user->user_type=='BUSINESS'): ?>
                                                <a class="nav-item nav-link" id="nav-about-tab" href="/settings/team" role="tab" aria-controls="nav-about" aria-selected="false">Team</a>
                                                <?php endif; ?>
                                            </div>
                                        </nav>
                                        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                                            <div class="tab-pane fade show active" id="basic-info" role="tabpanel" aria-labelledby="nav-home-tab">
                                                <!-- basic info -->
                                                <div class="col-lg-10 m-auto bg-white shadow p-2">
                                                    <div class="d-flex flex-sm-row flex-column align-items-center justify-content-between">
                                                        <p class="text-dark mb-sm-0 mb-2 text-sm-left text-center">Note: <span class="text-muted">To make changes in your basic profile please click on edit button</span></p>
                                                        <a role="button" class="btn btn-dark text-white">
                                                            <span class="d-inline-block faCircle bg-white rounded-circle text-center mr-1"><i class="fas fa-pen text-dark"></i></span> Edit</a>
                                                    </div>
                                                </div>
                                                <div class="border rounded my-4 p-3">
                                                    <div class="d-flex flex-sm-row flex-column align-items-center">
                                                        <form class="form-register" action="" method="post" id="mediaForm" enctype="multipart/form-data">
                                                        <input type="hidden" name="id" id="id" value="<?php echo e($user->id); ?>">
                                                        <div class="flex-shrink-0 mr-3">
                                                            <div class="position-relative dropdown dropright">
                                                                <div class="profile-pic rounded-circle" style="background: url(<?php echo e(getUserProfileImage($user->profile_thumb_image)); ?>)"></div>
                                                                <span class="bg-white position-absolute profile-pen cursor-pointer" data-toggle="dropdown"><i class="fas fa-pencil-alt"></i></span>
                                                                <div class="dropdown-menu dropdown-menu-right shadow-sm cus-rounded py-0 overflow-hidden">
                                                                    <a class="dropdown-item" href="javascript:void(0);" onclick="$('#image').click();">Change Picture</a>
                                                                    <a class="dropdown-item" href="javascript:void(0);" onclick="$('#video').click();">Add short video</a>
                                                                </div>
                                                                <input id="image" name="image" type="file" style="display:none" />
                                                                <input id="video" name="video" type="file" style="display:none" />
                                                            </div>
                                                        </div>
                                                        </form>
                                                        <div class="w-100 mt-sm-0 mt-2 text-sm-left text-center">
                                                            <h5 class="mb-sm-0 mb-2">
                                                                <?php if($user->user_type=='BUSINESS'): ?><?php echo e($user->business_name); ?> <?php else: ?> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> <?php endif; ?> 
                                                                <a href="javascript:void(0);"  data-toggle="modal" data-target="#basicProfile">
                                                                    <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-4"></i>
                                                                </a>
                                                            </h5>
                                                            <p class="mb-0 my-2"><i class="fas fa-map-marker-alt"></i> <?php echo e($user->state_name); ?>, <?php echo e($user->country_name); ?> - 11:11 PM Local Time <a href="#" data-toggle="modal" data-target="#changeLocation"><i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg ml-3"></i></a></p>
                                                        </div>
                                                    </div>
                                                    <!-- content -->
                                                    <div class="border my-4 rounded p-2">
                                                        <div class="w-100 text-right">
                                                            <a href="javascript:void(0);"  data-toggle="modal" data-target="#overviewModal">
                                                                <i class="fas fa-pen-square cursor-pointer text-muted-50 fa-lg"></i>
                                                            </a>
                                                        </div>
                                                        <p class="text-muted"><?php if(!empty($user->overview)): ?><?php echo e($user->overview); ?> <?php else: ?> Overview <?php endif; ?> </p>
                                                    </div>
                                                    <!-- content -->
                                                </div>
                                                <!-- basic info -->

                                                <!-- identity verification -->
                                                <div class="border my-4 rounded p-4">
                                                    <div class="d-flex flex-sm-row flex-column justify-content-between align-items-center">
                                                        <h5 class="font-300">Identity Verification</h5>
                                                        <a class="btn btn-dark text-white" href="javascript:void(0);" onClick="showIdProofBox();"><i class="fas fa-plus-circle mr-1"></i> Add</a>
                                                    </div>
                                                    <div class="d-flex align-items-center my-4">
                                                        <div class="flex-shrink-0 mr-4">
                                                            <?php if(isset($govt_id->govt_id) && $govt_id->is_verified==1): ?>)
                                                                <i class="far fa-check-circle fa-2x"></i>
                                                            <?php else: ?>
                                                                <i class="fas fa-times-circle fa-2x"></i>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="w-100">
                                                            <p class="mb-0 text-muted">Identity verification is a good to get best clients/services and it helps in resolving the disputes.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- identity verification -->
                                                <!-- Drag and Drop -->
                                                <div class="border my-4 rounded p-4" id="id_proof" style="<?php if(!isset($govt_id->govt_id)): ?>display:none; <?php endif; ?>">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                                            <div class="drapDrop-small rounded shadow m-auto bg-white position-relative">
                                                                <span id="profile_image_span">
                                                                    <?php if(isset($govt_id->media_file) && !empty($govt_id->media_file)): ?>
                                                                        <img class="img-fluid" src="<?php echo e(URL($govt_id->media_file)); ?>">
                                                                    <?php else: ?>
                                                                        <i class="fas fa-user fa-3x position-absolute setIcon"></i>
                                                                    <?php endif; ?>
                                                                </span>
                                                                <input class="custom-file-input" type="file" name="govtIdProof" id="govtIdProof"/>
                                                                <input type="hidden"  title="" name="idproof_media_id" id="idproof_media_id">
                                                                
                                                            </div>
                                                            <div class="progress" style="display:none;">
                                                                <div class="progress-bar"></div>
                                                            </div>
                                                            <!-- <span class="mt-2 d-block">Upload Picture</span>
                                                            <div class="drapDrop-small rounded d-flex align-items-center justify-content-center mb-lg-0 mb-sm-4 mb-4 position-relative">
                                                                <input class="custom-file-input smalldragDropFile" type="file" id="fileInput" multiple size="50">
                                                                <p class="text-muted-50 text-center mb-0 position-absolute">Drag your file or <strong>Browse</strong> to upload</p>
                                                                <div class="showImage position-absolute" style="background:url('https://dev.unitedmarket.co/public/users/profile_image/profile_thumb_image_1588088682_43978.png') no-repeat;"></div>
                                                            </div> -->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-6 col-12 d-flex align-self-end flex-column">
                                                            <h5 class="font-300">Please attach your Govt. Id proof to verify your account.</h4>
                                                            <p class="text-muted">Our concerned team will verify your identity proof and update you about your verification badge.</p>
                                                            <span class="small text-muted">This process will take 24 to 72 hours.</span>
                                                            <a role="button" id="addIdProof" class="btn btn-dark btn-sm text-white mt-3">Upload</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Drag and Drop -->
                                            </div>                                           
                                </section>
                                <!-- ./Tabs -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<!-- Modal Basic Info Start-->
<div class="modal fade" id="basicProfile" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Basic Profile</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>NOTE: You cannot change your first name &amp; last name after verification</p>
                <form method="POST" action="" id="ProfileForm">
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_type" id="user_type" value="<?php echo e($user->user_type); ?>">
                    <?php if($user->user_type=='BUSINESS'): ?>
                    <div class="form-group">
                        <input type="text" name="business_name" id="business_name" class="form-control cus-input" value="<?php echo e($user->business_name); ?>"/>
                    </div>
                    <?php else: ?>
                    <div class="form-group">
                        <input type="text" name="first_name" id="first_name" class="form-control cus-input" value="<?php echo e($user->first_name); ?>" />
                    </div>
                    <div class="form-group">
                        <input type="text" name="first_name" id="last_name" class="form-control cus-input" value="<?php echo e($user->last_name); ?>" />
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <div class="position-relative">
                            <input type="text" id="user_name" name="user_name" class="form-control cus-input pr-5" placeholder="User Name" value="<?php echo e($user->user_name); ?>" <?php if(isset($user->user_name)): ?> readonly <?php endif; ?>/>
                            <span class="rightIcon position-absolute" id="isAvailableIcon" style="display:none;">
                                <i class="fas fa-check-circle text-success"></i>
                            </span>
                            <span class="rightIcon position-absolute" id="isNotAvailableIcon" style="display:none;">
                                <i class="fas fa-times text-danger"></i>
                            </span>
                        </div>
                        <?php if(!isset($user->user_name)): ?> 
                        <div class="d-flex justify-content-between">
                            <p class="small text-muted mt-2 mb-0">Select unique username<br>
                            NOTE: You can add your username only once</p>
                            <span class="small text-success mt-2" id="isAvailable" style="display:none;">Available</span>
                            <span class="small text-danger mt-2" id="isNotAvailable" style="display:none;">Not Available</span>
                        </div>
                        <?php endif; ?>
                    </div>
                        <button type="button" id="btnAddBasicProfile" class="btn btn-dark btn-sm btn-block">Save</button>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal  Basic Info End-->
<!-- Modal Current Location Start-->
<div class="modal fade" id="changeLocation" tabindex="-1" role="dialog" aria-labelledby="createNewJobLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Change Location</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Please provide following details</p>
                <form method="POST" action="" id="LocationForm">
                <?php echo csrf_field(); ?>                 
                    <div class="form-group">
                        <div class="select-style-left">
                        <select name="country" id="country" onChange="populateStatesOfCountry(this.value);">                                               
                            <option value="">Country</option>
                            <?php if(!empty($countries)): ?>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" <?php if($country->id==$user->country): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="select-style-left">
                            <select name="state" id="state" onChange="populateCitiesOfState(this.value);">
                            <?php if(!empty($states_of_selected_country)): ?>
                                <?php $__currentLoopData = $states_of_selected_country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->id); ?>" <?php if($state->id==$user->state): ?> selected <?php endif; ?>><?php echo e($state->name); ?></option>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>                                             
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="select-style-left">
                            <select name="city" id="city">
                            <?php if(!empty($cities_of_selected_state)): ?>
                                <?php $__currentLoopData = $cities_of_selected_state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>" <?php if($city->id==$user->city): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>                                                  
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" id="zipcode" name="zipcode" value="<?php echo e($user->zipcode); ?>" maxlength="6" class="form-control cus-input" placeholder="Zip Code"/>
                    </div>
                    <div class="form-group">
                        <label>Add Address (Optional)</label>
                        <textarea class="form-control" placeholder="Address" rows="4" id="address2" name="address2"><?php echo e($user->address2); ?></textarea>
                    </div>
                        <button id="btnCurrentLocation" type="button" class="btn btn-dark btn-sm btn-block ">Save</button>
                </form>               
            </div>
        </div>
    </div>
</div>
<!-- Modal Current Location End-->
<!-- Modal About Us Start-->
<div class="modal fade" id="overviewModal" tabindex="-1" role="dialog" aria-labelledby="overviewLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center pb-0">
                <h4 class="mb-0">Overview</h4>
                <button type="button" class="close font-300" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="" id="OverviewForm">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <textarea class="form-control" placeholder="Overview" rows="10" id="overview" name="overview"><?php echo e($user->overview); ?></textarea>
                    </div>
                        <button type="button" id="btnOverview" class="btn btn-dark btn-sm btn-block">Save</button>
                </form>                
            </div>
        </div>
    </div>
</div>
<!-- Modal About Us End-->
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    
});
function showIdProofBox(){
    $('#add_id_verification').hide();
    $("#id_proof").show();
}
var timer;
var x;
$('#user_name').keyup(function(){
    var user_name = $('#user_name').val();
    if(user_name==''){
        $("#isAvailableIcon").hide();
        $("#isAvailable").hide();
        $("#isNotAvailableIcon").hide();
        $("#isNotAvailable").hide();
        return false;
    }else{
        if (x) { x.abort() } 
        clearTimeout(timer); 
        timer = setTimeout(function() { 
            var formPostData = {user_name: user_name};
            $.ajax({
                type:'POST',
                url:'/isUsernameAvailable',
                data:formPostData,
                async: false,
                success:function(data){
                    if(user_name==''){
                        $("#isAvailableIcon").hide();
                        $("#isAvailable").hide();
                        $("#isNotAvailableIcon").hide();
                        $("#isNotAvailable").hide();
                        return false;
                    }else if(data.isAvailable==1){
                        $("#isAvailableIcon").show();
                        $("#isAvailable").show();
                        $("#isNotAvailableIcon").hide();
                        $("#isNotAvailable").hide();
                    }else{
                        $("#isAvailableIcon").hide();
                        $("#isAvailable").hide();
                        $("#isNotAvailableIcon").show();
                        $("#isNotAvailable").show();
                        return false;
                    }
                }
            }); 
        }, 500); 
    }
});
$('#btnAddBasicProfile').click(function(e){
    e.preventDefault();
    var user_type = $("#user_type").val();                
    if(user_type!='BUSINESS' && $('#first_name').val()==''){
        alert("Please enter first name.");
        $('#first_name').focus();
        return false;
    }else if(user_type!='BUSINESS' && $('#last_name').val()==''){
        alert("Please enter last name.");
        $('#last_name').focus();
        return false;			
    }else if(user_type=='BUSINESS' && $('#business_name').val()==''){
        alert("Please enter business name.");
        $('#business_name').focus();
        return false;  
    }else{
        if(user_type=='BUSINESS'){
            var business_name = $("#business_name").val();
            formPostData = {business_name:business_name,user_name:$("#user_name").val()};
        }else{
            var first_name = $("#first_name").val();
            var last_name = $("#last_name").val();
            formPostData = {first_name:first_name,last_name:last_name,user_name:$("#user_name").val()};
        }     
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:formPostData,
            async: false,
            success:function(data){
                if(data.code==210){
                    alert("Username already exists.");
                    return false;
                }else if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        }); 
    }
});
$('#btnCurrentLocation').click(function(e){
    e.preventDefault();
    if($('#country').val()==''){
        alert("Please select country.");
        $('#country').focus();
        return false;
    }else if($('#state').val()==''){
        alert("Please select state.");
        $('#state').focus();
        return false;
    }else if($('#city').val()==''){
        alert("Please select city.");
        $('#city').focus();
        return false;
    }else if($('#zipcode').val()==''){
        alert("Please enter zip code.");
        $('#zipcode').focus();
        return false;
    }else if($('#zipcode').val() !='' && $('#zipcode').val().length<4){
        alert("Invalid zip code");
        $('#zipcode').focus();
        return false;
    }else{
        var country = $("#country").val();
        var state = $("#state").val();
        var city = $("#city").val();                   
        var zipcode = $("#zipcode").val();
        var address2 = $("#address2").val();
        var formData = {city:city,state:state,country:country,zipcode:zipcode,address2:address2};     
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:formData,
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
$('#btnOverview').click(function(e){
    e.preventDefault();
    if($('#overview').val()==''){
        alert("Please enter overview.");
        $('#overview').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:{overview:$("#overview").val()},
            success:function(data){
                if(data.code==200){
                    window.location.href=document.URL;
                }
            }
        });
    }
});
$("#image").change(function(){
   
    var allowedTypes = ['image/jpeg','image/png','image/jpg'];
    var fileType = '';   
    var isValid = true;
    var formData = new FormData();
    fileType = $(this).get(0).files[0].type;
    if(!allowedTypes.includes(fileType)){
        isValid = false;
    }
    if(!isValid){
        alert('Please select a valid file (JPEG/JPG/PNG).');
        $("#fileInput").val('');
        return false;
    }else{     
        $('#loader').show();
        $.ajax({
            type: "POST",
            url: base_path+"/upload_profile_image",
            data:new FormData($("#mediaForm")[0]),
            dataType:'json',
            async:false,
            processData: false,
            contentType: false,
            success:function(response){
                if(response.success=='done'){
                    window.location.href=document.URL;
                }
            },
        });
    }
});
$("#video").change(function(){
   
    var allowedTypes = ['video/quicktime','video/mp4','video/mov','video/avi'];
    var fileType = '';   
    var isValid = true;
    var formData = new FormData();
    fileType = $(this).get(0).files[0].type;
    if(!allowedTypes.includes(fileType)){
        isValid = false;
    }
    if(!isValid){
       alert('Please select a valid file (AVI/MP4/MOV).');
       $("#fileInput").val('');
       return false;
    }else{
        $('#loader').show();
        $.ajax({
            type: "POST",
            url: base_path+"/upload_story_video",
            data:new FormData($("#mediaForm")[0]),
            dataType:'json',
            async:false,
            processData: false,
            contentType: false,
            success:function(response){
                if(response.success=='done'){
                    alert("Story video uploaded successfully.");
                    window.location.href=document.URL;
                }
            },
        });
    }
});
// drag and drop
function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            var htmlPreview =
                '<img class="img-fluid" src="' + e.target.result + '" />'
            //'<p>' + input.files[0].name + '</p>';
            var wrapperZone = $(input).parent();
            var previewZone = $(input).parent().parent().find('.preview-zone');
            var boxZone = $(input).parent().parent().find('.preview-zone').find('.box1').find('.box-body');

            wrapperZone.removeClass('dragover');
            previewZone.removeClass('hidden');
            boxZone.empty();
            boxZone.append(htmlPreview);
        };
        reader.readAsDataURL(input.files[0]);
    }
}
$("#govtIdProof").change(function(){
    var allowedTypes = ['image/jpeg','image/png','image/jpg'];
    var fileType = '';   
    var isValid = true;
    var formData = new FormData();
    fileType = $(this).get(0).files[0].type;
    if(!allowedTypes.includes(fileType)){
        isValid = false;
    }
    formData.append("media_files[]", $(this).get(0).files[0]);
    if(!isValid){
        alert('Please select a valid file (JPEG/JPG/PNG).');
        $("#fileInput").val('');
        return false;
    }else{     
        $('.progress').show();
        $.ajax({                
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = parseInt((evt.loaded / evt.total) * 100);
                        $(".progress-bar").width(percentComplete + '%');
                        $(".progress-bar").html(percentComplete+'%');
                    }
                }, false);
                return xhr;
            },
            type: 'POST',
            url: '/api/upload-medias',
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                $(".progress-bar").width('0%');
                //$('#uploadStatus').html('<img src="images/loading.gif"/>');
            },
            error:function(){
                $('#uploadStatus').html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
            },
            success: function(resp){                    
                if(resp.code == 200){
                    $('.progress').hide();
                    var media_ids = resp.media_ids;
                    var media_files = resp.media_files;
                    var media_urls = resp.media_urls;                  
                    $('#idproof_media_id').val(media_ids[0]);
                    var img = '<img src="'+media_urls[0]+'">';
                    $('#profile_image_span').html(img);
                }
            } 
        });
    }
}); 
$('#addIdProof').click(function(e){
    e.preventDefault();
    if($('#idproof_media_id').val()==''){
        alert("Please upload an image.");
        $('#idproof_media_id').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'/UpdateUserInfo',
            data:{idproof_media_id:$("#idproof_media_id").val()},
            success:function(data){
                if(data.code==200){
                    alert("Document uploaded successfully. This process will take 24 to 72 hours.");
                    window.location.href=document.URL;
                }
            }
        });
    }
});
</script>
<style>
.custom-file-input::before{
    width:100%;
    height:88px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/basic-info.blade.php ENDPATH**/ ?>