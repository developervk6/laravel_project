
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white border p-4">
        <div class="row justify-content-between">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="d-flex justify-content-between flex-sm-row flex-column">
                    <h2 class="text-sm-left text-center">Settings</h2>
                </div>
                <div class="row mt-2">                    
                    <div class="col-lg-5 col-md-5 col-sm-12 col-12 m-auto">
                        <div class="w-100 mb-2">                           
                            <div class="bg-light p-3 d-flex justify-content-between align-items-center mb-3">
                                <h5 class="font-300 mb-0">Two Step Verification</h5>
                            </div>
                            <div class="collapse show" id="passwordAccordian">                                
                                <?php if($user->mode=='question'): ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                    <form action="" name="frmTwoStepVerification" id="frmTwoStepVerification" method="post">
                                    <div class="row">
                                        <div class="col-lg-12">                                            
                                                <?php $__currentLoopData = $user->security_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-group">
                                                        <label><?php echo e($question->security_question); ?></label>
                                                        <input type="text" name="answers[]" id="answer<?php echo e($loop->iteration); ?>" class="form-control cus-input answer" placeholder="Answer" />
                                                        <input type="hidden" name="security_question_ids[]" value="<?php echo e($question->id); ?>">
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>                             
                                    </div>
                                    <div class="col-sm-12 col-12 m-auto">
                                        <div class="row">                                           
                                            <div class="col-lg-12 col-md-6 col-sm-12 col-12 px-1">
                                                <button id="btn-verify" class="btn btn-dark btn-sm mb-0 w-100 text-white" type="button">Verify</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                                <?php elseif($user->mode=='phone'): ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                    <form action="" name="frmTwoStepVerification" id="frmTwoStepVerification" method="post">
                                    <input type="hidden" name="id" id="id" value="<?php echo e($user->id); ?>">
                                    <input type="hidden" name="otp_generated" id="otp_generated" value="">
                                    <div class="row">
                                        <div class="col-lg-12">                                            
                                            <div class="form-group">
                                                <label>Phone Number</label>
                                                <span class="w-100 text-muted">******<?php echo e(substr($user->mobile,6)); ?></span>
                                            </div>
                                            <div class="form-group" id="otpDiv" style="display:none;">
                                                <label>OTP</label>
                                                <input type="text" name="otp" id="otp" class="form-control cus-input answer" placeholder="OTP" />
                                            </div>
                                        </div>                             
                                    </div>
                                    <div class="col-sm-12 col-12 m-auto">
                                        <div class="row">                                           
                                            <div class="col-lg-12 col-md-6 col-sm-12 col-12 px-1">
                                                <button id="btn-send-otp" class="btn btn-dark btn-sm mb-0 w-100 text-white" type="button">Send Otp</button>
                                                <button id="btn-otp-verify" style="display:none;" class="btn btn-dark btn-sm mb-0 w-100 text-white" type="button">Verify</button>
                                            </div>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                                <?php else: ?>
                                <div>
                                    two step verification not active.
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end-->
<script src="<?php echo e(URL('/')); ?>/public/js/main.js"></script>
<script>
var pattern = new RegExp(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{6,}$/);
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
$(document).ready(function(){
    
});
$("#btn-verify").click(function(){
    var error = 0;
    $(".answer").each(function(){
        if($(this).val()==''){
            error = 1;
        }
    });
    if(error==1){
        alert("Please write answer of all questions");
        return false;
    }else{
        var security_question_ids = $('input[name="security_question_ids[]"]').map(function(){ 
            return this.value; 
        }).get();
        var answers = $('input[name="answers[]"]').map(function(){ 
            return this.value; 
        }).get();
        $.ajax({
            type: 'POST',
            url: '/AjaxRequest',
            data: {action:'TwoStepVerification',security_question_ids:security_question_ids,answers:answers},
            async: false,
            success: function(data) {  
                if(data.code==200){
                    localStorage.setItem('TwoStepVerified',1);
                    window.location.href = "<?php echo e(URL('/settings/basic-info')); ?>";
                }else{
                    alert("Please write correct answer of all the the questions.");
                    return false;
                }      
            }
        });
    }
});
$("#btn-send-otp").click(function(){
    var formData = {action:'send_code',user_id:$('#id').val(),send_to_monbile:1};
    $.ajax({
        type:'POST',
        url:'/AjaxForgotPassword',
        data:formData,
        async: false,
        success:function(data){
            if(data.code==200){
                $('#btn-send-otp').hide();
                $('#btn-otp-verify').show();
                $('#otpDiv').show();
                $('#otp_generated').val(data.data.otp);
            }else if(data.code==404){
                alert("Error in sending code");
                return false;
            }
        }
    });
});
$("#btn-otp-verify").click(function(e){		
    e.preventDefault();
    var verification_code = $('#otp_generated').val();
    if($('#otp').val()==''){
        alert("Please enter verification code.");
        $('#otp').focus();
        return false;
    }else if(verification_code!=$('#otp').val()){
        alert("Please enter valid verification code."); 
        $('#otp').focus();      
        return false;		
    }else{
        $.ajax({
            type: 'POST',
            url: '/AjaxRequest',
            data: {action:'TwoStepVerificationPhone'},
            async: false,
            success: function(data) {  
                if(data.code==200){
                    localStorage.setItem('TwoStepVerified',1);
                    window.location.href = "<?php echo e(URL('/settings/basic-info')); ?>";
                }   
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/settings/two-step-verification.blade.php ENDPATH**/ ?>