
<?php $__env->startSection('content'); ?>
<!-- content section-->
<div class="container py-5">
    <div class="bg-white shadow cus-rounded p-lg-5 p-md-5 p-sm-5 p-4">
        <!-- notification 1 -->
        <?php if(count($notifications)>0): ?>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-dismissible fade show cus-alert <?php if(!$loop->last): ?> border-bottom <?php endif; ?> px-0" role="alert">
            <div class="row w-100 h5 font-300 text-muted d-flex justify-content-between align-items-center">
                <div class="col-lg-9 col-md-9 col-sm-7 col-12">
                    <p class="mb-0"><?php echo e($notification->message); ?></p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-5 col-12 d-flex align-items-center justify-content-between">
                    <button type="button" class="close px-lg-4 px-md-4 px-sm-4 px-0 font-300 order-1" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <p class="mb-0 order-2"><?php echo e(date("d M y",strtotime($notification->created_at))); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="alert alert-dismissible fade show cus-alert px-0"
            role="alert">
            <div class="row w-100 h5 font-300 text-muted d-flex justify-content-between align-items-center">
                <div class="col-lg-9 col-md-9 col-sm-7 col-12">
                    <p class="mb-0">No records found</p>
                </div>                
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<!-- content section-->
<!-- Footer section -->
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>                           
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
}); 
</script> 
<!-- Footer section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/web/ec2-23-20-13-30.compute-1.amazonaws.com/public_html/resources/views/user/notifications.blade.php ENDPATH**/ ?>