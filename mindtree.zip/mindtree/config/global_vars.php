<?php
return
[
    'show_results_per_page'  => "10",
    'timeline' => array(
                    'Less than a week',
                    'Less than a month',
                    'Long term'
                    ),
    'distance_dropdown' => array(
                                10,
                                20,
                                50,                        
                                100,
                                200,
                                500,
                                1000
                            ),    
    'fulfilment_of_services' => array(
                                    'Face to Face',
                                    'Digital Service Fulfilment',
                                    'Flexible'
                                    ),
    'expertise_level' => array(
                                    'ENTRY',
                                    'INTERMEDIATE',
                                    'EXPERT'
                                    ),
    'service_mode' => array(
                                    'HOURLY',
                                    'FIXED',
                                    'FLEXIBLE'
                                    ),
    'availibility_hours' => array(
                                "0"       =>'10 Hours per week',
                                "1"       =>'20 Hours per week',
                                "2"       =>'30 Hours per week',
                                "3"       =>'40 Hours per week',                        
                                "4"       =>'50 Hours per week',
                                "5"       =>'60 Hours per week',
                                "6"       =>'70 Hours per week'
                            ),
    
];


