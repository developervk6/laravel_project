<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
		for($i = 0; $i < 20; $i++) {
			DB::table('networks')->insert([
				'type' => 'AG1',
				'SapId' => 'SapId_'.Str::random(8),
				'HostName' => 'HostName_'.Str::random(5),
				'Loopback' => '218.214.128.'.$i,
				'MacAddress' => 'MacAddress_'.Str::random(6),
			]);			
		}
    }
}
