<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/logout','Auth\LoginController@logout')->name('logout');
Route::post('/logout','Auth\LoginController@logout')->name('logout');
Route::get('login/{provider}', 'SocialAuthLinkedinController@redirectToProvider');
Route::get('{provider}/callback', 'SocialAuthLinkedinController@handleProviderCallback');

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/404','CommonController@page_not_found')->name('page_not_found');
///Login&Signup
Route::get('/signup', 'UserController@UserSignup')->name('signup');
Route::get('/login', 'UserController@UserLogin')->name('login');
Route::post('/signup', 'UserController@UserSignup')->name('signup');
Route::post('/login', 'UserController@UserLogin')->name('login');

Route::get('/','WelcomeController@Welcome')->name('welcome');
Route::get('/network-routers', 'NetworkController@index')->name('network-routers');
Route::get('/network-routers/add-new-router', 'NetworkController@AddNewRouter')->name('add-new-router');
Route::post('/network-routers/add-new-router', 'NetworkController@AddNewRouter')->name('add-new-router-post');
Route::get('/network-routers/edit-router/{id}', 'NetworkController@EditRouter')->name('edit-router');
Route::post('/network-routers/edit-router-post', 'NetworkController@EditRouter')->name('edit-router-post');
Route::post('/network-routers/delete-router', 'NetworkController@DeleteRouter')->name('delete-router');
Route::post('/AjaxRequest', 'AjaxController@Ajax');


