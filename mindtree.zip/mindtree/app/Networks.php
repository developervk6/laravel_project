<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Networks extends Model
{
    protected $fillable = [
		'type',
        'SapId',
        'Hostname',
        'Loopback',
        'MacAddress'
    ];
}
