<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use DatabaseSeeder;

class SeedCommand extends Command
{
    protected $signature = 'app:seed {limit}';

    public function handle(DatabaseSeeder $seeder)
    {
        $limit = $this->argument('limit');
        $seeder->run($limit);
    }
}