<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use AWS;
use DB;

class CommonController extends Controller
{ 
    public function page_not_found()
    {
        return view('error.404');
    }   
       
}
