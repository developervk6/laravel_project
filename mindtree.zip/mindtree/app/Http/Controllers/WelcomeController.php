<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WelcomeController extends Controller
{
     /**
     * Show the application \homepage.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function Welcome()
    {
        if(!Auth::guest()){
            return redirect(route('home'));  
        }
        return view('welcome');
    }
}
