<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Networks;
use DB;
use Validator;

class NetworkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $networks = Networks::select("*")->where("is_deleted",0)->orderBy("id","desc")->paginate(10);
		$dataForView['networks'] = $networks;
        return view('networks.index', $dataForView);
    }
	
	public function SearchRouter(Request $request)
    {
        $networks = DB::table('networks')->select("*");					
		$networks = $networks->where(function($query) use ($request){
			$query->orWhere("SapId","LIKE","%".$request->search_keyword."%");
			$query->orWhere("Hostname","LIKE","%".$request->search_keyword."%");
			$query->orWhere("Loopback","LIKE","%".$request->search_keyword."%");
			$query->orWhere("MacAddress","LIKE","%".$request->search_keyword."%");			
		});  
		$networks = $networks->get();		
        return $networks;
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function AddNewRouter(Request $request)
    {
		if($request->isMethod('post')){
			
			$validator = Validator::make($request->all(), [ 
                'type'             	=> 	'required', 
                'SapId'          	=> 	'required|max:18',
				'Hostname'			=>	'required|unique:networks|max:14',
				'Loopback'			=>	'required|unique:networks',
				'MacAddress'		=>	'required'				
            ]);
            if ($validator->fails()) { 
                return redirect('/network-routers/add-new-router')->withErrors($validator)->withInput();       
            }			
			$router = new Networks();
			$router->type = $request->type;
			$router->SapId = $request->SapId;
			$router->Hostname = $request->Hostname;
			$router->Loopback = $request->Loopback;
			$router->MacAddress = $request->MacAddress;			
			$router->save();
			return redirect(route('network-routers'))->with('success', 'Router saved!');
		}else{
			return view('networks.create');
		}        
    }  
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function EditRouter(Request $request)
    {
        if($request->isMethod('post')){
			$validator = Validator::make($request->all(), [ 
                'type'             	=> 	'required', 
                'SapId'          	=> 	'required|max:18',
				'MacAddress'		=>	'required'				
            ]);
            if ($validator->fails()) { 
				return redirect('network-routers/edit-router/'.$request->id)->withErrors($validator);
            }	
			$network = Networks::find($request->id);
			$network->type =  $request->type;
			$network->SapId =  $request->SapId;
			$network->Hostname =  $request->Hostname;
			$network->Loopback =  $request->Loopback;
			$network->MacAddress =  $request->MacAddress;
			$network->save();
			return redirect('/network-routers')->with('success', 'Router updated!');
		}else{
			$DataForView['NetworkRouters'] = Networks::find($request->id);
			return view('networks.edit',$DataForView);
		}
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function DeleteRouter(Request $request)
    {
        $network = Networks::where('id',$request->id)->update(['is_deleted'=>1]);
        return redirect('/network-routers')->with('success', 'Network Router deleted!');
    }
}
