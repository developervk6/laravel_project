<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Mail;
use DB;
use Share;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Cookie;

use Session;

class AjaxController extends Controller
{
    public function __construct(){
        $this->NetworkController = app()->make('App\Http\Controllers\NetworkController');
    }   

    public function Ajax(Request $request){
        if($request->isMethod('post'))
        {  
            if($request->action=='SearchRouter'){ 
                $userDetails = Auth::user();
                $networks = $this->NetworkController->SearchRouter($request);				
				$responseData['code'] = 200;
				$responseData['message'] = 'success';
				$responseData['data'] = $networks;
                return response()->json($responseData);
            }
			if($request->action=='deleteRouter'){ 
                $userDetails = Auth::user();
                $this->NetworkController->DeleteRouter($request);				
				$responseData['code'] = 200;
				$responseData['message'] = 'success';
                return response()->json($responseData);
            }
		}

    }
}
