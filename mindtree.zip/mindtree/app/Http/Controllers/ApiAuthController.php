<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use Mail;
use App\User; 
use Illuminate\Support\Facades\Auth; 
use Validator;
use App\Http\Controllers\UserController;

class ApiAuthController extends Controller
{
    public $successStatus = 200;

    public function __construct(){
        $this->CommonController = app()->make('App\Http\Controllers\CommonController');
        $this->UserController = app()->make('App\Http\Controllers\UserController');
    }    
    public function register(Request $request){
        if(isset($request->email) && !empty($request->email)){
            $request->email = $request->email;
            $input['email'] =  $request->email;
        }
        if(isset($request->password)){
            $request->password = $request->password;
            $input['password'] =  $request->password;
        } 
		$userData = User::where('email', $request->email)->first(); 
		$input['password'] = bcrypt($request->password); 
		$validator = Validator::make($request->all(), [ 
			'email'             => 'required', 
			'password'          => 'required'
		]);
		if ($validator->fails()) { 
			return response()->json(['error'=>$validator->errors()], 401);            
		} 
		if($userData && isset($userData->id)){

			$responseData['code'] = __('statuscodes.already_registered');
			$responseData['message'] = __('messages.already_registered_account');
			return response()->json($responseData);
		}                       
       /*New User Register */  
        //echo "<pre>";print_r($input);die;
        $user = User::create($input);
        //echo "<pre>";print_r($input);die;
        $responseData['token'] =  $user->createToken('MindTree')->accessToken;
        if($user->id){
            $userData = User::where('id', $user->id)->first();
        }
        if($userData->email){
            $userData->email = $userData->email;
        }    
        $responseData['code'] = __('statuscodes.success');
        $responseData['message'] = __('messages.success');
        $responseData['data'] = $userData;        
        return response()->json($responseData); 
    }
    public function login(Request $request){

		$request->email = $request->email;
		$request->password = $request->password;
		$credentials = [
			'email' => $request->email,
			'password' => $request->password 
		];   
		if (Auth::attempt($credentials)) {
			$user = Auth::getLastAttempted();                
		}
        if(isset($user->id)){
            $token = $user->createToken('MindTree')->accessToken;            
            $responseData['code'] = __('statuscodes.success');;
            $responseData['message'] = __('messages.success');
            $responseData['token'] = $token;
            if($user->email){
                $user->email = $user->email;
            } 
            $responseData['data'] = $user;
        }        
        return response()->json($responseData);
    }    
}
