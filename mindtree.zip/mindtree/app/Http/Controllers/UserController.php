<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Mail;
use DB;
use Share;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Cookie;
use Session;

class UserController extends Controller
{
    public function __construct(){
        $this->CommonController = app()->make('App\Http\Controllers\CommonController');
    }   
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
        // $this->middleware('auth');
    // }
	/**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {	
		$arrValidator = array(
								'email' 		=> 'required|email|max:255',
								'password' 		=> 'required|min:6'							
							);		
		return Validator::make($data, $arrValidator);       
    }
    public function getUserDetailsById($id)
    {
		$user = User::where('id',$id)->first();
		return $user;
	}	   
}