<?php
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller;
use Mail;
use DB;
use App\Networks; 
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Cache;
use Validator;

class ApiNetworkController extends Controller
{
    public $successStatus = 200;
    
    public function __construct(){
        $this->CommonController = app()->make('App\Http\Controllers\CommonController');
        $this->UserController = app()->make('App\Http\Controllers\UserController');
    }  

	public function FetchRouters(Request $request){
		
		// $routers = Networks::select("*")->where("is_deleted",0);	
		// if(isset($request->type)){
			// $routers = $routers->where("type",$request->type);
		// }
		// if(isset($request->SapId)){
			// $routers = $routers->where("SapId",$request->SapId);
		// }		
		$startIp = ip2long($request->start_ip);
		$endIp = ip2long($request->end_ip);;
		// if(isset($request->start_ip) && isset($request->end_ip)){
			// //$routers = $routers->whereRaw(INET_ATON(SUBSTRING_INDEX('Loopback', '/', 1)),'between', [$startIp,$endIp]);
			// $routers = $routers->whereRaw(inet_aton(SUBSTRING_INDEX('Loopback', '/', 1)),'between',[$startIp,$endIp]);
		// }
		//echo "<pre>";print_r($routers->toSql());die;
		//$routers = $routers->orderBy("id","desc")->paginate(10);
		$query = "SELECT * FROM networks WHERE inet_aton(SUBSTRING_INDEX(Loopback, '/', 1)) >= $startIp AND inet_aton(SUBSTRING_INDEX(Loopback, '/', 1)) <=$endIp";
		$routers = DB::select($query);		
		$responseData['code'] = __('statuscodes.success');;
        $responseData['message'] = __('messages.success');
		$responseData['data'] = $routers;
		return $responseData;
	}
	
	public function AddRouter(Request $request)
    {
		if($request->isMethod('post')){
			
			$validator = Validator::make($request->all(), [ 
                'type'             	=> 	'required', 
                'SapId'          	=> 	'required|max:18',
				'Hostname'			=>	'required|unique:networks|max:14',
				'Loopback'			=>	'required|unique:networks',
				'MacAddress'		=>	'required'				
            ]);
            if ($validator->fails()) { 
                return response()->json(['error'=>$validator->errors()], 401);            
            }										
			$router = new Networks();
			$router->type = $request->type;
			$router->SapId = $request->SapId;
			$router->Hostname = $request->Hostname;
			$router->Loopback = $request->Loopback;
			$router->MacAddress = $request->MacAddress;			
			$router->save();			
		}
		$responseData['code'] = __('statuscodes.success');;
		$responseData['message'] = __('messages.success');		
		return $responseData;		
    }  
	public function UpdateRouter(Request $request)
    {
		if($request->isMethod('post')){
			
			$validator = Validator::make($request->all(), [ 
                'type'             	=> 	'required', 
                'SapId'          	=> 	'required|max:18',
				'Hostname'			=>	'required|unique:networks|max:14',
				'MacAddress'		=>	'required'				
            ]);
            if ($validator->fails()) { 
                return response()->json(['error'=>$validator->errors()], 401);            
            }
			$arrUpdateData = array(
						'type'             	=> 	$request->type, 
						'SapId'          	=> 	$request->SapId,
						'Hostname'			=>	$request->Hostname,
						'MacAddress'		=>	$request->MacAddress	
				);
			Networks::where("Loopback",$request->Loopback)->update($arrUpdateData);				
		}
		$responseData['code'] = __('statuscodes.success');;
		$responseData['message'] = __('messages.success');		
		return $responseData;		
    }
	//Delete router using ip address
	public function DeleteRouter(Request $request){
		Networks::where("Loopback",$request->ip)->update(["is_deleted"=>1]); ///soft deleted
		$responseData['code'] = __('statuscodes.success');;
        $responseData['message'] = __('messages.success');
		return $responseData;
	}
}