<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Socialite;
use Auth;
use Exception;

class SocialAuthLinkedinController extends Controller
{
    public function __construct(){
        $this->UserController = app()->make('App\Http\Controllers\UserController');
    }   
    public function redirectToProvider(Request $request)
    {
        return Socialite::driver($request->provider)->redirect();
    }
    public function handleProviderCallback(Request $request)
    {        
        try {
            $first_name = '';
            $last_name = '';
            $socialUser = Socialite::driver($request->provider)->user(); 
            //echo "<pre>";print_r($socialUser);die;           
            
            if(isset($socialUser) && !empty($socialUser->email)){
                $existUser = User::where('email',$socialUser->email)->first();
                
            }else{
                $existUser = false;
            }
            if($existUser && isset($existUser->status) && $existUser->status=='ACTIVE') {
                Auth::loginUsingId($existUser->id);
            }
            else if($existUser && isset($existUser->status) && $existUser->status=='PENDING') {
				if($existUser->id){                       
                    if($request->provider=='linkedin'){
                        $first_name = $socialUser->first_name;
                        $last_name = $socialUser->last_name;
                    }else if($request->provider=='google'){
                        $name = $socialUser->name;
                        if(!empty($name)){
                            $arrName = explode(" ",$name);
                            $first_name = $arrName[0];
                            $last_name = $arrName[1];
                        }
                    }  
                    if($existUser->user_type!=''){
                        return redirect(route('complete-profile'))
                            ->with("id",$existUser->id)
                            ->with('email',$socialUser->email)
                            ->with('user_type',$existUser->user_type)
                            ->with('first_name',$first_name)
                            ->with('last_name',$last_name)
                            ->with('profile_image',$socialUser->avatar_original);
                    }  else{
                        return redirect(route('signup-step2'))
                            ->with("id",$existUser->id)
                            ->with('email',$socialUser->email)
                            ->with('first_name',$first_name)
                            ->with('last_name',$last_name)
                            ->with('profile_image',$socialUser->avatar_original);
                    }                
                    
                }
            }
            else {
                $user = new User;
                if($request->provider=='linkedin'){
                    $user->linkedin_id = $socialUser->id;
                    $first_name = $socialUser->first_name;
                    $last_name = $socialUser->last_name;
                }else if($request->provider=='google'){
                    $user->google_id = $socialUser->id;
                    $name = $socialUser->name;
                    if(!empty($name)){
                        $arrName = explode(" ",$name);
                        $first_name = $arrName[0];
                        $last_name = $arrName[1];
                    }
                }
                $user->email = $socialUser->email;                
                $user->password = bcrypt(rand(1,10000));
                $user->signup_from          = strtoupper($request->provider);
                if(isset($socialUser->avatar_original)){$user->profile_image = $socialUser->avatar_original;}
                if(isset($socialUser->avatar_original)){$user->profile_thumb_image = $socialUser->avatar_original;}
                $user->created_at           = time();
                $user->updated_at           = time();
                $user->save();
                if($user->id){ 
                    $this->UserController->InsertUserSettings($user->id);            
                    return redirect(route('signup-step2'))
                    ->with("id",$user->id)
                    ->with('email',$socialUser->email)
                    ->with('first_name',$first_name)
                    ->with('last_name',$last_name)
                    ->with('profile_image',$socialUser->avatar_original);
                }
            }
            return redirect()->to('/home');
        } 
        catch (Exception $e) {
            //echo "sssss<pre>";print_r($e->getMessage());die;
            return 'error';
        }
    }
}