<?php
Use App\Medias;
Use App\Notifications;
function defaultPetPic()
{
    return URL('public/images/profile_avatar.png');
}
function getContractId($id){
    $num_padded = sprintf("%06d", $id);
    return $num_padded;
}
function getUserProfileImage($image_url=""){ 
    if(!empty($image_url)){
        try{
            //return URL('/public/timthumb.php').'?src='.$image_url.'&w=70&h=70';
            return $image_url;
        }catch (Exception $e){
            return $image_url;
        }
        return $image_url;        
    }
    return defaultPetPic();
}
function resize_crop_image($max_width, $max_height, $source_file, $dst_dir, $quality = 80){
    $imgsize = getimagesize($source_file);
    $width = $imgsize[0];
    $height = $imgsize[1];
    $mime = $imgsize['mime'];

    switch($mime){
        case 'image/gif':
            $image_create = "imagecreatefromgif";
            $image = "imagegif";
            break;

        case 'image/png':
            $image_create = "imagecreatefrompng";
            $image = "imagepng";
            $quality = 7;
            break;

        case 'image/jpeg':
            $image_create = "imagecreatefromjpeg";
            $image = "imagejpeg";
            $quality = 80;
            break;

        default:
            return false;
            break;
    }

    $dst_img = imagecreatetruecolor($max_width, $max_height);
    $src_img = $image_create($source_file);

    $width_new = $height * $max_width / $max_height;
    $height_new = $width * $max_height / $max_width;
    //if the new width is greater than the actual width of the image, then the height is too large and the rest cut off, or vice versa
    if($width_new > $width){
        //cut point by height
        $h_point = (($height - $height_new) / 2);
        //copy image
        imagecopyresampled($dst_img, $src_img, 0, 0, 0, $h_point, $max_width, $max_height, $width, $height_new);
    }else{
        //cut point by width
        $w_point = (($width - $width_new) / 2);
        imagecopyresampled($dst_img, $src_img, 0, 0, $w_point, 0, $max_width, $max_height, $width_new, $height);
    }

    $image($dst_img, $dst_dir, $quality);

    if($dst_img)imagedestroy($dst_img);
    if($src_img)imagedestroy($src_img);
}
function GetTimeFromDateFormat($datetime,$full = false){
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
function medias($media_ids=''){
    if(!empty($media_ids)){
        $arrMediaIds = explode(",",$media_ids);
        $Medias = Medias::select("*")->whereIn("id",$arrMediaIds)->get();
        return $Medias;  
    }    
    return array();       
}
function videoType($url) {
    if (strpos($url, 'youtube') > 0 ) {
        return 'youtube';
    } elseif (strpos($url, 'youtu.be') > 0) {
        return 'youtu.be';
    } elseif (strpos($url, 'vimeo') > 0) {
        return 'vimeo';
    } else {
        return 'unknown';
    }
}
function UnreadNotifications(){
    $user = Auth::user();
    $unread_notifications = Notifications::where(["receiver_id"=>$user->id])->orderBy("id","DESC")->get();
    return $unread_notifications;
}
?>