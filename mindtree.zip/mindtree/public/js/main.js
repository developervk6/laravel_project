$(function(){
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("#form-total").steps({
        headerTag: "h2",
        bodyTag: "section",
        transitionEffect: "fade",
        enableAllSteps: true,
        autoFocus: true,
        transitionEffectSpeed: 500,
        titleTemplate : '<span class="title">#title#</span>',
        labels: {
            previous : 'Previous',
            next : 'Next',
            finish : 'Proceed',
            current : ''
        },
        onStepChanging: function (event, currentIndex, newIndex) {            
            var move = false;
            if(currentIndex==0 && newIndex==1){                
                var user_type = $("#user_type").val();                
                if(user_type!='BUSINESS' && $('#first_name').val()==''){
                    alert("Please enter first name.");
                    $('#first_name').focus();
                    return false;
                }else if(user_type!='BUSINESS' && $('#last_name').val()==''){
                    alert("Please enter last name.");
                    $('#last_name').focus();
                    return false;			
                }else if(user_type=='BUSINESS' && $('#business_name').val()==''){
                    alert("Please enter business name.");
                    $('#business_name').focus();
                    return false;                    
                }else if($('#email').val()==''){
                    alert("Please enter email.");
                    $('#email').focus();
                    return false;			
                }else if($('#mobile').val()==''){
                    alert("Please enter phone number.");
                    $('#mobile').focus();
                    return false; 
                }else if($('#mobile').val() !='' && $('#mobile').val().length<6){
                    alert("Invalid phone number");
                    $('#mobile').focus();
                    return false;             	
                }else{
                    var id = $("#id").val();                    
                    var email = $("#email").val();
                    var country_code = $("#country_code").val();
                    var mobile = $("#mobile").val();
                    var profile_image = $("#profile_image").val();
                    var formData;
                    if(user_type=='BUSINESS'){
                        var business_name = $("#business_name").val();
                        formData = {id:id,email:email,business_name:business_name,country_code:country_code,mobile:mobile,profile_image:profile_image,user_type:user_type};
                    }else{
                        var first_name = $("#first_name").val();
                        var last_name = $("#last_name").val();
                        formData = {id:id,email:email,first_name:first_name,last_name:last_name,country_code:country_code,mobile:mobile,profile_image:profile_image,user_type:user_type};
                    }                    
                    $.ajax({
                        type:'POST',
                        url:'/AjaxCompleteProfile',
                        data:formData,
                        async: false,
                        success:function(data){
                            if(data.status=='done'){
                                if(data.code==200){
                                    //var country_html = '<option value="'+data.country_id+'">'+data.country_name+'</option>';
                                    $('#country_name').val(data.country_name);
                                    $('#country').val(data.country_id);
                                    $('#state').html(data.states);
                                    $('#verification_code_user').val(data.verification_code);
                                    move = true;
                                }else if(data.code==404){
                                    alert("Mobile number already exists.");
                                    move = false; 
                                }
                            }
                        }
                    });
                }
                return move;
            }else if(currentIndex==1 && newIndex==2){
                var verification_code = $('#otp1').val()+$('#otp2').val()+$('#otp3').val()+$('#otp4').val();
                if($('#otp1').val()=='' || $('#otp2').val()=='' || $('#otp3').val()=='' || $('#otp4').val()==''){
                    alert("Please enter verification code.");
                    $('#otp1').focus();
                    return false;
                }else if(verification_code!=$('#verification_code_user').val()){
                    alert("Please enter valid verification code.");
                    $('#otp1').val("");
                    $('#otp2').val("");
                    $('#otp3').val("");
                    $('#otp4').val("");
                    $('#otp1').focus();
                    return false;
                }else{ 
                    return true;
                }
                
            }else if(currentIndex==2 && newIndex==3){
                if($('#state').val()==''){
                    alert("Please select state.");
                    $('#state').focus();
                    return false;
                }else if($('#city').val()==''){
                    alert("Please select city.");
                    $('#city').focus();
                    return false;
                }else if($('#zipcode').val()==''){
                    alert("Please enter zip code.");
                    $('#zipcode').focus();
                    return false;
                }else if($('#zipcode').val() !='' && $('#zipcode').val().length<4){
                    alert("Invalid zip code");
                    $('#zipcode').focus();
                    return false;
                }else{
                    var id = $("#id").val();
                    var user_type = $("#user_type").val();
                    var email = $("#email").val();
                    var country_code = $("#country_code").val();
                    var mobile = $("#mobile").val();
                    var profile_image = $("#profile_image").val();
                    var country = $("#country").val();
                    var state = $("#state").val();
                    var city = $("#city").val();                   
                    var zipcode = $("#zipcode").val();
                    var formData; 
                    if(user_type=='BUSINESS'){
                        var business_name = $("#business_name").val();
                        formData = {id:id,email:email,business_name:business_name,country_code:country_code,mobile:mobile,profile_image:profile_image,user_type:user_type,city:city,state:state,country:country,zipcode:zipcode};
                    }else{
                        var first_name = $("#first_name").val();
                        var last_name = $("#last_name").val();
                        formData = {id:id,email:email,first_name:first_name,last_name:last_name,country_code:country_code,mobile:mobile,profile_image:profile_image,user_type:user_type,city:city,state:state,country:country,zipcode:zipcode};
                    } 

                    $.ajax({
                        type:'POST',
                        url:'/AjaxUpdateOtherInfo',
                        data:formData,
                        success:function(data){
                            if(data.status=='done'){
                                $("#form-total-h-0").hide();
                                //$('#verification_code_user').val(data.verification_code);
                            }
                            return true;
                        }
                    });
                }
            }
            return true;
        }
    });
    $('#mobile,#zipcode').keydown(function(event){        
        if ( event.keyCode == 46 || event.keyCode == 8 ) {
        }
        else {
            if (event.keyCode < 48 || event.keyCode > 57) {
                event.preventDefault(); 
            }             
        }
    });
    $('a[href="#finish"]').click(function(){
        if($('#user_type').val()=='BUSINESS' || $('#user_type').val()=='FREELANCER' ){            
            window.location.href = profile_path;
        }else{
            localStorage.setItem("action_name", "signup");
            window.location.href = payment_path;
        }
    }); 
});
function populateCitiesOfState(state_id){
    if(state_id==''){
        alert("Please select state.");
        $('#state').focus();
        return false;
    }else{
        $.ajax({
           type:'GET',
           contentType: "application/json",
           url:'/api/fetchCities/'+state_id,
           success:function(data){
                if(data.code==200){
                    var htmlCities = '<option value="">City</option>';
                    data.data.forEach(obj => {
                        htmlCities += '<option value="'+obj.id+'">'+obj.name+'</option>';
                    });
                    $('#city').html(htmlCities);
              }
              return true;
           }
        });
    }
}
function populateStatesOfCountry(country_id){
    if(country_id==''){
        alert("Please select country.");
        $('#country').focus();
        return false;
    }else{
        $.ajax({
           type:'GET',
           contentType: "application/json",
           url:'/api/fetchStates/'+country_id,
           success:function(data){
                if(data.code==200){
                    var htmlStates = '<option value="">State</option>';
                    data.data.forEach(obj => {
                        htmlStates += '<option value="'+obj.id+'">'+obj.name+'</option>';
                    });
                    $('#state').html(htmlStates);
              }
              return true;
           }
        });
    }
}
function ResendVerificationCode(){
    var id = $("#id").val();
    var country_code = $("#country_code").val();
    var mobile = $("#mobile").val();
    if(id==''){
        alert("Invalid user.");
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'/resend-code',
            data:{id:id,country_code:country_code,mobile:mobile},
            success:function(data){
               if(data.status=='done'){
                    $('#verification_code_user').val(data.verification_code);
                    alert("New verification code sent.");
               }
            }
         });
    }
}


