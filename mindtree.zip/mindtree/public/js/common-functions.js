function uploadprofilephoto(formID) {
    //jQuery('#loading_img').attr('display','block')
    $.ajax({
        type: "POST",
        url: base_path+"/upload_profile_image",
        data:new FormData($("#"+formID)[0]),
        dataType:'json',
        async:false,
        processData: false,
        contentType: false,
        success:function(response){
            //console.log(response);return false;
            if(response.success=='done'){
                var image_url = response.url;
                $('#profile_image_span').html('<img src="'+image_url+'" class="img-large img-responsive add-pet-default" alt="" style="width:100px"/>');
                $('#profile_image').val(image_url);
            }else{
                alert(response.error);
            }
        },
    });
}
// $(document).ready(function(){
//     $("#myInput").keyup(function(){
//         var search_in = $("#search_in").val();
//         if(search_in==''){search_in='all';}
//         $.ajax({
//             type:'GET',
//             url:'/get-profile-name-by-keyword/'+search_in+'/'+$(this).val(),
//             success:function(data){
//                 if(data.status=='done'){  
//                     console.log(data.data);
//                     autocomplete(document.getElementById("myInput"), data.data);
//                     // $("#global_search").autocomplete({
//                     //     source: data.data
//                     // });
//                 }
//             }
//         });
//     });
// });
function populateServiceSubCategories(service_category_id){
    if(service_category_id!=''){      
        $.ajax({
           type:'GET',
           contentType: "application/json",
           url:'/GetServiceSubCategories/'+service_category_id,
           success:function(data){
                if(data.status=='done'){
                    var htmlSubCateries = '<option value="">Sub Category</option>';
                    data.data.forEach(obj => {
                        htmlSubCateries += '<option value="'+obj.id+'">'+obj.service_name+'</option>';
                    });
                    $('#service_sub_category_id').html(htmlSubCateries);
              }
              return true;
           }
        });
    }
}
function getReverseGeocodingData(lat, lng) {
    var address = '';
    var latlng = new google.maps.LatLng(lat, lng);
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'latLng': latlng }, function (results, status) {
        if (status !== google.maps.GeocoderStatus.OK) {
            alert(status);
        }
        if (status == google.maps.GeocoderStatus.OK) {
            address = (results[0].formatted_address);
        }
    });
    return address;
}

/* Update read as notifications */
$("#notification_top").click(function(){
    $.ajax({
        type:'POST',
        url:'/UpdateNotificationStatus',
        success:function(data){
            console.log(data);
            if(data.code==200){
                console.log(data);
            }
        }
    });
});